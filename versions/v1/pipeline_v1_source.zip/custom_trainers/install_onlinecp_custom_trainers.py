#!/usr/bin/env python3
"""Install legacy, rank-curriculum and difficulty-feedback trainers into nnU-Net v2.

The script is intentionally portable. By default it locates the active
``nnunetv2`` package. Use ``--nnunet-root`` to target a source checkout, for
example on Windows::

    python install_onlinecp_custom_trainers.py apply \
      --nnunet-root C:\\path\\to\\nnunetv2

All source modules and curriculum helpers must be beside this installer:

- nnUNetTrainer_OnlinePairedCP.py
- nnUNetTrainer_OnlinePairedCPArgmaxV3.py
- nnUNetTrainer_OnlineCPCurriculum.py
- onlinecp_curriculum_policy.py
- onlinecp_curriculum_contract.py
- nnUNetTrainer_OnlineCPFeedback.py
- onlinecp_feedback_policy.py
- onlinecp_feedback_metrics.py
- onlinecp_raw_resampling.py
- onlinecp_raw_bank.py
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

MODULES = {
    "onlinecp_curriculum_policy.py": (
        "bde202bc0060b47350724a219dfa573d946e58410d46453698bd07bb87ab6b1b"
    ),
    "onlinecp_curriculum_contract.py": (
        "4bcb725c896acde1d828db978d35b7d3e8219122eedb6aa9b2fc3dcf1a040493"
    ),
    "nnUNetTrainer_OnlineCPCurriculum.py": (
        "37936501a55fd2443e414db5083c564e556d7dee96bbf9f1e7d6d38dc98b3f77"
    ),
    "nnUNetTrainer_OnlinePairedCP.py": (
        "ec4b3934a0e05a2810dbab69a8a0f60e06754d4853aea465a3ee735b56008ed1"
    ),
    "nnUNetTrainer_OnlinePairedCPArgmaxV3.py": (
        "055c6c154820c8994bb9d59273ca8515c3db4ff6a4ed4064923fefe2b3f46320"
    ),
    "onlinecp_feedback_policy.py": (
        "566357115d84fcdfc46b03706bdaa86a00c9ff9d3510cd8490268e8bc219a37c"
    ),
    "onlinecp_feedback_metrics.py": (
        "fe0d94b5d98fe376c41b8bf6eb60d8c922b9b1d6f629fe88d5fa1f1ad108982c"
    ),
    "nnUNetTrainer_OnlineCPFeedback.py": (
        "2ed7f15acf0aad9f9bcbc161b31b3b69b234792bb34a471c15165e958a173c8c"
    ),
    "onlinecp_raw_resampling.py": (
        "49d1c06eed2d5f9ec535ab587e2789f7af7ef8c9d096c0706cc63a9292c318a2"
    ),
    "onlinecp_raw_bank.py": (
        "0cf1249958de0bebece45501fc689844fb3e8a1ec1bd47f44d62a0cc790a7a6b"
    ),
}
TARGET_RELATIVE = Path("training") / "nnUNetTrainer"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def locate_nnunet_root(explicit: str | None) -> Path:
    if explicit:
        root = Path(explicit).expanduser().resolve()
        if root.name != "nnunetv2" and (root / "nnunetv2").is_dir():
            root = root / "nnunetv2"
        if not (root / "training" / "nnUNetTrainer").is_dir():
            raise RuntimeError(
                "--nnunet-root must point to the nnunetv2 package directory "
                f"(missing training/nnUNetTrainer): {root}"
            )
        return root

    spec = importlib.util.find_spec("nnunetv2")
    if spec is None or spec.submodule_search_locations is None:
        raise RuntimeError(
            "nnunetv2 is not importable. Activate the nnU-Net environment or "
            "pass --nnunet-root."
        )
    locations = [Path(value).resolve() for value in spec.submodule_search_locations]
    if len(locations) != 1:
        raise RuntimeError(f"Ambiguous nnunetv2 package roots: {locations}")
    return locations[0]


def source_dir() -> Path:
    return Path(__file__).resolve().parent


def audit_sources() -> dict[str, Path]:
    root = source_dir()
    output: dict[str, Path] = {}
    for name, expected in MODULES.items():
        path = root / name
        if not path.is_file():
            raise RuntimeError(f"Required trainer source is missing: {path}")
        actual = sha256(path)
        if actual != expected:
            raise RuntimeError(
                f"Trainer source hash mismatch for {name}:\n"
                f"  actual:   {actual}\n"
                f"  expected: {expected}"
            )
        compile(path.read_text(encoding="utf-8"), str(path), "exec")
        output[name] = path
    return output


def atomic_write_bytes(data: bytes, target: Path, *, overwrite: bool = False) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    descriptor, filename = tempfile.mkstemp(prefix=f".{target.name}.", suffix=".tmp", dir=target.parent)
    temporary = Path(filename)
    try:
        with os.fdopen(descriptor, "wb") as dst:
            dst.write(data)
            dst.flush()
            os.fsync(dst.fileno())
        if overwrite:
            os.replace(temporary, target)
        else:
            os.link(temporary, target)
    finally:
        if temporary.exists():
            temporary.unlink()


def atomic_copy(source: Path, target: Path, *, overwrite: bool = False) -> None:
    atomic_write_bytes(source.read_bytes(), target, overwrite=overwrite)


def import_smoke(nnunet_root: Path) -> None:
    parent = nnunet_root.parent
    code = r'''
from nnunetv2.training.nnUNetTrainer.nnUNetTrainer_OnlinePairedCP import (
    nnUNetTrainer_250epochs_OnlineBasicCP,
    nnUNetTrainer_250epochs_OnlineHierCPExactArgmax,
    nnUNetTrainer_250epochs_OnlineHierCPNoPatientExactArgmax,
    nnUNetTrainer_250epochs_OnlineHierCPNoPopulationExactArgmax,
    _smoke_policy as smoke_v2,
    _smoke_paste as paste_v2,
)
from nnunetv2.training.nnUNetTrainer.nnUNetTrainer_OnlinePairedCPArgmaxV3 import (
    nnUNetTrainer_250epochs_OnlineBasicCPSharedPoolsV3,
    nnUNetTrainer_250epochs_OnlineHierCPArgmaxV3,
    _smoke_policy as smoke_v3,
    _smoke_paste as paste_v3,
)
from nnunetv2.training.nnUNetTrainer.nnUNetTrainer_OnlineCPCurriculum import (
    nnUNetTrainer_250epochs_OnlineBasicCPCurriculumControl,
    nnUNetTrainer_250epochs_OnlineHierCPCurriculum,
    nnUNetTrainer_250epochs_OnlineHierCPNoPatientCurriculum,
    nnUNetTrainer_250epochs_OnlineHierCPNoPopulationCurriculum,
)
from nnunetv2.training.nnUNetTrainer.nnUNetTrainer_OnlineCPFeedback import (
    nnUNetTrainer_250epochs_OnlineBasicCPFeedbackControl,
    nnUNetTrainer_250epochs_OnlineHierCPFeedback,
)
from nnunetv2.training.nnUNetTrainer.onlinecp_raw_bank import (
    PASTE_CONTRACT, RawBankStore,
)
from nnunetv2.training.nnUNetTrainer.onlinecp_raw_resampling import (
    prepare_case, prepare_candidate, apply_candidate,
)
assert PASTE_CONTRACT == 'onlinecp_raw_target_paste_v1'
assert callable(RawBankStore) and all(callable(value) for value in
                                    (prepare_case, prepare_candidate, apply_candidate))
assert nnUNetTrainer_250epochs_OnlineBasicCPFeedbackControl.basic_control
assert not nnUNetTrainer_250epochs_OnlineHierCPFeedback.basic_control
assert nnUNetTrainer_250epochs_OnlineHierCPFeedback.bank_contract_filename == 'feedback_contract.json'
assert nnUNetTrainer_250epochs_OnlineBasicCPCurriculumControl.basic_control
assert not nnUNetTrainer_250epochs_OnlineHierCPCurriculum.basic_control
assert nnUNetTrainer_250epochs_OnlineHierCPNoPatientCurriculum.expected_ablation_mode == 'no_patient'
assert nnUNetTrainer_250epochs_OnlineHierCPNoPopulationCurriculum.expected_ablation_mode == 'no_population'
assert nnUNetTrainer_250epochs_OnlineBasicCP.online_policy == "basic"
assert nnUNetTrainer_250epochs_OnlineHierCPExactArgmax.online_policy == "hier_argmax"
assert nnUNetTrainer_250epochs_OnlineHierCPNoPatientExactArgmax.expected_ablation_mode == "no_patient"
assert nnUNetTrainer_250epochs_OnlineHierCPNoPopulationExactArgmax.expected_ablation_mode == "no_population"
assert nnUNetTrainer_250epochs_OnlineBasicCPSharedPoolsV3.online_policy == "basic"
assert nnUNetTrainer_250epochs_OnlineHierCPArgmaxV3.online_policy == "hier"
print("[OK] v2 policy", smoke_v2())
print("[OK] v2 paste", paste_v2())
print("[OK] v3 policy", smoke_v3())
print("[OK] v3 paste", paste_v3())
print("[OK] OnlineCP custom trainer imports")
'''
    env = os.environ.copy()
    old_pythonpath = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = str(parent) + (os.pathsep + old_pythonpath if old_pythonpath else "")
    result = subprocess.run(
        [sys.executable, "-c", code],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        env=env,
    )
    sys.stdout.write(result.stdout)
    if result.returncode != 0:
        raise RuntimeError("Installed trainer import smoke failed")


def check(nnunet_root: Path) -> int:
    sources = audit_sources()
    target_dir = nnunet_root / TARGET_RELATIVE
    print(f"python:  {Path(sys.executable).resolve()}")
    print(f"nnunet:  {nnunet_root}")
    print(f"target:  {target_dir}")
    for name, source in sources.items():
        target = target_dir / name
        state = "missing"
        if target.is_file():
            state = "same" if sha256(target) == MODULES[name] else "different"
        print(f"  {name}: source=OK target={state}")
    print("[OK] source syntax and SHA-256 audit")
    return 0


def apply(nnunet_root: Path, *, overwrite: bool = False) -> int:
    sources = audit_sources()
    target_dir = nnunet_root / TARGET_RELATIVE
    if not target_dir.resolve().is_relative_to(nnunet_root.resolve()):
        raise RuntimeError(f"Trainer target escapes the requested package root: {target_dir}")
    originals: dict[Path, tuple[bytes | None, int | None]] = {}
    conflicts: list[Path] = []
    for name in MODULES:
        target = target_dir / name
        if target.is_symlink() or (target.exists() and not target.is_file()):
            raise RuntimeError(f"Trainer target must be a regular file or absent: {target}")
        if target.is_file():
            originals[target] = (target.read_bytes(), target.stat().st_mode & 0o777)
            if hashlib.sha256(originals[target][0]).hexdigest() != MODULES[name]:
                conflicts.append(target)
        else:
            originals[target] = (None, None)
        print(f"[InstallPlan] {sources[name]} -> {target}; overwrite={overwrite}")
    if conflicts and not overwrite:
        raise FileExistsError(
            "Existing trainer implementations differ; no trainer files were changed. "
            "Review these paths and use --overwrite only to authorize their replacement: "
            + ", ".join(str(path) for path in conflicts)
        )

    changed: list[Path] = []
    try:
        for name, source in sources.items():
            target = target_dir / name
            original_bytes, _ = originals[target]
            if original_bytes is not None and hashlib.sha256(original_bytes).hexdigest() == MODULES[name]:
                print(f"[REUSE] identical trainer: {target}")
                continue
            if original_bytes is not None:
                backup = target.with_name(target.name + f".pre_hiercp_onlinecp.{time.time_ns()}")
                atomic_write_bytes(original_bytes, backup)
                print(f"[BACKUP] {backup}")
            atomic_copy(source, target, overwrite=original_bytes is not None)
            changed.append(target)
            if sha256(target) != MODULES[name]:
                raise RuntimeError(f"Post-copy hash mismatch: {target}")
            print(f"[INSTALL] {target}")

        for name in MODULES:
            subprocess.run(
                [sys.executable, "-m", "py_compile", str(target_dir / name)],
                check=True,
            )
        import_smoke(nnunet_root)
    except Exception:
        for target in reversed(changed):
            data, mode = originals[target]
            if data is None:
                if target.exists():
                    target.unlink()
            else:
                atomic_write_bytes(data, target, overwrite=True)
                if mode is not None:
                    os.chmod(target, mode)
        print("[ROLLBACK] Trainer installation rolled back", file=sys.stderr)
        raise

    print("[OK] Legacy, rank-curriculum and difficulty-feedback trainer modules installed and imported")
    return 0


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("check", "apply"))
    parser.add_argument(
        "--overwrite", action="store_true",
        help="Explicitly authorize replacing different existing trainers after a unique backup.",
    )
    parser.add_argument(
        "--nnunet-root",
        help="Path to the nnunetv2 package directory; defaults to the active environment.",
    )
    args = parser.parse_args()
    try:
        root = locate_nnunet_root(args.nnunet_root)
        if args.action == "check":
            raise SystemExit(check(root))
        raise SystemExit(apply(root, overwrite=args.overwrite))
    except Exception as exc:
        print(f"[ERROR] {exc}", file=sys.stderr)
        raise SystemExit(1)


if __name__ == "__main__":
    main()
