"""Entry point for the user-requested v1-style L0 application.

This is a local-module integration/verification entry point, not a replacement
for completed full-cohort training or the native online augmentation service.
"""
import argparse
import json
from pathlib import Path
import sys


def main():
    p=argparse.ArgumentParser(description=__doc__)
    sub=p.add_subparsers(dest='command',required=True)
    sub.add_parser('check')
    verify=sub.add_parser('verify')
    verify.add_argument('--output',required=True)
    verify.add_argument('--check-cp128',action='store_true')
    args=p.parse_args()
    if args.command=='verify':
        from tools.verify_v222_v1_l0 import main as verify_main
        sys.argv=[sys.argv[0],'--output',args.output]+(['--check-cp128'] if args.check_cp128 else [])
        verify_main()
        return
    import torch
    from hiercp_v222.v1_local import model
    from hiercp_v222.contracts import read_json, verify_v1
    root=Path(__file__).resolve().parent
    cfg=read_json(root/'config/prompt_graph_v222_v1_l0.json')
    base=read_json(root/cfg['base_config'])
    with torch.device('meta'):
        net=model(cfg,base)
    print(json.dumps(dict(config=cfg,parameters=sum(p.numel() for p in net.parameters()),
        L0_parameters=sum(p.numel() for p in net.local.parameters()),
        L1_L2_parameters=sum(p.numel() for n,p in net.named_parameters() if not n.startswith('local.')),
        v1_revision=verify_v1(),full_training=False,native_cp_bank_integrated=False),indent=2))


if __name__=='__main__':
    main()
