"""v2.22: blinded context episodes and cross-patient prompt alignment."""
PIPELINE_VERSION = 'hiercp_v222_blinded_context_r1'
