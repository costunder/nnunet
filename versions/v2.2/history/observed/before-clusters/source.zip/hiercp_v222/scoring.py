"""Frozen context scoring for online CP; no target annotation reaches the model."""
import time
import numpy as np
import torch
from .contracts import validate_checkpoint
from .model import PromptGraphModel
from .data import support_for_query
from .training import require_device, configure_runtime

class Scorer:
    def __init__(self, checkpoint):
        require_device('cuda')
        self.payload = validate_checkpoint(torch.load(checkpoint, map_location='cpu', weights_only=False))
        self.cfg = self.payload['config']; self.base = self.payload['base']
        configure_runtime(self.base, self.cfg['seed'])
        self.model = PromptGraphModel(self.cfg, self.base, self.payload['input_contract']).cuda().eval()
        self.model.load_state_dict(self.payload['state_dict'])
        self.model.requires_grad_(False)
        self.memory = {k: v.cuda() if torch.is_tensor(v) else v for k, v in self.payload['memory'].items()}
        self.batch = None

    @torch.inference_mode()
    def score_records(self, records, recipient):
        if recipient not in self.payload['split']['outer_train']:
            raise ValueError('CP recipient must be a segmentation-training patient')
        if len(records) != self.cfg['candidate_count'] or any(set(r) != {'patch'} for r in records):
            raise ValueError('128 context-only records required; labels/geometry cannot enter scorer')
        group = self.payload['identities']['cases'][recipient]['patient_group']
        support = support_for_query(self.memory, group)
        with torch.autocast('cuda', dtype=torch.bfloat16): state = self.model.prepare_support(*support)
        patches = torch.from_numpy(np.stack([r['patch'] for r in records]))
        reports = []
        if self.batch is None:
            for count in self.base['generation']['scoring_batch_size_candidates']:
                try:
                    torch.cuda.reset_peak_memory_stats(); start = time.perf_counter()
                    for _ in range(self.cfg['batch_calibration_repeats']):
                        with torch.autocast('cuda', dtype=torch.bfloat16):
                            result = self.model.predict_embeddings(self.model.local(patches[:count].cuda()), state)
                        torch.cuda.synchronize()
                    elapsed = time.perf_counter()-start
                    peak = torch.cuda.max_memory_allocated()
                    free, total = torch.cuda.mem_get_info()
                    reports.append(dict(batch=count, graphs_per_second=count*self.cfg['batch_calibration_repeats']/elapsed,
                                        peak_vram_bytes=peak, accepted=peak < total*self.cfg['max_vram_fraction']))
                    del result
                except torch.cuda.OutOfMemoryError as error:
                    reports.append(dict(batch=count, accepted=False, error=str(error)))
                    torch.cuda.empty_cache(); break
            valid = [r for r in reports if r['accepted']]
            if not valid: raise MemoryError('No full-context scoring batch fits alongside nnU-Net')
            self.batch = max(valid, key=lambda r: r['graphs_per_second'])['batch']
        scores = []
        for chunk in patches.split(self.batch):
            with torch.autocast('cuda', dtype=torch.bfloat16):
                result = self.model.predict_embeddings(self.model.local(chunk.cuda()), state)
            scores.append(result['ranking_score'].float().cpu())
        scores = torch.cat(scores).numpy()
        if scores.shape != (128,) or not np.isfinite(scores).all(): raise FloatingPointError('Invalid context score')
        return scores, dict(physical_batch=self.batch, calibration=reports, all_128_candidates_scored=True,
                            query_group_excluded_from_support=group, score_is_calibrated_incidence_probability=False)
