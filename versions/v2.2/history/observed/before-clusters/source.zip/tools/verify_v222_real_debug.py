"""Explicit three-patient real-CT DEBUG; no production cache or learned checkpoint."""
import argparse
import sys
import time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

def main():
    import numpy as np
    import torch
    from scipy import ndimage as ndi
    from hiercp.common import discover_cases,load_case
    from hiercp.preparation_runtime import snapshot
    from hiercp_v222.contracts import load_config,read_json,write_new,safe_new_root,verify_v1,source_identity
    from hiercp_v222.data import inspect_case,fit_contract,support_for_query
    from hiercp_v222.inputs import context_patch
    from hiercp_v222.model import PromptGraphModel,supervised_loss
    from hiercp_v222.training import configure_runtime
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--medical-root',required=True);p.add_argument('--split',required=True)
    p.add_argument('--cases',nargs=3,required=True);p.add_argument('--output',required=True)
    args=p.parse_args();cfg,base=load_config();split=read_json(args.split);verify_v1()
    if len(set(args.cases))!=3 or not set(args.cases)<=set(split['inner_train']):
        raise ValueError('Three distinct actual inner-training cases required')
    configure_runtime(base,cfg['seed'])
    if not torch.cuda.is_available():raise RuntimeError('CUDA required')
    root=safe_new_root(args.output);torch.set_num_threads(4);torch.manual_seed(42)
    paths={p.case_id:p for p in discover_cases(Path(args.medical_root)/'Data')}
    write_new(root/'started.json',dict(debug=True,cases=args.cases,config=cfg,base=base,resources=snapshot(),
              gpu=torch.cuda.get_device_name(),gpu_count=torch.cuda.device_count(),source_identity=source_identity()))
    with ThreadPoolExecutor(max_workers=3) as pool:
        rows=list(pool.map(lambda c:inspect_case(paths[c],20),args.cases))
    inventory={r['case_id']:r for r in rows}
    # DEBUG fit is explicitly separate; never a production contract fitted on subset.
    contract=fit_contract(inventory,{'inner_train':args.cases},base)
    def build(c):
        case=load_case(paths[c]);positive=inventory[c]['positives'][0]
        distance=ndi.distance_transform_edt(case.label!=2,sampling=case.spacing)
        negative=np.argwhere((case.label==1)&(distance>contract['blind_radius_mm']+np.linalg.norm(case.spacing)/2))
        if not len(negative):raise ValueError(f'No unambiguous DEBUG comparison center: {c}')
        center=negative[np.random.default_rng(42).integers(len(negative))]
        values=[context_patch(case.image,case.spacing,positive['center'],contract),context_patch(case.image,case.spacing,center,contract)]
        # Native central CT intervention; only data outside the blind may influence features.
        changed=case.image.copy();anchor=np.asarray(positive['center'])
        half=np.ceil(contract['blind_radius_mm']/case.spacing).astype(int)
        start=np.maximum(0,anchor-half);stop=np.minimum(case.image.shape,anchor+half+1)
        slices=tuple(slice(int(a),int(b)) for a,b in zip(start,stop))
        grid=np.indices(tuple(stop-start)).transpose(1,2,3,0)+start
        mask=np.linalg.norm((grid-anchor)*case.spacing,axis=-1)<=contract['blind_radius_mm']
        view=changed[slices];view[mask]=999999
        intervened=context_patch(changed,case.spacing,positive['center'],contract)
        np.testing.assert_array_equal(values[0],intervened)
        return values,dict(case=c,positive=positive,comparison_center=center.tolist(),native_blind_intervention_exact=True)
    with ThreadPoolExecutor(max_workers=3) as pool:built=list(pool.map(build,args.cases))
    patches=torch.from_numpy(np.stack([p for values,_ in built for p in values]))
    with (root/'debug_patches.npy').open('xb') as stream:np.save(stream,patches.numpy(),allow_pickle=False)
    model=PromptGraphModel(cfg,base,contract).cuda().eval()
    write_new(root/'inputs.json',dict(debug=True,input_contract=contract,actual_patients=3,actual_graphs=6,
              input_shape=list(patches.shape),nodes_per_graph=len(model.local.grid),edges_per_graph=model.local.edge.shape[1],
              parameters=sum(p.numel() for p in model.parameters()),input_audit=[a for _,a in built],raw_inventory=rows))
    print({'stage':'real_inputs_ready','nodes_per_graph':len(model.local.grid),'edges_per_graph':model.local.edge.shape[1]},flush=True)
    embeds=[]
    with torch.no_grad(),torch.autocast('cuda',dtype=torch.bfloat16):
        for chunk in patches.split(2):embeds.append(model.local(chunk.cuda()).float())
    memory=dict(embeddings=torch.cat(embeds),owners=torch.tensor([0,0,1,1,2,2],device='cuda'),
                classes=torch.tensor([1,0,1,0,1,0],device='cuda'),patient_groups=args.cases,case_ids=args.cases)
    support=support_for_query(memory,args.cases[2]);reports=[]
    model.train()
    for count in (2,4):
        # Same two real queries repeated for batch-4 throughput, not four independent patients.
        query=patches[4:6].repeat(count//2,1,1,1,1).cuda()
        targets=torch.tensor([1,0],device='cuda').repeat(count//2)
        model.zero_grad(set_to_none=True);torch.cuda.reset_peak_memory_stats()
        start=time.perf_counter()
        with torch.autocast('cuda',dtype=torch.bfloat16):out=model(query,*support);loss=supervised_loss(out,targets)
        torch.cuda.synchronize();forward_seconds=time.perf_counter()-start
        backward_start=time.perf_counter();loss.backward();torch.cuda.synchronize()
        backward_seconds=time.perf_counter()-backward_start
        missing=[n for n,p in model.named_parameters() if p.grad is None]
        if missing:raise AssertionError(f'No gradient: {missing}')
        if not all(torch.isfinite(p.grad).all() for p in model.parameters()):raise FloatingPointError('Nonfinite gradient')
        elapsed=time.perf_counter()-start
        row=dict(physical_batch=count,effective_batch=count,gradient_accumulation=1,
                 seconds=elapsed,query_graphs_per_second=count/elapsed,peak_vram_bytes=torch.cuda.max_memory_allocated(),
                 forward_seconds=forward_seconds,backward_seconds=backward_seconds,
                 execution_chunk_nodes=model.local.execution_chunk_nodes[(count,'cuda:0')],
                 finite_all_parameter_gradients=True,repeated_queries_for_batch_probe=count>2)
        reports.append(row);print(row,flush=True)
        write_new(root/f'batch_{count}.json',row)
        if row['peak_vram_bytes']>torch.cuda.get_device_properties(0).total_memory*.9:
            raise MemoryError('DEBUG probe exceeds physical VRAM reserve; no WDDM paging accepted as successful calibration')
        del query,targets,out,loss
        model.zero_grad(set_to_none=True);torch.cuda.empty_cache()
    optimizer=torch.optim.AdamW(model.parameters(),lr=1e-4)
    before={n:p.detach().clone() for n,p in model.named_parameters()}
    with torch.autocast('cuda',dtype=torch.bfloat16):out=model(patches[4:6].cuda(),*support);loss=supervised_loss(out,torch.tensor([1,0],device='cuda'))
    loss.backward();optimizer.step();torch.cuda.synchronize()
    groups=['local.dense','local.project','local.pool_gate','label_seed']+[f'local.blocks.{i}' for i in range(3)]+[f'l1.{i}' for i in range(2)]+[f'l2.{i}' for i in range(2)]
    updates={prefix:any(not torch.equal(before[n],p) for n,p in model.named_parameters() if n.startswith(prefix)) for prefix in groups}
    if not all(updates.values()):raise AssertionError(updates)
    model.eval()
    with torch.no_grad(),torch.autocast('cuda',dtype=torch.bfloat16):
        state=model.prepare_support(*support);labels=state['labels'].clone()
        query=model.local(patches[4:6].cuda());out=model.predict_embeddings(query,state)
        original=out['logits'].clone()
        supervised_loss(out,torch.tensor([0,1],device='cuda'))
        torch.testing.assert_close(original,model.predict_embeddings(query,state)['logits'],rtol=0,atol=0)
        model.predict_embeddings(query+5,state)
        torch.testing.assert_close(labels,state['labels'],rtol=0,atol=0)
    write_new(root/'result.json',dict(debug=True,actual_CT=True,actual_patients=3,actual_graphs=6,
              input_contract_scope='DEBUG-only fitted on declared cases; not usable as production cache',
              benchmarks=reports,parameter_groups_updated=updates,query_targets_cannot_change_forward=True,
              queries_cannot_mutate_support=True,full_model_width_depth_and_graph_rules=True,
              full_training=False,full_evaluation=False,checkpoint_written=False,resources=snapshot()))
    print(str(root/'result.json'),flush=True)

if __name__=='__main__':main()
