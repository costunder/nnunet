"""Measured physical batches, complete-epoch query coverage and frozen support provenance."""
from pathlib import Path
import time
import math
import os
import numpy as np
import torch
from torch.utils.data import DataLoader, Subset
from hiercp.preparation_runtime import snapshot
from .contracts import write_new, safe_new_root, source_identity, sha
from .data import ContextDataset, support_for_query
from .model import PromptGraphModel, supervised_loss
from . import PIPELINE_VERSION

def require_device(device):
    if device != 'cuda' or not torch.cuda.is_available():
        raise RuntimeError('CUDA required; no automatic CPU fallback')
    if torch.cuda.device_count() != 1:
        raise RuntimeError('This measured runner targets the single-GPU project host; multi-GPU execution must be configured explicitly')

def configure_runtime(base, seed):
    os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
    torch.manual_seed(seed)
    torch.backends.cuda.matmul.allow_tf32 = base['runtime']['allow_tf32']
    torch.backends.cudnn.allow_tf32 = base['runtime']['allow_tf32']
    torch.backends.cudnn.benchmark = base['runtime']['cudnn_benchmark']
    torch.use_deterministic_algorithms(base['runtime']['deterministic'])

def loader(dataset, batch, workers, *, indices=None):
    data = dataset if indices is None else Subset(dataset, indices)
    options = dict(batch_size=batch, shuffle=False, num_workers=workers, pin_memory=True)
    if workers:
        options.update(persistent_workers=True, prefetch_factor=1)
    return DataLoader(data, **options)

@torch.no_grad()
def build_memory(model, dataset, batch, workers):
    training = model.training; model.eval()
    values = []
    for patches, indices in loader(dataset, batch, workers):
        with torch.autocast('cuda', dtype=torch.bfloat16):
            values.append(model.local(patches.cuda(non_blocking=True)).float().cpu())
    cases = sorted(set(r['case_id'] for r in dataset.rows)); lookup = {c: i for i, c in enumerate(cases)}
    memory = dict(embeddings=torch.cat(values).cuda(),
                  owners=torch.tensor([lookup[r['case_id']] for r in dataset.rows], device='cuda'),
                  classes=torch.tensor([r['target'] for r in dataset.rows], device='cuda'),
                  case_ids=cases,
                  patient_groups=[dataset.meta['identities']['cases'][c]['patient_group'] for c in cases])
    model.train(training)
    return memory

def calibrate(model, dataset, memory, cfg, output):
    """Real full-graph forward/backward probes; no weights updated or data truncated."""
    by_case = {}
    for i, row in enumerate(dataset.rows): by_case.setdefault(row['case_id'], []).append(i)
    # All patches have the exact same graph cardinality. Use the largest query case.
    indices = max(by_case.values(), key=len)
    patches = torch.stack([dataset[i][0] for i in indices])
    group = dataset.rows[indices[0]]['patient_group']
    support = support_for_query(memory, group)
    with torch.autocast('cuda', dtype=torch.bfloat16): cluster_plan = model.fit_support_clusters(*support)
    reports = []; candidates = [1]
    while candidates[-1] < len(indices): candidates.append(min(2*candidates[-1], len(indices)))
    model.train()
    for count in candidates:
        torch.cuda.empty_cache(); torch.cuda.reset_peak_memory_stats()
        query = targets = loss = None
        try:
            query = patches[:count].cuda()
            targets = torch.tensor([dataset.rows[i]['target'] for i in indices[:count]], device='cuda')
            start = time.perf_counter()
            for _ in range(cfg['batch_calibration_repeats']):
                model.zero_grad(set_to_none=True)
                with torch.autocast('cuda', dtype=torch.bfloat16):
                    loss = supervised_loss(model(query, *support, cluster_plan=cluster_plan), targets)
                loss.backward()
                torch.cuda.synchronize()
            elapsed = time.perf_counter()-start
            peak = torch.cuda.max_memory_allocated()
            reports.append(dict(physical_batch=count, graphs_per_second=count*cfg['batch_calibration_repeats']/elapsed,
                                peak_vram_bytes=peak, seconds=elapsed,
                                accepted=peak < torch.cuda.get_device_properties(0).total_memory*cfg['max_vram_fraction']))
            del loss, query, targets
        except torch.cuda.OutOfMemoryError as error:
            reports.append(dict(physical_batch=count, accepted=False, error=str(error),
                                policy='Only measured physical batch changes; architecture and full graph unchanged'))
            query = targets = loss = None
            model.zero_grad(set_to_none=True); torch.cuda.empty_cache()
            break
    model.zero_grad(set_to_none=True)
    write_new(Path(output)/'batch_calibration.json', reports)
    valid = [r for r in reports if r['accepted']]
    if not valid: raise MemoryError('No full-graph training batch fits; inspect calibration, do not reduce model')
    batch = max(valid, key=lambda r: r['graphs_per_second'])['physical_batch']
    worker_reports = []
    for workers in cfg['worker_candidates']:
        start = time.perf_counter(); count = 0
        for value, _ in loader(dataset, batch, workers): count += len(value)
        worker_reports.append(dict(workers=workers, samples=count, seconds=time.perf_counter()-start))
    write_new(Path(output)/'worker_calibration.json', worker_reports)
    workers = min(worker_reports, key=lambda r: r['seconds'])['workers']
    return batch, workers, reports

def grouped_indices(dataset, rng=None):
    groups = {}
    for i, row in enumerate(dataset.rows): groups.setdefault(row['patient_group'], []).append(i)
    names = list(groups)
    if rng is not None: rng.shuffle(names)
    for group in names:
        indices = np.asarray(groups[group])
        if rng is not None: rng.shuffle(indices)
        yield group, indices.tolist()

class PatientBatchSampler:
    """One persistent loader; all batches retain a single query patient group."""
    def __init__(self, dataset, batch, seed=None):
        self.dataset, self.batch, self.seed, self.epoch = dataset, batch, seed, 0
    def __iter__(self):
        rng = None if self.seed is None else np.random.default_rng(self.seed+self.epoch)
        for _, indices in grouped_indices(self.dataset, rng):
            for begin in range(0, len(indices), self.batch):
                yield indices[begin:begin+self.batch]
    def __len__(self):
        return sum(math.ceil(len(ids)/self.batch) for _, ids in grouped_indices(self.dataset))

def grouped_loader(dataset, batch, workers, seed=None):
    sampler = PatientBatchSampler(dataset, batch, seed)
    kwargs = dict(batch_sampler=sampler, num_workers=workers, pin_memory=True)
    if workers: kwargs.update(persistent_workers=True, prefetch_factor=1)
    return DataLoader(dataset, **kwargs), sampler

@torch.no_grad()
def evaluate(model, dataset, memory, batch, workers):
    model.eval(); logits = []; targets = []
    iterator, _ = grouped_loader(dataset, batch, workers)
    last_group = None
    for patches, ids in iterator:
        group = dataset.rows[int(ids[0])]['patient_group']
        if group != last_group:
            support = support_for_query(memory, group)
            with torch.autocast('cuda', dtype=torch.bfloat16): state = model.prepare_support(*support)
            last_group = group
        with torch.autocast('cuda', dtype=torch.bfloat16):
            output = model.predict_embeddings(model.local(patches.cuda(non_blocking=True)), state)
        logits.append(output['logits'].cpu())
        targets.extend(dataset.rows[i]['target'] for i in ids.tolist())
    logits = torch.cat(logits); targets = torch.tensor(targets)
    prob = logits.softmax(-1)[:, 1].numpy(); y = targets.numpy()
    from scipy.stats import rankdata
    positive = int(y.sum()); negative = len(y)-positive
    if not positive or not negative: raise ValueError('Both validation observation classes required')
    auc = float((rankdata(prob)[y == 1].sum()-positive*(positive+1)/2)/(positive*negative))
    return dict(observation_cross_entropy=float(torch.nn.functional.cross_entropy(logits, targets)),
                observation_accuracy=float((logits.argmax(-1) == targets).float().mean()),
                observation_auroc=auc, samples=len(y), positives=positive, negatives=negative,
                scope='constructed observation task; not tumor incidence probability or segmentation performance')

def train(cache, output, cfg, base):
    configure_runtime(base, cfg['seed']); require_device('cuda')
    root = safe_new_root(output)
    trainset = ContextDataset(cache, 'inner_train'); valset = ContextDataset(cache, 'inner_val')
    if trainset.meta['config'] != cfg or trainset.meta['base'] != base:
        raise ValueError('Cache/model configuration differs')
    contract = trainset.meta['input_contract']
    model = PromptGraphModel(cfg, base, contract).cuda()
    # Explicit bootstrap only: actual memory precedes measured batch calibration.
    memory = build_memory(model, trainset, 2, 0)
    batch, workers, measurements = calibrate(model, trainset, memory, cfg, root)
    counts = torch.bincount(memory['classes'], minlength=2).float()
    if bool((counts == 0).any()): raise ValueError('Both training classes required')
    weights = counts.sum()/(2*counts)
    optimizer = torch.optim.AdamW(model.parameters(), lr=base['training']['lr'], weight_decay=base['training']['weight_decay'])
    epochs = cfg['gnn_epochs']; best = math.inf; best_path = None
    total_steps = epochs*sum(math.ceil(len(ids)/batch) for _, ids in grouped_indices(trainset))
    report = dict(format=PIPELINE_VERSION, config=cfg, base=base, input_contract=contract,
                  parameters=sum(p.numel() for p in model.parameters()), trainable_parameters=sum(p.numel() for p in model.parameters() if p.requires_grad),
                  input_shape=[batch, 1, 48, 48, 48], nodes_per_graph=len(model.local.grid),
                  edges_per_graph=model.local.edge.shape[1], physical_batch=batch, gradient_accumulation=1,
                  effective_batch=batch, epochs=epochs, optimization_steps=total_steps,
                  train_samples=len(trainset), used_train_samples=len(trainset), train_usage_ratio=1.0,
                  val_samples=len(valset), workers=workers, persistent_workers=workers > 0,
                  prefetch_factor=1 if workers else None, pin_memory=True, precision='bfloat16_autocast_FP32_loss',
                  gpu=torch.cuda.get_device_name(), gpu_count=torch.cuda.device_count(), resources=snapshot(),
                  support_memory='complete inner_train, detached embeddings refreshed every epoch; all queries train L0',
                  debug=False, subset=False, peak_vram=max(r.get('peak_vram_bytes', 0) for r in measurements))
    write_new(root/'training_started.json', report)
    step = 0; previous_clusters = {}
    query_loader, sampler = grouped_loader(trainset, batch, workers, cfg['seed'])
    for epoch in range(epochs):
        memory = build_memory(model, trainset, batch, workers)
        model.train(); seen = set(); begin = time.perf_counter(); losses = []; alignment_losses = []
        cluster_audits = {}
        sampler.epoch = epoch; last_group = None
        for patches, ids in query_loader:
            group = trainset.rows[int(ids[0])]['patient_group']
            if group != last_group:
                support = support_for_query(memory, group); last_group = group
                with torch.autocast('cuda', dtype=torch.bfloat16): cluster_plan = model.fit_support_clusters(*support)
                # Epoch-to-epoch stability is a diagnostic, never a query-label
                # criterion for selecting prototypes or cluster count.
                assignment = cluster_plan['assignment'].cpu().numpy()
                active_classes = (cluster_plan['active']%2).cpu().numpy()
                stability = None
                if group in previous_clusters:
                    from sklearn.metrics import adjusted_rand_score
                    old = previous_clusters[group]
                    stability = [float(adjusted_rand_score(old[active_classes==c],assignment[active_classes==c])) for c in (0,1)]
                previous_clusters[group] = assignment.copy()
                cluster_audits[group] = dict(**cluster_plan['audit'],
                    support_patient_groups=sorted(set(memory['patient_groups'])-{group}),
                    excluded_query_patient_group=group, classwise_previous_epoch_ARI=stability)
            targets = torch.tensor([trainset.rows[i]['target'] for i in ids.tolist()], device='cuda')
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast('cuda', dtype=torch.bfloat16):
                output_ = model(patches.cuda(non_blocking=True), *support, cluster_plan=cluster_plan)
                loss = supervised_loss(output_, targets, weights)
            if not torch.isfinite(loss): raise FloatingPointError('Nonfinite loss')
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), base['training']['grad_clip'], error_if_nonfinite=True)
            optimizer.step(); step += 1; seen.update(ids.tolist()); losses.append(loss.detach())
            alignment_losses.append(output_['alignment_loss'].detach())
        if seen != set(range(len(trainset))): raise RuntimeError('Incomplete epoch coverage')
        memory = build_memory(model, trainset, batch, workers)
        metrics = evaluate(model, valset, memory, batch, workers)
        elapsed = time.perf_counter()-begin
        row = dict(epoch=epoch+1, optimization_steps=step, train_loss=float(torch.stack(losses).mean()),
                   alignment_loss=float(torch.stack(alignment_losses).mean()), cluster_episodes=cluster_audits,
                   validation=metrics, all_train_queries_visited=len(seen), seconds=elapsed,
                   query_graphs_per_second=len(seen)/elapsed, peak_vram=torch.cuda.max_memory_allocated(), resources=snapshot())
        write_new(root/f'epoch_{epoch+1:03d}.json', row); print(row, flush=True)
        if metrics['observation_cross_entropy'] < best:
            best = metrics['observation_cross_entropy']; best_path = root/f'weights_epoch_{epoch+1:03d}.pt'
            with best_path.open('xb') as stream: torch.save(dict(state_dict=model.state_dict(), epoch=epoch+1), stream)
    best_state = torch.load(best_path, map_location='cpu', weights_only=True)
    model.load_state_dict(best_state['state_dict']); memory = build_memory(model, trainset, batch, workers)
    memory = {k: v.cpu() if torch.is_tensor(v) else v for k, v in memory.items()}
    meta = trainset.meta
    payload = dict(format=PIPELINE_VERSION, debug=False, completed_epochs=epochs, selected_epoch=best_state['epoch'],
                   state_dict={k: v.cpu() for k, v in model.state_dict().items()}, config=cfg, base=base,
                   input_contract=contract, split=meta['split'], identities=meta['identities'], memory=memory,
                   donor_pool=meta['donor_pool'], raw_records=meta['raw_records'], physical_batch=batch, workers=workers,
                   source_identity=source_identity(), cache_sha256=sha(cache), optimization_steps=step)
    with (root/'checkpoint.pt').open('xb') as stream: torch.save(payload, stream)
    write_new(root/'training_complete.json', dict(format=PIPELINE_VERSION, epochs=epochs, selected_epoch=best_state['epoch'],
              checkpoint_sha256=sha(root/'checkpoint.pt'), segmentation_training_executed=False))
    return root/'checkpoint.pt'
