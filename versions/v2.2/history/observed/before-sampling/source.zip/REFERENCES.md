# References — HierCP / nnU-Net

갱신: 2026-09-22, v2.22 r2. 논문에서 가져온 개념, 실제 구현, 프로젝트에서 새로 정한 조건을 분리한다. 논문 인용은 본 데이터의 소형 종양 성능을 입증하지 않는다. 현재 설계는 [L2 군집 정렬](docs/pipeline_v222_cluster_r2.md), 전체 흐름은 [파이프라인](docs/pipeline_v222.md)을 따른다.

## 현재 구현과 연결된 근거

| ID | 서지·원문 | 실제 연결 | 원문과 다른 점 / 적용 범위 |
|---|---|---|---|
| R1 — SwAV | Caron, Misra, Mairal, Goyal, Bojanowski, Joulin. **Unsupervised Learning of Visual Features by Contrasting Cluster Assignments**. NeurIPS 2020. [논문](https://arxiv.org/abs/2006.09882), [공식 코드](https://github.com/facebookresearch/swav) | 정규화된 prototype과 assignment 예측이라는 설계 참고. Appendix D의 DeepCluster-v2도 참고. | **SwAV 재현 아님.** 원문의 동일 영상 view 간 swapped prediction, Sinkhorn 균등 배정, multi-crop, 학습 가능한 prototype 파라미터를 구현했다고 주장하지 않는다. 현재 중심은 support의 군집별 평균이며 별도 Parameter가 아니다. SwAV가 K를 자동 선택한다는 주장도 하지 않는다. |
| R2 — DeepCluster | Caron, Bojanowski, Joulin, Douze. **Deep Clustering for Unsupervised Learning of Visual Features**. ECCV 2018. [논문](https://arxiv.org/abs/1807.05520), [공식 코드](https://github.com/facebookresearch/deepcluster) | 표현에서 군집 pseudo-target을 만들고 이를 고정한 상태에서 표현을 학습하는 교대 절차. `fit_support_clusters`, `alignment_loss`. | 원문 k-means를 그대로 쓰지 않는다. 본 구현은 관측 클래스별 cosine average-linkage, 환자 episode별 재계산이다. 의료 관측 클래스, query 환자 제외, loss 결합은 프로젝트 설계다. |
| R3 — PRODIGY | Huang, Ren, Chen, Kržmanc, Zeng, Liang, Leskovec. **PRODIGY: Enabling In-context Learning Over Graphs**. NeurIPS 2023. [논문](https://arxiv.org/abs/2305.12600), [최종 PDF](https://cs.stanford.edu/~jure/pubs/prodigy-neurips23.pdf), [공식 구현](https://github.com/snap-stanford/prodigy/blob/main/models/metaGNN.py) | L1 data–label prompt graph, 알려진 support 관계와 미지 query 관계 구분, query로부터 support로 정답을 보내지 않는 구조. `RelationLayer`, `encode_support`, `predict_embeddings`. | CT 문맥을 data로 삼는 것, 두 관측 클래스, 128차원, L2 환자 간 군집 정렬은 본 프로젝트의 적용 설계다. PRODIGY가 이 의료 L2를 제안했다고 쓰지 않는다. |
| R4 — GATv2 | Brody, Alon, Yahav. **How Attentive are Graph Attention Networks?** ICLR 2022. [논문](https://arxiv.org/abs/2105.14491), [공식 코드](https://github.com/tech-srl/how_attentive_are_gats) | L0 공간 GNN의 PyG `GATv2Conv`. 전체 그래프 계산을 streaming하는 `chunked_gat`는 PyG 출력·입력/파라미터 gradient와 대조한다. | L1은 별도 edge-conditioned relation attention이다. 모든 attention 층을 GATv2라고 부르지 않는다. 3층/128/4 heads는 기존 프로젝트 설정을 계승했다. |
| R5 — Silhouette | Peter J. Rousseeuw. **Silhouettes: A graphical aid to the interpretation and validation of cluster analysis**. Journal of Computational and Applied Mathematics 20, 53–65, 1987. [DOI](https://doi.org/10.1016/0377-0427(87)90125-7), [구현 정의](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.silhouette_score.html) | `select_partition`에서 support 표현의 군집 내/군집 간 cosine 거리로 후보 K를 비교한다. | 모든 비단독 군집 cut을 비교하고 양의 최고 점수, 동점은 작은 K, 해상 불충분 시 K=1이라는 선택 규칙은 프로젝트 설계다. Silhouette는 실제 생물학적 아형이나 최적 K의 증명이 아니다. |
| R6 — Hierarchical clustering | Daniel Müllner. **Modern hierarchical, agglomerative clustering algorithms**. 2011. [논문](https://arxiv.org/abs/1109.2378), [SciPy linkage 공식 문서](https://docs.scipy.org/doc/scipy/reference/generated/scipy.cluster.hierarchy.linkage.html) | `scipy.cluster.hierarchy.linkage(method='average')`, `cut_tree`. 정규화된 환자 label 간 cosine 거리 사용. | 논문의 모든 linkage 방법을 사용하는 것이 아니다. Average-linkage를 택한 이유는 고정 K/무작위 초기 중심 없이 전체 계층의 cut을 비교하기 위해서다. CT에서 우수하다는 실험 근거는 아직 없다. |
| R7 — nnU-Net | Isensee, Jaeger, Kohl, Petersen, Maier-Hein. **nnU-Net: a self-configuring method for deep learning-based biomedical image segmentation**. Nature Methods 18, 203–211, 2021. [DOI](https://doi.org/10.1038/s41592-020-01008-z), [공식 nnU-Net v2 코드](https://github.com/MIC-DKFZ/nnUNet) | 분할 학습·추론·기본 native loader 및 사용자 정의 online CP trainer의 기반. | 이 논문이 GNN 위치 선택, 본 관측 과제, 군집 loss 또는 CP 성능을 보증하는 것은 아니다. |

## 과거 검토·배경 자료 — 현재 특징으로 재도입하지 않음

| ID | 자료 | 검토 목적과 현재 상태 |
|---|---|---|
| R8 | Landrieu & Simonovsky. **Large-scale Point Cloud Semantic Segmentation with Superpoint Graphs**. CVPR 2018. [논문](https://arxiv.org/abs/1711.09869) | 그래프/기하 특징 선행 사례를 검토했다. 해당 논문의 점군 특징을 CT에 임의로 결합하는 근거로 쓰지 않는다. 현재 수작업 특징 묶음 미사용. |
| R9 | Qi et al. **PointNet++: Deep Hierarchical Feature Learning on Point Sets in a Metric Space**. NeurIPS 2017. [논문](https://arxiv.org/abs/1706.02413) | 국소 공간 이웃과 좌표 활용 비교 자료. 현재 PointNet++ 미구현, 상대 좌표를 CNN 특징에 concat하지 않음. |
| R10 | Wang et al. **Dynamic Graph CNN for Learning on Point Clouds**. [논문](https://arxiv.org/abs/1801.07829) | EdgeConv 및 동적 이웃 비교 자료. 현재 DGCNN/EdgeConv 미구현. |
| R11 | Wickramasinghe et al. **Voxel2Mesh: 3D Mesh Model Generation from Volumetric Data**. [논문](https://arxiv.org/abs/1912.03681) | CNN 영상 특징을 그래프 계열 처리에 전달하는 개념 참고. 현재 mesh decoder/mesh supervision 미구현. |
| R12 | **Image Biomarker Standardisation Initiative (IBSI)**. [공식 특징 정의](https://ibsi.readthedocs.io/en/latest/03_Image_features.html#intensity-based-statistical-features) | 과거 통계 특징 정의 감사에 참고했다. 공식 정의가 있다는 것과 본 과제에서 유효하다는 것은 다르다. 폐기된 통계 묶음을 복구하지 않는다. |

과거 감사 문서: [feature_evidence_audit_20260922.md](docs/feature_evidence_audit_20260922.md). 위 자료를 최신 구현 모듈인 것처럼 열거하지 않는다.

## Copy-Paste 적용 확률 확인 (2026-09-22)

- **R13 — TumorCP: A Simple but Effective Object-Level Data Augmentation for Tumor Segmentation.** [원문 §3.2](https://arxiv.org/html/2107.09843#S3.SS2). 저자들은 모든 실험에서 CP 적용 확률 `p_cp=0.8`을 사용했다. CP가 발동했을 때 개별 object-level 변환은0.5이고, intra/inter를 결합한 설정의 선택 비율도 각각0.5다. 세 확률을 혼동하면 안 된다. KiTS19 실험 설정이며 현재 간 CT/GNN에서80%가 최적이라는 증거는 아니다. 기존 사용자 Basic CP를 TumorCP 재현이라고 바꾸어 부르지 않는다.
- **R14 — Ghiasi et al., Simple Copy-Paste is a Strong Data Augmentation Method for Instance Segmentation. CVPR2021.** [원문](https://arxiv.org/abs/2012.07177). 두 영상과 복사할 객체의 무작위 부분집합을 사용한다. 객체 선택의 무작위성과 샘플별 CP 실행 gate는 서로 다른 개념이다. 이번 원문 확인만으로 모든 CP 방법의 공통 적용 확률을50%나100%로 정할 수 없다.
- 설치된 nnU-Net의 `get_training_transforms` 확인: 회전0.2, scaling0.2, Gaussian noise0.1, 밝기0.15, contrast0.15, 일반 gamma0.3. 각 transform의 바깥 적용 확률이며 채널별 추가 gate가 있는 다른 증강과 구분한다. 증강 하나만 택하는 확률분포가 아니므로 합을1로 맞추지 않는다.
- 본 프로젝트 원본 Basic CP는 별도의 확률 gate 없이 매 방문 CP를 시도한다. 변경 전 v2.22의0.5는 프로젝트 계승값이며 TumorCP 논문의 `p_cp`를 그대로 옮긴 설정도, 검증된 최적값도 아니다. 이후 사용자가 양쪽0.8 비교를 명시적으로 승인해 Basic CP80 변형과 v2.22의 설정을0.8로 맞췄다. 이 값의 현재 데이터 최적성을 주장하지 않는다. 원본1.0 트레이너는 보존했다.

## 문맥 기반 배치 검토 (2026-09-23)

- **R15 — Dvornik, Mairal, Schmid. Modeling Visual Context is Key to Augmenting Object Detection Datasets. ECCV2018.** [원문](https://openaccess.thecvf.com/content_ECCV_2018/html/NIKITA_DVORNIK_Modeling_Visual_Context_ECCV_2018_paper.html), [저자 코드](https://github.com/dvornikita/context_aug). 객체 주변 문맥을 학습해 copy-paste 위치를 고르는 선행연구다. 이번 학습 목표 감사에서 검토했으며 CT/GNN 또는 원본 CT 입력 수정안의 효능이 입증된 것으로 인용하지 않는다. 현재 구현을 해당 논문 재현이라고 부르지 않는다. 상세 `docs/v222_raw_ct_proposal_20260923.md`.

## 코드 출처와 프로젝트 고유 선택

- **R16 — Wang et al. Dynamic Graph CNN for Learning on Point Clouds.** [원문](https://arxiv.org/abs/1801.07829). L0 수정 검토의 근거: 매 layer의 현재 특징으로 kNN 관계를 갱신한다. 기존 r3에 적용된 방법이 아니며 CT CP 효능 근거도 아니다.
- **R17 — Han et al. Vision GNN: An Image is Worth Graph of Nodes.** [원문](https://arxiv.org/abs/2206.00272). 영상 patch 특징을 노드로 사용하는 설계 근거. 원문의 positional encoding과 graph operator를 포함해 재현했다고 주장하지 않는다. [미적용 L0 수정 명세](docs/v222_l0_feature_graph_proposal_20260923.md).

- **Basic CP**의 기준은 저장된 사용자 원본과 [원본 비교 기록](docs/original_basic_cp_online.md), [보존 구현](basic_cp_online/reference.py)이다. 이를 출처 확인 없이 다른 Copy-Paste 논문의 재현으로 바꾸어 인용하지 않는다.
- L2의 **관측 클래스별 군집**, **query 환자 그룹 전체 제외**, **군집당 최소 2명의 독립 환자라는 submode 조건**, **silhouette cut 선택**, **query CE + alignment CE의 동등 가중치**, **군집 환자 수 가중 log-sum-exp 점수**는 프로젝트 구현 선택이다. 위 논문이 이 조합을 의료 문제에서 검증했다는 근거는 없다.
- Temperature 0.2, hidden 128, L0/L1/L2 깊이 3/2/2와 4 heads는 기존 계약 유지다. SwAV 원문의 값을 임의 축소한 결과가 아니다.
- Source는 `hiercp_v222/model.py`, `clustering.py`, `training.py`, `scoring.py`에 연결된다. 참고문헌 추가만으로 구현 완료나 성능 개선으로 기록하지 않는다.

## 작업 완료 체크리스트

- [x] 서버 또는 원격 세션 종료 위험이 있는 명령을 사용하지 않았다.
- [x] 사용자 파일과 기존 결과를 파괴적으로 변경하지 않았다.
- [x] 모델 깊이와 너비를 편의상 축소하지 않았다.
- [x] 그래프와 데이터 규모를 편의상 축소하지 않았다.
- [x] 숨겨진 subset, cap, fast mode를 추가하지 않았다.
- [x] physical batch size와 병렬화 가능성을 실제로 검토했다.
- [x] GPU, CPU, RAM 활용 상태를 측정하거나 확인했다.
- [x] 이번 변경에서 OOM은 없었으며 모델 축소를 적용하지 않았다.
- [x] 디버그 설정과 최종 설정을 분리했다.
- [x] dummy, placeholder, random fallback을 사용하지 않았다. 합성 검사는 DEBUG로 구분한다.
- [x] 핵심 모듈이 forward, loss, gradient와 optimizer에 연결되어 있다.
- [x] 실제 실행 설정과 변경 사항을 명확하게 보고했다.
- [x] smoke test와 전체 학습 또는 전체 평가를 구분해서 보고했다.
