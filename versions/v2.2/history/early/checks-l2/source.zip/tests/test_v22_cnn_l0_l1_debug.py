"""DEBUG: synthetic wiring/geometry tests, never medical performance results."""
import ast
import copy
import tempfile
import unittest
import zipfile
from pathlib import Path
import numpy as np
import torch
from torch_geometric.data import HeteroData
from hiercp.schema import LOCAL_NODE_TYPES,LOCAL_EDGE_TYPES,graph_config_from_dict
from hiercp_v22.contracts import load_config,verify_v1,validate_encoder_config
from hiercp_v22.data import collate,local_record,materialize,sources
from hiercp_v22.model import L0L1Model

ROOT=Path(__file__).resolve().parents[1]

def items(count=4):
    generator=torch.Generator().manual_seed(72)
    out=[]
    for i in range(count):
        graph=HeteroData()
        for kind in LOCAL_NODE_TYPES:
            graph[kind].num_nodes=6
            graph[kind].grid=torch.rand(6,3,generator=generator)*1.8-.9
            # Each structural shell is both present and absent across graphs.
            graph[kind].shell_id=torch.full((6,),i%3,dtype=torch.long)
        for edge in LOCAL_EDGE_TYPES:
            graph[edge].edge_index=torch.cartesian_prod(torch.arange(6),torch.arange(6)).T.contiguous()
        source=torch.randn(1,48,48,48,generator=generator).clamp(-1,1)
        target=torch.randn(1,48,48,48,generator=generator).clamp(-1,1)
        out.append(((graph,source,target),i))
    return out

def debug_probe(output):
    """Non-production differentiability probe; not a CP/Full training objective."""
    terms=[]
    for key in ('embeddings','labels','assignment'):
        value=output[key].float()
        weights=torch.linspace(.1,1.,value.numel(),device=value.device).reshape(value.shape)
        terms.append((value*weights).sum()/value.numel())
    return sum(terms)

class CNNOnlyL0L1Debug(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cfg,cls.base=load_config();cls.threads=torch.get_num_threads();torch.set_num_threads(4)
    @classmethod
    def tearDownClass(cls):torch.set_num_threads(cls.threads)
    def model(self):return L0L1Model(self.cfg,self.base,patient_ids=['A','B','C'])

    def test_preserved_versions_and_l1_exact_architecture(self):
        verify_v1()
        with zipfile.ZipFile(ROOT/'versions/v2.2/before_cnn_only_r3_20260922/source.zip') as z:
            old=ast.parse(z.read('hiercp_v22/model.py').decode())
        new=ast.parse((ROOT/'hiercp_v22/model.py').read_text())
        for name in ('Residual','PatientTaskGraph'):
            get=lambda tree:ast.dump(next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==name))
            self.assertEqual(get(old),get(new))
        self.assertEqual((self.base['model']['hidden_dim'],self.base['model']['local_layers'],self.cfg['task_layers']),(128,3,2))
        self.assertEqual((self.cfg['gnn_epochs'],self.cfg['nnunet_epochs'],self.cfg['candidate_count']),(40,250,128))

    def test_input_contract_and_no_statistical_parameters(self):
        model=self.model();convs=[m for m in model.modules() if isinstance(m,torch.nn.Conv3d)]
        self.assertEqual(convs[0].in_channels,1)
        self.assertTrue(all(layer[0].in_features==32 for layer in model.local.project.values()))
        self.assertFalse(any('decoder' in n or 'alignment' in n for n,_ in model.named_parameters()))
        self.assertTrue(all(p.requires_grad for p in model.parameters()))
        self.assertTrue(all(conv.lin_edge is None for block in model.local.blocks for conv in block.conv.convs.values()))
        for field,value in [('cnn_input_channels',5),('edge_attribute_dim',10),('node_auxiliary_feature_dim',3)]:
            with self.assertRaises(ValueError):validate_encoder_config(dict(self.cfg,**{field:value}))

    def test_ct_changes_output_and_batched_equals_individual(self):
        torch.manual_seed(1);model=self.model().eval();data=items()
        with torch.no_grad():
            batched=model.encode_local(collate(data))
            singles=torch.cat([model.encode_local(collate([item])) for item in data])
            altered=collate(data);altered.target_patches=-altered.target_patches
            different=model.encode_local(altered)
        # FP32 convolution/reduction order varies between batch kernels.
        torch.testing.assert_close(batched,singles,rtol=5e-5,atol=1e-5)
        self.assertGreater(float((batched-different).abs().max()),1e-5)

    def test_handcrafted_inputs_cannot_reenter(self):
        model=self.model().eval()
        for field in ('x','observed','pos','pos_mm'):
            batch=collate(items(2));batch.graph[LOCAL_NODE_TYPES[0]][field]=torch.zeros(12,3)
            with self.assertRaisesRegex(ValueError,'unexpected node inputs'):model.encode_local(batch)
        batch=collate(items(2));batch.graph[LOCAL_EDGE_TYPES[0]].edge_attr=torch.zeros(72,4)
        with self.assertRaisesRegex(ValueError,'edge attributes'):model.encode_local(batch)
        batch=collate(items(2));batch.source_patches=batch.source_patches.repeat(1,5,1,1,1)
        with self.assertRaisesRegex(ValueError,'CT'):model.encode_local(batch)

    def test_all_parameters_receive_gradients_and_groups_update(self):
        torch.manual_seed(6);model=self.model().train();batch=collate(items())
        optimizer=torch.optim.AdamW(model.parameters(),lr=1e-4)
        before={n:p.detach().clone() for n,p in model.named_parameters()}
        output=model(batch,torch.tensor([0,0,1,2]));loss=debug_probe(output)
        loss.backward()
        self.assertEqual([n for n,p in model.named_parameters() if p.grad is None],[])
        self.assertTrue(all(torch.isfinite(p.grad).all() for p in model.parameters()))
        optimizer.step()
        groups=['local.dense_encoder.','local.project.','data_projection.','patient_labels']
        groups += [f'local.blocks.{i}.' for i in range(3)]
        groups += [f'task.to_label.{i}.' for i in range(2)]+[f'task.to_data.{i}.' for i in range(2)]
        for group in groups:self.assertTrue(any(not torch.equal(before[n],p) for n,p in model.named_parameters() if n.startswith(group)),group)

    def test_patient_isolation_queries_and_unseen_labels(self):
        model=self.model().eval();x=torch.randn(6,128);owners=torch.tensor([0,0,1,1,2,2])
        with torch.no_grad():
            original=model.encode_support(x,owners)
            altered=x.clone();altered[:2]*=3
            changed=model.encode_support(altered,owners)
            torch.testing.assert_close(original['labels'][1:],changed['labels'][1:],rtol=0,atol=0)
            saved=[v.clone() for v in original['label_history']]
            result=model.query_relations(torch.randn(3,128),torch.arange(3),original)
            torch.testing.assert_close(result.sum(-1),torch.ones(3))
            for a,b in zip(saved,original['label_history']):torch.testing.assert_close(a,b,rtol=0,atol=0)
            unseen=model.encode_support(x,owners,case_ids=['A','B','NEW'])
            self.assertEqual(unseen['labels'].shape,(3,16,128))
            self.assertNotIn('NEW',model.patient_lookup)

    def test_topology_matches_v21_and_storage_roundtrip(self):
        from hiercp.common import LoadedCase,CasePaths
        from hiercp_v2.data import local_record as old_record,materialize as old_materialize
        from hiercp_v22.storage import GraphWriter,load_record
        from hiercp_v22.training import full_inventory
        grid=np.indices((64,64,64));organ=((grid-32)**2).sum(0)<28**2
        tumor=((grid-np.array([25,30,32])[:,None,None,None])**2).sum(0)<4**2
        labels=np.zeros(organ.shape,np.uint8);labels[organ]=1;labels[tumor]=2
        image=(40+grid[0]+grid[1]*.3-grid[2]*.1).astype(np.float32)
        case=LoadedCase(CasePaths('DEBUG_GEOMETRY',Path('unused'),Path('unused')),image,labels,
                        np.eye(4),np.eye(4),None,None,np.ones(3),{}, {})
        source,_=sources(case,self.base['cache']['source_pad'],20)[0]
        old=old_record(case,source,(38,32,32),self.base)
        fresh=local_record(case,source,(38,32,32),self.base)
        oldgraph,oldsource,oldtarget=old_materialize(old)
        newgraph,newsource,newtarget=materialize(fresh)
        for branch in ('source_local','target_local'):
            for kind in fresh[branch]['nodes']:
                torch.testing.assert_close(fresh[branch]['nodes'][kind]['pos_mm'],old[branch]['nodes'][kind]['pos_mm'],rtol=0,atol=0)
            for edge in fresh[branch]['edges']:
                torch.testing.assert_close(fresh[branch]['edges'][edge],old[branch]['edges'][edge],rtol=0,atol=0)
        for kind in LOCAL_NODE_TYPES:torch.testing.assert_close(newgraph[kind].full_id,oldgraph[kind].full_id)
        for edge in LOCAL_EDGE_TYPES:torch.testing.assert_close(newgraph[edge].edge_index,oldgraph[edge].edge_index)
        torch.testing.assert_close(newsource,oldsource[:1],rtol=0,atol=0)
        torch.testing.assert_close(newtarget,oldtarget[:1],rtol=0,atol=0)
        with tempfile.TemporaryDirectory(prefix='v22_cnn_DEBUG_',dir=ROOT/'tmp') as tmp:
            self.assertTrue(Path(tmp).resolve().is_relative_to(ROOT/'tmp'))
            root=Path(tmp);writer=GraphWriter(root,minimum_free_bytes=0)
            saved=writer.write('graph.pt.gz',fresh,('case',1))
            back=materialize(load_record(root,saved['path']))
            torch.testing.assert_close(back[1],newsource)
            self.assertEqual(full_inventory(root,[dict(id='a',**saved)])[0]['bytes'],saved['bounds']['bytes'])

    def test_incomplete_full_objective_never_writes_training_outputs(self):
        from hiercp_v22.training import train
        from hiercp_v22.model import context_descriptor,prompt_loss
        from hiercp_v22.scoring import Scorer
        with tempfile.TemporaryDirectory(prefix='v22_cnn_gate_DEBUG_',dir=ROOT/'tmp') as tmp:
            self.assertTrue(Path(tmp).resolve().is_relative_to(ROOT/'tmp'))
            output=Path(tmp)/'not_created'
            with self.assertRaisesRegex(RuntimeError,'Full training objective'):train('not_read',output,self.cfg,self.base)
            self.assertFalse(output.exists())
        with self.assertRaisesRegex(RuntimeError,'retired'):context_descriptor(None)
        with self.assertRaisesRegex(RuntimeError,'Full training objective'):Scorer('not_read')

if __name__=='__main__':unittest.main()
