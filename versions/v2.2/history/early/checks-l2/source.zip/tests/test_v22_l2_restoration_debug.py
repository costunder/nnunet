"""DEBUG regression of restored L2, not evidence of medical utility."""
import ast
import unittest
import zipfile
from pathlib import Path
import torch
from hiercp_v22.contracts import load_config
from hiercp_v22.model import PromptGraphModel, transport_positive, prompt_loss
from hiercp_v22.training import attach_context
from hiercp_v22.data import collate
from test_v22_cnn_l0_l1_debug import items

ROOT=Path(__file__).resolve().parents[1]


class L2RestorationDebug(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cfg,cls.base=load_config()
        cls.threads=torch.get_num_threads();torch.set_num_threads(4)
    @classmethod
    def tearDownClass(cls):torch.set_num_threads(cls.threads)
    def model(self,local=False):
        torch.manual_seed(5)
        return PromptGraphModel(self.cfg,self.base,patient_ids=['A','B','C'],with_local=local)
    def memory(self):
        g=torch.Generator().manual_seed(29)
        return dict(case_ids=['A','B','C'],embeddings=torch.randn(9,128,generator=g),
                    owners=torch.arange(3).repeat_interleave(3),evidence=torch.tensor([1,-1,-1]*3),
                    donor_allowed=torch.ones(3,dtype=torch.bool))

    def test_archived_l2_and_transfer_preserved_exactly(self):
        with zipfile.ZipFile(ROOT/'versions/v2.2/before_cnn_only_r3_20260922/source.zip') as z:
            old=ast.parse(z.read('hiercp_v22/model.py').decode())
        new=ast.parse((ROOT/'hiercp_v22/model.py').read_text())
        for name in ('Residual','PatientTaskGraph','CrossPatientAlignment','transport_positive','observed_evidence_loss'):
            get=lambda t:ast.dump(next(n for n in t.body if getattr(n,'name',None)==name))
            self.assertEqual(get(old),get(new),name)
        m=self.model()
        self.assertEqual(len(m.alignment.layers),2)
        self.assertEqual(m.alignment.layers[0].embed_dim,128)
        self.assertEqual(m.alignment.layers[0].num_heads,4)
        self.assertFalse(any('decoder' in n for n,_ in m.named_parameters()))

    def test_full_ct_to_l2_loss_and_optimizer(self):
        m=self.model(local=True).train();batch=collate(items(6))
        owners=torch.tensor([0,0,1,1,2,2]);evidence=torch.tensor([1,-1,1,-1,1,-1])
        optimizer=torch.optim.AdamW(m.parameters(),lr=1e-4,weight_decay=0)
        before={n:p.detach().clone() for n,p in m.named_parameters()}
        out=m(batch,owners,evidence=evidence,donor_allowed=torch.ones(3,dtype=torch.bool))
        loss,terms=prompt_loss(out,evidence,self.cfg['loss_weights'])
        self.assertEqual(int(terms['supervised_observations']),3)
        loss.backward()
        self.assertEqual([n for n,p in m.named_parameters() if p.grad is None],[])
        self.assertTrue(all(torch.isfinite(p.grad).all() for p in m.parameters()))
        groups=['local.dense_encoder.','data_projection.','patient_labels']
        groups += [f'local.blocks.{i}.' for i in range(3)]
        groups += [f'task.to_label.{i}.' for i in range(2)]+[f'task.to_data.{i}.' for i in range(2)]
        groups += [f'alignment.layers.{i}.' for i in range(2)]+[f'alignment.updates.{i}.' for i in range(2)]
        for group in groups:
            self.assertTrue(any(p.grad.abs().max()>0 for n,p in m.named_parameters() if n.startswith(group)),group)
        optimizer.step()
        for group in groups:
            self.assertTrue(any(not torch.equal(before[n],p) for n,p in m.named_parameters() if n.startswith(group)),group)

    def test_correspondence_changes_scores_and_queries_do_not_update_support(self):
        m=self.model().eval();memory=self.memory()
        with torch.no_grad():
            state=m.prepare_task_state(memory)
            original=m.forward_tasks(memory,memory['embeddings'],memory['owners'],state=state)
            changed=dict(state,transported=state['transported'].roll(1,dims=-1))
            other=m.forward_tasks(memory,memory['embeddings'],memory['owners'],state=changed)
            self.assertGreater(float((original['scores']-other['scores']).abs().max()),1e-7)
            saved=state['aligned'].clone()
            m.forward_tasks(memory,memory['embeddings']*4,memory['owners'],state=state)
            torch.testing.assert_close(saved,state['aligned'],rtol=0,atol=0)
            self.assertEqual(state['correspondence'].shape,(3,3,16,16))
            torch.testing.assert_close(state['correspondence'].sum(-1),torch.ones(3,3,16))
            self.assertNotIn('descriptor_basis',state)

    def test_only_external_T_contributes(self):
        assignment=torch.tensor([[1.,0.],[0.,1.],[.5,.5]])
        owners=torch.arange(3);matrix=torch.eye(2).expand(3,3,2,2).clone()
        result,available,_=transport_positive(assignment,owners,torch.tensor([1,-1,0]),matrix,torch.ones(3,dtype=torch.bool))
        self.assertEqual(available.tolist(),[False,True,True])
        torch.testing.assert_close(result[0],torch.zeros(2))
        torch.testing.assert_close(result[1:],torch.tensor([[1.,0.],[1.,0.]]))
        _,available,_=transport_positive(assignment,owners,torch.tensor([1,-1,0]),matrix,torch.zeros(3,dtype=torch.bool))
        self.assertFalse(available.any())

    def test_recipient_context_never_adds_positive_evidence(self):
        memory=self.memory()
        for case in ('A','UNSEEN'):
            joined,owner=attach_context(memory,torch.randn(4,128),case)
            self.assertFalse(joined['donor_allowed'][owner])
            self.assertTrue((joined['evidence'][joined['owners']==owner]==-1).all())
            self.assertNotIn('descriptors',joined)
        self.assertTrue(memory['donor_allowed'].all())

    def test_patient_permutation_equivariance(self):
        m=self.model().eval();memory=self.memory();perm=torch.tensor([2,0,1]);inverse=perm.argsort()
        reordered=dict(memory,case_ids=[memory['case_ids'][i] for i in perm],
                       owners=inverse[memory['owners']],donor_allowed=memory['donor_allowed'][perm])
        with torch.no_grad():
            a=m.forward_tasks(memory,memory['embeddings'],memory['owners'])
            b=m.forward_tasks(reordered,memory['embeddings'],reordered['owners'])
        torch.testing.assert_close(a['scores'],b['scores'],rtol=1e-5,atol=1e-6)

    def test_observed_only_uniform_collapse_is_explicit(self):
        # Analytic counterexample for the retained T/U objective, not training data.
        p,k=3,16
        assignment=torch.full((6,k),1/k);owners=torch.tensor([0,0,1,1,2,2])
        evidence=torch.tensor([1,-1]*3);matrix=torch.full((p,p,k,k),1/k)
        transferred,available,_=transport_positive(assignment,owners,evidence,matrix,torch.ones(p,dtype=torch.bool))
        scores=torch.nn.functional.cosine_similarity(assignment,transferred[owners],dim=-1)
        loss,terms=prompt_loss(dict(scores=scores,available=available[owners]),evidence,self.cfg['loss_weights'])
        self.assertEqual(float(loss),0.)
        self.assertTrue((scores==1).all())
        self.assertEqual(int(terms['supervised_observations']),3)


if __name__=='__main__':unittest.main()
