"""v2.2: raw-observation graph encoder; isolated from v2.1."""
PIPELINE_VERSION = "hiercp_prompt_graph_v22_physical_nodes_r2"
