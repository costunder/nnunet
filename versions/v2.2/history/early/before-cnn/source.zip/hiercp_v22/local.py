"""Raw CT/statistics/geometry -> learned node projection -> unchanged spatial GNN.

Inherited methods only perform message passing and pooling. No dense encoder,
unused CNN weights, feature-map sampling, or hidden graph restriction exists.
"""
import torch
from torch import nn
from hiercp.model import LocalTumorContextPyGEncoder, HeteroGATv2Block
from hiercp.schema import LOCAL_HANDCRAFTED_DIM, LOCAL_NODE_TYPES, LOCAL_EDGE_TYPES, LOCAL_EDGE_DIM, CONTEXT_SHELL_COUNT
from .features import WIDTH

class RawObservationEncoder(LocalTumorContextPyGEncoder):
    def __init__(self, *, hidden_dim, heads, layers, dropout, checkpoint_local_blocks):
        nn.Module.__init__(self)
        self.hidden_dim = hidden_dim
        self.checkpoint_local_blocks = checkpoint_local_blocks
        self.project = nn.ModuleDict(
            {
                node_type: nn.Sequential(
                    nn.Linear(WIDTH, hidden_dim),
                    nn.LayerNorm(hidden_dim),
                    nn.SiLU(inplace=True),
                )
                for node_type in LOCAL_NODE_TYPES
            }
        )
        self.blocks = nn.ModuleList(
            [
                HeteroGATv2Block(
                    node_types=LOCAL_NODE_TYPES,
                    edge_types=LOCAL_EDGE_TYPES,
                    dim=hidden_dim,
                    heads=heads,
                    edge_dim=LOCAL_EDGE_DIM,
                    dropout=dropout,
                )
                for _ in range(layers)
            ]
        )
        self.pool = nn.ModuleDict(
            {
                node_type: self._attention_pool(hidden_dim)
                for node_type in LOCAL_NODE_TYPES
                if node_type not in {"source_context", "target_context"}
            }
        )
        self.context_shell_pool = nn.ModuleDict(
            {
                f"{node_type}_c{shell_id}": self._attention_pool(hidden_dim)
                for node_type in ("source_context", "target_context")
                for shell_id in range(CONTEXT_SHELL_COUNT)
            }
        )
        self.empty_context_shell = nn.ParameterDict(
            {
                f"{node_type}_c{shell_id}": nn.Parameter(torch.zeros(hidden_dim))
                for node_type in ("source_context", "target_context")
                for shell_id in range(CONTEXT_SHELL_COUNT)
            }
        )
        self.context_shell_fuse = nn.ModuleDict(
            {
                node_type: nn.Sequential(
                    nn.Linear(hidden_dim * CONTEXT_SHELL_COUNT, hidden_dim * 2),
                    nn.LayerNorm(hidden_dim * 2),
                    nn.SiLU(inplace=True),
                    nn.Dropout(dropout),
                    nn.Linear(hidden_dim * 2, hidden_dim),
                )
                for node_type in ("source_context", "target_context")
            }
        )
        self.tumor_fuse = self._pair_fuser(hidden_dim, dropout)
        self.source_context_fuse = self._pair_fuser(hidden_dim, dropout)
        self.target_context_fuse = self._pair_fuser(hidden_dim, dropout)
        self.source_relation = self._pair_fuser(hidden_dim, dropout)
        self.target_relation = self._pair_fuser(hidden_dim, dropout)
        self.final_fuse = nn.Sequential(
            nn.Linear(hidden_dim * 6, hidden_dim * 2),
            nn.LayerNorm(hidden_dim * 2),
            nn.SiLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim * 2, hidden_dim),
        )

    def forward(self, batch):
        x_dict = {}
        for kind in LOCAL_NODE_TYPES:
            x = batch[kind].observed
            if x.ndim != 2 or x.shape[1] != WIDTH:
                raise ValueError(f"Wrong raw observation width for {kind}: {x.shape}")
            x_dict[kind] = self.project[kind](x.float())
        edge_attr_dict = {
            edge_type: batch[edge_type].edge_attr for edge_type in LOCAL_EDGE_TYPES
        }
        for block in self.blocks:
            x_dict = self._run_local_block(
                block, x_dict, batch.edge_index_dict, edge_attr_dict
            )
        pooled = {
            node_type: self.pool[node_type](
                x_dict[node_type],
                index=batch[node_type].batch,
            )
            for node_type in LOCAL_NODE_TYPES
            if node_type not in {"source_context", "target_context"}
        }
        source_context_core, source_shells = self._pool_context_shells(
            "source_context",
            x_dict["source_context"],
            batch["source_context"].x,
            batch["source_context"].batch,
            batch.num_graphs,
        )
        target_context_core, target_shells = self._pool_context_shells(
            "target_context",
            x_dict["target_context"],
            batch["target_context"].x,
            batch["target_context"].batch,
            batch.num_graphs,
        )
        tumor = self.tumor_fuse(
            self._pair(pooled["tumor_surface"], pooled["tumor_interior"])
        )
        source_context = self.source_context_fuse(
            self._pair(source_context_core, pooled["source_liver_surface"])
        )
        target_context = self.target_context_fuse(
            self._pair(target_context_core, pooled["target_liver_surface"])
        )
        source_relation = self.source_relation(self._pair(tumor, source_shells[0]))
        target_relation = self.target_relation(self._pair(tumor, target_shells[0]))
        fused = self.final_fuse(
            torch.cat(
                [
                    tumor,
                    source_context,
                    target_context,
                    source_relation,
                    target_relation,
                    torch.abs(source_relation - target_relation),
                ],
                dim=-1,
            )
        )
        return {
            "tumor": tumor,
            "source_context": source_context,
            "target_context": target_context,
            "source_relation": source_relation,
            "target_relation": target_relation,
            "source_c0": source_shells[0],
            "source_c1": source_shells[1],
            "source_c2": source_shells[2],
            "target_c0": target_shells[0],
            "target_c1": target_shells[1],
            "target_c2": target_shells[2],
            "fused": fused,
        }
