"""Physical, mask-aware observations with an explicit feature dictionary.

Mean/population variance follow the first-order definitions in IBSI; applying
them to masked per-node physical boxes is our CP-specific proposal, not an
IBSI-certified radiomics implementation or a claimed clinical biomarker.
All valid voxel cells contribute, including fractional boundary-cell volumes.
"""
import itertools
import numpy as np
from scipy.ndimage import map_coordinates

CONTRACT='physical_observation_boxes_mm_masked_r2'
RADII_MM=(4.,12.,28.) # existing experiment's near/middle/far context scales
POSITION_SCALE_MM=28.
GRADIENT_SCALE_MM=4.
NAMES=('ct_intensity',)+tuple(f'{s}_{r:g}mm' for r in RADII_MM for s in ('mean','std','observed_fraction'))+(
    'gradient_x','gradient_y','gradient_z','gradient_x_available','gradient_y_available','gradient_z_available',
    'relative_x','relative_y','relative_z','tumor_signed_distance','liver_depth','normal_x','normal_y','normal_z')
WIDTH=len(NAMES)
FEATURE_GROUPS={
    'observation':(0,16,17,18),
    'statistics':tuple(range(1,16)),
    'geometry':tuple(range(19,24)),
}


def _validate(image,valid,spacing):
    image=np.asarray(image,dtype=np.float64);valid=np.asarray(valid,dtype=bool);spacing=np.asarray(spacing,dtype=np.float64)
    if image.ndim!=3 or valid.shape!=image.shape or spacing.shape!=(3,) or np.any(spacing<=0):
        raise ValueError('3D image/mask and positive physical spacing required')
    if not np.isfinite(image).all() or not np.isfinite(spacing).all():raise ValueError('Nonfinite physical observations')
    return image,valid,spacing


def _box_integrals(values,lower,upper):
    """Integrate voxel-cell constants over fractional index-space boxes."""
    prefix=np.pad(values,((1,0),)*3).cumsum(0).cumsum(1).cumsum(2)
    limit=np.asarray(values.shape,dtype=np.float64)
    lower=np.clip(lower,0,limit);upper=np.clip(upper,0,limit)
    total=np.zeros(len(lower),dtype=np.float64)
    for corner in itertools.product((0,1),repeat=3):
        coordinates=np.where(np.asarray(corner)[None,:],upper,lower)
        sign=(-1)**(3-sum(corner))
        total+=sign*map_coordinates(prefix,coordinates.T,order=1,prefilter=False,mode='nearest')
    return total


def physical_moments(image,valid,spacing,coordinates,radii=RADII_MM):
    """Weighted mean/std/support for every point and every declared mm radius.

    No intensity from an invalid cell enters the statistics. Coverage is the
    observed volume / requested box volume, so ROI/organ truncation is explicit.
    """
    image,valid,spacing=_validate(image,valid,spacing)
    xyz=np.asarray(coordinates,dtype=np.float64);radii=np.asarray(radii,dtype=np.float64)
    if xyz.ndim!=2 or xyz.shape[1]!=3 or not np.isfinite(xyz).all() or radii.ndim!=1 or not len(radii) or not np.isfinite(radii).all() or np.any(radii<=0):
        raise ValueError('Finite N x 3 coordinates and positive physical radii required')
    # Integral-grid origin is the lower face of voxel zero, hence +0.5.
    centers=xyz[:,None,:]+.5;half=radii[None,:,None]/spacing[None,None,:]
    lower=(centers-half).reshape(-1,3);upper=(centers+half).reshape(-1,3)
    mass=_box_integrals(valid.astype(np.float64),lower,upper)
    if np.any(mass<=1e-12):raise ValueError('No observed CT support for a requested node/window')
    first=_box_integrals(np.where(valid,image,0.),lower,upper)
    second=_box_integrals(np.where(valid,image*image,0.),lower,upper)
    mean=first/mass;variance=second/mass-mean*mean
    # Only round-off of a mathematically nonnegative variance is clamped.
    if np.any(variance < -1e-8*np.maximum(1.,second/mass)):
        raise FloatingPointError('Unstable physical-window variance')
    volume=np.broadcast_to((2*radii)**3/np.prod(spacing),(len(xyz),len(radii))).ravel()
    fraction=mass/volume
    if np.any(fraction>1+1e-8):raise FloatingPointError('Observed volume exceeds requested window')
    result=np.stack((mean,np.sqrt(np.maximum(variance,0)),np.minimum(fraction,1)),axis=1)
    return result.reshape(len(xyz),len(radii)*3).astype(np.float32)


def physical_gradients(image,valid,spacing,coordinates):
    """Finite differences per mm, without crossing an unobserved mask.

    Central difference when both neighbors are observed, one-sided otherwise.
    With no observed neighbor the derivative is unavailable; value=0 and an
    explicit availability channel=0 encode missingness, not a fabricated slope.
    """
    image,valid,spacing=_validate(image,valid,spacing)
    xyz=np.asarray(coordinates,dtype=np.int64)
    if xyz.ndim!=2 or xyz.shape[1]!=3 or np.any(xyz<0) or np.any(xyz>=np.asarray(image.shape)):
        raise ValueError('Node coordinates outside observed array')
    if not valid[tuple(xyz.T)].all():raise ValueError('A node center is outside its declared observation domain')
    center=image[tuple(xyz.T)];grad=np.zeros((len(xyz),3));available=np.zeros_like(grad)
    shape=np.asarray(image.shape)
    for axis in range(3):
        offset=np.zeros(3,dtype=np.int64);offset[axis]=1
        plus=xyz+offset;minus=xyz-offset
        plus_inside=np.all((plus>=0)&(plus<shape),axis=1);minus_inside=np.all((minus>=0)&(minus<shape),axis=1)
        plus=np.clip(plus,0,shape-1);minus=np.clip(minus,0,shape-1)
        vp=plus_inside & valid[tuple(plus.T)];vm=minus_inside & valid[tuple(minus.T)]
        ip=image[tuple(plus.T)];im=image[tuple(minus.T)]
        both=vp&vm;forward=vp&~vm;backward=vm&~vp
        grad[both,axis]=(ip[both]-im[both])/(2*spacing[axis])
        grad[forward,axis]=(ip[forward]-center[forward])/spacing[axis]
        grad[backward,axis]=(center[backward]-im[backward])/spacing[axis]
        available[:,axis]=vp|vm
    return grad.astype(np.float32),available.astype(np.float32)


def node_observations(fields,specifications,spacing,config):
    """Compute complete canonical features once per observation domain."""
    if tuple(map(float,config.context_shells_mm))!=RADII_MM or float(config.context_radius_mm)!=POSITION_SCALE_MM:
        raise ValueError('Feature scales must match the declared full context contract')
    output={};spacing=np.asarray(spacing,dtype=np.float64)
    # Tumor observations describe the actual donor tumor. Context observations
    # exclude the real/virtual footprint in BOTH branches; no inpainted pixels.
    for tumor_domain in (True,False):
        names=[k for k in specifications if k.startswith('tumor_')==tumor_domain]
        if not names:continue
        coords=np.concatenate([specifications[k][0] for k in names]).astype(np.int64)
        valid=(fields.footprint & fields.organ) if tumor_domain else (fields.organ & ~fields.footprint)
        moments=physical_moments(fields.ct_norm,valid,spacing,coords)
        gradient,available=physical_gradients(fields.ct_norm,valid,spacing,coords)
        offset=0
        for kind in names:
            positions,normal_source,_=specifications[kind];count=len(positions);index=tuple(np.asarray(positions).T)
            normal=fields.liver_normal[index] if normal_source=='liver' else fields.tumor_normal[index]
            relative=(np.asarray(positions)-(np.asarray(fields.ct_norm.shape)-1)*.5)*spacing
            value=np.concatenate((fields.ct_norm[index][:,None],
                moments[offset:offset+count],gradient[offset:offset+count]*GRADIENT_SCALE_MM,available[offset:offset+count],
                relative/POSITION_SCALE_MM,fields.tumor_sdf_mm[index][:,None]/POSITION_SCALE_MM,
                fields.liver_depth_mm[index][:,None]/POSITION_SCALE_MM,normal),axis=1).astype(np.float32)
            if value.shape!=(count,WIDTH) or not np.isfinite(value).all():raise ValueError('Invalid canonical feature table')
            output[kind]=value;offset+=count
    return output


def dictionary():
    rows=[]
    for i,name in enumerate(NAMES):
        group=next(g for g,indices in FEATURE_GROUPS.items() if i in indices)
        if name.startswith(('mean_','std_')):
            origin='IBSI first-order moment formula; masked per-node box is project adaptation'
            reference='https://ibsi.readthedocs.io/en/latest/03_Image_features.html#intensity-based-statistical-features'
        elif name.startswith('observed_fraction') or 'available' in name:
            origin='Project measurement-validity indicator; not a clinical biomarker';reference='project design'
        elif name.startswith('gradient'):
            origin='Physical finite difference with observed-only stencil; project feature choice';reference='project mathematical definition'
        else:
            origin='Project CP feature choice; no paper is claimed to validate this exact feature set'
            reference='hiercp_v22/features.py; hiercp/spatial.py'
        if name=='ct_intensity':formula='u = 2*(clip(HU,-200,250)+200)/450-1';unit='dimensionless; HU=225*u+25 inside clipping range'
        elif name.startswith('mean_'):formula='sum(observed_cell_overlap_volume*u)/sum(observed_cell_overlap_volume)';unit='normalized CT; clipped HU mean=225*mean+25'
        elif name.startswith('std_'):formula='sqrt(sum(w*u*u)/sum(w)-mean*mean), population std';unit='normalized CT; clipped HU std=225*std'
        elif name.startswith('observed_fraction'):formula='observed_volume / (2*half_width_mm)^3';unit='fraction [0,1]'
        elif 'available' in name:formula='1 if at least one axial neighbor is observed, else 0';unit='binary measurement availability'
        elif name.startswith('gradient'):formula='4mm * du/ds; central or one-sided observed finite difference';unit='dimensionless; HU/mm=value*225/4'
        elif name.startswith('relative'):formula='(node_index-(native_ROI_shape-1)/2)*axis_spacing_mm / 28mm';unit='dimensionless displacement'
        elif name=='tumor_signed_distance':formula='(EDT(outside)-EDT(inside))/28mm with physical sampling; negative inside';unit='dimensionless distance; multiply by28 for mm'
        elif name=='liver_depth':formula='full-organ physical EDT inside /28mm';unit='dimensionless distance; multiply by28 for mm'
        else:formula='physical SDF gradient / max(gradient_norm,1e-6); liver SDF for liver nodes, footprint SDF otherwise';unit='direction component [-1,1]; zero at zero gradient'
        rows.append(dict(index=i,name=name,group=group,formula=formula,unit=unit,
                         observation_domain='tumor nodes: actual donor footprint within organ; context/liver nodes: organ minus actual/virtual footprint, within native ROI',
                         axes='x/y/z denote array axes0/1/2 with physical spacing, not guaranteed anatomical RAS directions',
                         window='axis-aligned physical box; named mm is half-width, not spherical radius',
                         missingness='coverage channels expose ROI/organ truncation; gradient availability exposes absent stencil; empty statistical support is an error',
                         definition_origin=origin,reference=reference,
                         feature_contract=CONTRACT,clinical_validity='unproven; requires controlled downstream evaluation'))
    return rows
