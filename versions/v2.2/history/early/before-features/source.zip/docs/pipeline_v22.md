# v2.2 — CNN 없는 원본 관측 특징 기반 GNN

2026-09-20 KST. 구현 버전이며 전체 학습·의료 평가 완료를 뜻하지 않는다.

## 변경 목적과 범위

사용자가 제공한 설계 설명의 핵심인 **CNN 없이도 원본 관측값으로 후보를 평가하는 경로**를 구현했다. v2.1을 그대로 보존하고 `hiercp_v22/`, `run_v22.py`, `config/prompt_graph_v22.json`으로 분리했다. artifact format은 `hiercp_prompt_graph_v22_raw_nodes_r1`이다.

v2.1의 노드·엣지와 후보 집합을 유지한 비교 버전이다. 옥트리, MST, FPS, feature-kNN, 새로운 이웃 수 제한, CNN 보조 점수 경로를 동시에 추가하지 않았다. 이들을 함께 바꾸면 CNN 제거 효과를 분리할 수 없기 때문이다. 기존 CNN 특징을 추론 때 0으로 만드는 방식도 아니다. 별도의 모델을 처음부터 학습한다.

## 실제 forward 경로

```text
donor 실제 종양 / recipient에 옮긴 가상 종양 footprint
    ↓ 기존 mm 좌표·반경·역할별 노드와 엣지
원본 관측 특징 16개
    ↓ 노드 종류별 Linear(16,128) → LayerNorm → SiLU
기존 3층 gated GATv2 + 역할별·거리 구간별 pooling
    ↓ 후보 하나당 128차원 data node
환자별 data ↔ 16개 latent label의 L1, 2층
    ↓ 환자 간 label 대응 L2, 2층
다른 inner-train 환자 T의 분포 전달 → 후보 compatibility
    ↓ 전체 128개 유효 후보의 argmax
온라인 CT/GT copy-paste → nnU-Net 분할 학습
```

16개 입력은 CT 강도 1, 국소 평균 1, 표준편차 1, 강도 기울기 1, 상대 물리 좌표 3, 종양 경계 거리 1, 간 내부 깊이 1, 법선 3, 곡률 1, 거리 구간 1, 표면 역할 1, source/target 역할 1이다. 기존 특징을 그대로 사용한다. 좌표만으로 판단하는 모델이 아니다.

종양 표면·내부, donor 주변과 간 표면, recipient 주변과 간 표면의 기존 노드 역할을 유지한다. KD-tree는 이웃 탐색을 맡고, GNN이 영상 관측값과 공간 관계에서 특징을 학습한다. 기존 context sampling seed 384와 필수 경계·2-hop 확장 규칙도 유지한다. 이는 canonical 전체 노드가 매 forward 모두 들어간다는 뜻이 아니다. 이번 버전에 추가한 node/edge cap은 없다.

학습 가능한 Conv3d 모듈은 0개다. 기존 CNN은 삭제된 모듈이며 optimizer에 미사용 CNN parameter가 남지 않는다. GNN hidden 128, head 4, L0/L1/L2 3/2/2층과 label 16개는 유지한다. 3명의 DEBUG 환자 모델은 6,940,776 parameter이고 실제 학습 모델은 환자별 label table 수에 따라 달라진다.

## GPU 패치 전송 제거와 통계 보존

`LocalBatch`는 graph, patch_moments, indices만 전달한다. source/target 48³ 패치와 source_index를 모델 배치에서 없앴다. 새 그래프 저장 파일에도 dense patch 대신 source/target 각각 평균·표준편차 10개를 저장한다.

이 20개 통계는 **v2.1 L2 정렬·재구성 손실 목표를 동일하게 보존하기 위한 값**이다. CNN 입력이나 query encoder 입력은 아니다. v2.1과 동일하게 float16으로 표현했던 5채널 패치에 대해 float32 mean/std를 계산한다. 노드 특징 평균과 합친 descriptor가 기존 값과 정확히 일치하는지 검사했다.

CPU 그래프 준비는 기존 geometry builder를 호출하므로 48³ 패치를 일시적으로 만들고 통계를 계산한다. CPU 패치 생성·거리장 계산 비용까지 없어진 것은 아니다. source patch GPU 중복 인코딩 비용은 CNN 제거로 사라진다. 온라인 점수 요청마다 resource calibration을 다시 하는 기존 비용은 남아 있다.

## 데이터와 CP 계약

- 전체 cohort, outer/inner split, 모든 T anchor, 균형 donor context round를 그대로 사용한다.
- donor는 inner-train의 적격 ≤20 mm 종양 전체 풀이다. 소형 종양이 없는 outer-train 환자도 recipient로 포함한다.
- CP 확률 0.5, donor 균등 추출, 후보 128개, exact argmax를 유지한다. 동일 donor/recipient pair의 고정 후보·점수는 bank에서 재사용될 수 있다.
- CP 적용 시 해당 학습 샘플은 CT와 정답을 함께 수정한 patch 하나로 들어간다. 원본과 적용본을 별도 pair로 추가하지 않는다. 원본 파일은 보존하고 validation에는 CP를 적용하지 않는다.
- GNN 40 epoch, nnU-Net 250 epoch를 유지한다. GNN physical batch와 worker는 실제 데이터에서 자동 측정한다. DEBUG batch 2/4와 worker 설정을 production 기본값으로 쓰지 않는다.
- v2.1 GNN checkpoint, support embedding, 점수 bank는 v2.2에 재사용할 수 없다. CNN 없는 입력으로 재학습해야 한다.
- 원본 Basic CP/과거 Basic 결과는 별도 정책이다. 공통 donor 조건의 무작위 선택 대조군과 동일하다고 재표기하지 않는다.

## 실행

프로젝트 가상환경에서 실행한다. 새 output 디렉터리를 요구하며 기존 결과를 덮어쓰지 않는다.

```powershell
.venv\Scripts\python.exe run_v22.py check
```

전체 v2.1 그래프 준비가 끝났다면 `convert-cache --cache <완료된 index.json> --output <새 폴더>`를 사용한다. 모든 record의 SHA를 확인하고, 노드·엣지를 유지한 채 통계 저장 형식으로 별도 변환한다. 새 index에 원본 index 경로와 SHA, record 개수, 가중치 미재사용을 기록한다. 부분 cache는 거부한다. 원본 cache를 수정하거나 version 이름만 바꾸지 않는다.

새로 준비하려면 `prepare --medical-root <Medical 루트> --split <split.json> --output <새 폴더>`를 사용한다. 이후:

```text
train --cache <v2.2 index.json> --output <새 GNN 학습 폴더>
reuse-native --native <v2.1 native.json> --output <새 native 실행 폴더>
bank --native <새 native.json> --checkpoint <완료된 v2.2 checkpoint> --output <새 bank 폴더>
nnunet-train --native <새 native.json> --bank <새 bank index.json>
predict --native <새 native.json> --output <새 예측 폴더>
evaluate --native <새 native.json> --predictions <예측 디렉터리> --output <새 평가 폴더>
```

각 줄 앞에 `.venv\Scripts\python.exe run_v22.py`를 붙인다. `reuse-native`는 검증된 원본/전처리를 참조하고 별도 runtime·results root를 만든다. 신규 native 준비가 필요하면 `nnunet-plan`도 제공한다. native CLI 실행에는 가상환경 Scripts가 PATH에 있어야 한다.

## 확인한 범위

- 정적 import와 CNN 모듈 부재, CPU 배치 일관성, 입력 CT 변화에 대한 encoder 반응을 확인했다.
- v2.2 회귀 32개: fresh geometry 생성/저장/재로딩, descriptor 동일성, L1/L2, donor/split 경계와 native CP transport의 DEBUG 검사 통과.
- CUDA BF16에서 전체 폭 L0/L1/L2 → loss → 모든 parameter의 유한 gradient → 각 핵심 모듈 optimizer 갱신 1 step 통과. 합성 DEBUG 입력이며 학습 완료가 아니다.
- 실제 저장된 의료 그래프 4개에서 노드 7,451–9,145개, 엣지 463,543–566,590개를 동일하게 유지했고, 노드·엣지 tensor와 descriptor가 v2.1과 정확히 일치했다.
- RTX 5070 Ti에서 3회 측정 중앙값: physical graph batch 2의 L0 210.62 → 183.07 ms, batch 4의 L0 292.54 → 286.54 ms. v2.1 CNN 부분은 각각 5.60 / 5.13 ms였다. **이 표본에서는 CNN이 주된 연산 비용이라고 보기 어렵다.** 그래프 연산·CPU dispatch·측정 변동도 남는다. 시간은 전체 학습·CP latency나 의료 성능 결과가 아니다.
- 근거: `work/v22_20260920/debug2/verification.json`. profiler의 peak는 해당 측정 프로세스에서 관측한 값이며 production 동시 모델 peak가 아니다.
- 실제 U event의 후보 128개 전체를 CNN 없는 Scorer로 처리해 유한 점수와 argmax를 확인했다. 실제 inner-train T anchor 3명의 support를 사용한 **미학습 full-width DEBUG**다. physical batch 4, worker 2로 흐름을 검사했으며 production 자동 보정을 대체하지 않는다. 근거 `work/v22_20260920/pool_debug2/verification.json`. 이 검사에서는 native paste를 새로 실행하지 않았다.
- 최초 pool DEBUG는 점수 계산 후 테스트용 보정 객체의 순환 참조 때문에 JSON 저장이 실패했다. 도구를 수정하고 새 디렉터리에서 재검증했으며 실패한 원본은 `pool_debug1/`에 보존했다.

## 남아 있는 설계·검증 과제

이번 버전은 CNN 의존성을 제거한 비교 구현이다. 기존 T-only 관측 점수 손실이 후보 순위의 유용성을 충분히 학습시키는지, context 통계 기반 L2 정렬이 타당한지, 학습의 자기 환자 T/U support와 사용 시 U-only context 차이는 해결됐다고 주장하지 않는다. nnU-Net 손실은 고정 GNN으로 역전파되지 않는다.

완전한 판단에는 같은 donor·후보·CP 확률·학습량으로 재학습한 v2.1/v2.2와 유효 후보 무작위 선택 대조군의 nnU-Net 평가가 필요하다. CNN-only 모델, CNN 보조 branch, octree/MST 그래프는 이번 버전에 구현하지 않았고 향후 별도 비교 항목이다.

전체 cache 변환·GNN 40 epoch·nnU-Net 250 epoch·전체 의료 평가는 이번 구현 작업에서 실행하지 않았다. v2.1 실행 프로세스를 중단하거나 변경하지 않았다.

## 작업 완료 체크리스트

- [x] 서버 또는 원격 세션 종료 위험이 있는 명령을 사용하지 않았다.
- [x] 사용자 파일과 기존 결과를 파괴적으로 변경하지 않았다.
- [x] 모델 깊이와 너비를 편의상 축소하지 않았다. CNN 제거는 사용자 요청한 별도 비교 설계다.
- [x] 그래프와 데이터 규모를 편의상 축소하지 않았다.
- [x] 숨겨진 subset, cap, fast mode를 추가하지 않았다.
- [x] physical batch size와 병렬화 가능성을 실제로 검토했다. DEBUG 2/4, production 자동 측정 유지.
- [x] GPU, CPU, RAM 활용 상태를 측정하거나 확인했다.
- [x] OOM 발생 시 모델 축소보다 메모리 및 병목 원인을 먼저 조사했다. 이번 검사에서는 OOM 없음.
- [x] 디버그 설정과 최종 설정을 분리했다.
- [x] dummy, placeholder, random fallback을 사용하지 않았다. 합성 입력과 미학습 모델은 명시적 DEBUG 전용이다.
- [x] 핵심 모듈이 forward, loss, gradient와 optimizer에 연결되어 있다.
- [x] 실제 실행 설정과 변경 사항을 명확하게 보고했다.
- [x] smoke test와 전체 학습 또는 전체 평가를 구분해서 보고했다.
