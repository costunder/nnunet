"""Explicit, audited reuse of data geometry; never migrate learned weights."""
from pathlib import Path
from . import PIPELINE_VERSION
from .contracts import read_json,write_new,sha,safe_new_root,validate_split
from .data import patch_moments
from .storage import GraphWriter


def convert_record(record):
    from hiercp_v2 import PIPELINE_VERSION as OLD_FORMAT
    if record.get('format')!=OLD_FORMAT:raise ValueError('Only verified v2.1 graph records can be converted')
    result=dict(record)
    result['source_moments']=patch_moments(result.pop('source_patch'))
    result['target_moments']=patch_moments(result.pop('target_patch'))
    result['derived_from_format']=OLD_FORMAT
    result['format']=PIPELINE_VERSION
    return result


def convert_cache(index_path,output,cfg,base):
    """All records, coordinates and edges retained; write a separate v2.2 cache."""
    from hiercp_v2.contracts import load_config as old_config
    from hiercp_v2.storage import load_record
    from .donors import validate_training_rows,reject_cross_split_duplicates
    from .parallel import run_jobs
    path=Path(index_path).resolve(); old=read_json(path)
    old_cfg,old_base=old_config()
    if old.get('complete') is not True or old.get('format')!=old_cfg['format']:
        raise ValueError('A complete v2.1 cache is required; partial preparation is not a training set')
    if old['config']!=old_cfg or old['base_config']!=base or base!=old_base:
        raise ValueError('Predecessor cache/config mismatch')
    additions={'format','local_encoder','feature_contract','descriptor_contract','release'}
    if {k:v for k,v in cfg.items() if k not in additions}!={k:v for k,v in old_cfg.items() if k not in additions}:
        raise ValueError('Geometry/data/training conditions changed in CNN ablation')
    validate_split(old['split'])
    validate_training_rows(old['records'],old['split'],old['donor_pool'])
    reject_cross_split_duplicates(old['all_raw_identities'],old['split'])
    root=safe_new_root(output); writer=GraphWriter(root,int(cfg['minimum_free_gb']*1024**3)); rows=[]
    def one(row):
        if sha(path.parent/row['path'])!=row['sha256']:raise ValueError('Source graph SHA changed')
        record=convert_record(load_record(path.parent,row['path']))
        saved=writer.write(row['path'],record,(row['case_id'],row['donor_case_id'],row['component_id']))
        return dict(row,**saved)
    # Same independent-record parallel preparation scheduler and RAM admission.
    run_jobs(old['records'],one,rows.append,cfg['preparation_workers'],root/'conversion_resources.json')
    if len(rows)!=len(old['records']):raise RuntimeError('Conversion did not retain every graph')
    result=dict(old,format=PIPELINE_VERSION,config=cfg,records=sorted(rows,key=lambda r:r['id']),
                migration={'source_index':str(path),'source_sha256':sha(path),'record_count':len(rows),
                           'geometry_unchanged':True,'learned_weights_reused':False})
    for name,value in [('config.json',cfg),('base_config.json',base),('split.json',old['split']),('index.json',result)]:
        write_new(root/name,value)
    return root/'index.json'


def reuse_native(native_path,output):
    """Read-only reuse of preprocessing; independent runtime and results root."""
    from hiercp_v2.contracts import validate_native as validate_old
    path=Path(native_path).resolve(); old=validate_old(read_json(path))
    root=safe_new_root(output)
    value=dict(old,format=PIPELINE_VERSION,root=str(root),
               preprocessing_origin={'path':str(path),'sha256':sha(path),'release':'v2.1'},
               results_reused=False)
    write_new(root/'native.json',value)
    return root/'native.json'
