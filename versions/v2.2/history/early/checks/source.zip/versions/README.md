# 파이프라인 버전 구분

사용자의 요청에 따라 **v1 = 기존 파이프라인**, **v2.0 = 폐기된 view-only 구현**, **v2.1 = 기존 환자 간 정렬 구현**, **v2.2 = CNN 없는 원본 관측 특징 GNN**으로 구분한다. 변경 이력의 기준은 [PATCH_NOTES.md](../PATCH_NOTES.md)다.

v2.2는 `run_v22.py` / `hiercp_v22/` / `config/prompt_graph_v22.json`을 사용한다. v2.1의 runtime는 그대로 남겼고, 변경 전 소스·문서는 `v2.1/before_v22_20260920/source.zip`과 manifest에 보존했다. v2.2는 구현·DEBUG 검증 상태이며 전체 학습 완료가 아니다. 상세: [v2.2 계약](../docs/pipeline_v22.md).

아래 표는 기존 v1/v2.1의 비교 기록이다.

| 구분 | v1 (보존) | v2.1 (현재) |
|---|---|---|
| 진입점 | 기존 `run.py` 및 동일 동작 별칭 `run_v1.py` | `run_v2.py` |
| GNN | 기존 `hiercp/` | 새 `hiercp_v2/` |
| L0 | 기존 국소 그래프 인코더 | 기존 KD-tree 국소 그래프와 인코더 재사용 |
| L1 | 기존 patient/region 계층 | 실제 환자별 독립 random trainable label과 data 관계 학습 |
| L2 | 기존 population/prototype 계층 | 환자별 label 공간 정렬 + 관측 T evidence를 U context로 전달 |
| 기존 feedback 실험 | 원래 구현 그대로 | frozen GNN의 정렬 관계 점수 argmax; 별도 실험 |
| 가중치 호환 | 기존 버전 규칙 유지 | v1 가중치를 v2로 변환하거나 재사용하지 않음 |

v1의 내부 `MODEL_ARCHITECTURE_VERSION`은 기존 v5이다. **파이프라인 v1과 내부 모델 revision v5는 서로 다른 번호 체계**다.

`v1/manifest.json`은 변경 전 commit `74dcc2cf03d2d40d1f582223321d96004333f661`의 추적 파일 202개에 대한 SHA-256을 기록한다. `v1/pipeline_v1_source.zip`에는 그 파일들의 사본을 보존했다. 이전 실험 결과 폴더와 미추적 문서는 이동하거나 덮어쓰지 않았다. v2 실행 시 공유하는 v1 코드가 manifest와 일치하는지 검사한다.

2026-09-19 인계 최신화부터 루트 `gpt_handoff.md`/`code.txt`는 현재 문서로 갱신한다. 두 문서의 v1 원본은 변경하지 않은 ZIP에서 SHA를 검증한다. 나머지 v1 파일은 현재 파일까지 원본 SHA를 검사한다. 문서 갱신을 이유로 runtime/config 변경을 허용하지 않는다.

새 구조와 실행 절차는 `docs/pipeline_v2.md`에 기록했다. 이전 GNN PDF는 기존 구조 설명이며 v2 설명으로 간주하면 안 된다.

동일 데이터 두 stochastic view 정렬을 사용한 첫 구현을 **v2.0**으로 기록한다. 사용자 의도와 달라 폐기했다.
그 소스·handoff·code.txt 218개는 `v2/superseded_view_alignment_20260919/source.zip`과 manifest에 보존했다.
현재 **v2.1** format은 `hiercp_prompt_graph_v2_cross_patient_r1`이며 v2.0 artifact를 호환으로 받아들이지 않는다. `run_v2.py`, `hiercp_v2/`, `versions/v2/` 등 기존 경로는 v2 계열 공용 명칭으로 유지한다. 사람용 버전 번호와 저장 format ID를 혼동하지 않는다.

## 작업 완료 체크리스트

2026-09-19 공통 donor/누수 방지 수정 전 17개 파일은 `v2/pre_shared_donor_fix_20260919/source.zip`과 manifest에 보존했다. 현재 증강 계약은 `docs/shared_donor_leakage_v21.md`, 실행·DEBUG 증거는 `docs/local_v21_5070ti_run.md`를 따른다. 이전 비대칭 donor 정책의 cache/bank는 현재 실행에 재사용하지 않는다.

- [x] 서버 또는 원격 세션 종료 위험이 있는 명령을 사용하지 않았다.
- [x] 사용자 파일과 기존 결과를 파괴적으로 변경하지 않았다.
- [x] 모델 깊이와 너비를 편의상 축소하지 않았다.
- [x] 그래프와 데이터 규모를 편의상 축소하지 않았다.
- [x] 숨겨진 subset, cap, fast mode를 추가하지 않았다.
- [x] physical batch size와 병렬화 가능성을 실제로 검토했다.
- [x] GPU, CPU, RAM 활용 상태를 측정하거나 확인했다.
- [x] OOM 발생 시 모델 축소보다 메모리 및 병목 원인을 먼저 조사하도록 구현했다. 실제 GPU OOM 실험은 하지 않았다.
- [x] 디버그 설정과 최종 설정을 분리했다.
- [x] 생산 코드에 dummy, placeholder, random fallback을 사용하지 않았다.
- [x] 핵심 GNN 모듈이 forward, loss, gradient와 optimizer에 연결되어 있다.
- [x] 실제 실행 설정과 변경 사항을 명확하게 보고했다.
- [x] smoke test와 전체 학습 또는 전체 평가를 구분해서 보고했다.
