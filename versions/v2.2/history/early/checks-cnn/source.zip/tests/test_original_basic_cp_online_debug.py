"""DEBUG equivalence to the literal user source, plus real native loader wiring."""
import contextlib,io,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import numpy as np
import nibabel as nib
from scipy import ndimage as ndi
from basic_cp_online.reference import REFERENCE,static_inputs,select,apply_raw

def original(image,label,seed):
    scope={'__name__':'original_reference_DEBUG'}
    exec(compile(REFERENCE.read_text(encoding='utf-8'),str(REFERENCE),'exec'),scope)
    header=nib.Nifti1Header();header.set_data_shape(image.shape)
    scope['load_case_safely']=lambda *_:(image.copy(),label.copy(),np.eye(4),np.eye(4),header,header,np.ones(3),1.)
    scope['RNG_SEED']=seed;saved={}
    with patch('nibabel.save',side_effect=lambda image,path:saved.__setitem__(path,np.asarray(image.dataobj).copy())),contextlib.redirect_stdout(io.StringIO()):
        result=scope['augment_case']('input','label','CT','GT')
    return saved,result

class OriginalBasicCPOnlineDebug(unittest.TestCase):
    def test_literal_reference_CT_GT_equivalence_all_components_and_large_tumors(self):
        image=np.random.default_rng(71).normal(100,35,(64,64,64)).astype(np.float32)
        label=np.ones(image.shape,np.int16);label[10:31,10:31,10:31]=2;label[48:51,48:51,48:51]=2
        inputs=static_inputs(image,label);selected=set()
        for seed in range(12):
            plan=select(inputs,seed);selected.add(plan['component'])
            actual_ct,actual_gt=apply_raw(image,label,plan);expected,_=original(image,label,seed)
            np.testing.assert_array_equal(actual_ct,expected['CT']);np.testing.assert_array_equal(actual_gt,expected['GT'])
            self.assertLessEqual(plan['proposals'],4000)
        self.assertEqual(selected,{1,2})
        self.assertGreater(2*(3*21**3/(4*np.pi))**(1/3),20)
        np.testing.assert_array_equal(inputs['image'],image);np.testing.assert_array_equal(inputs['label'],label)

    def test_literal_distance_optimization_equals_uint8_EDT(self):
        mask=np.zeros((19,21,23),np.uint8);mask[5:10,5:10,5:10]=1
        expected=ndi.distance_transform_edt(~mask);x,y,z=np.indices(mask.shape)
        np.testing.assert_array_equal(expected,np.sqrt((x+1)**2+y*y+z*z))
        self.assertNotEqual(expected[6,6,6],ndi.distance_transform_edt(~mask.astype(bool))[6,6,6])

    def test_no_tumor_or_liver_unchanged_no_foreign_donor(self):
        image=np.ones((20,20,20),np.float32)
        for label,status in ((np.ones(image.shape,np.int16),'no_tumor'),(np.full(image.shape,2,np.int16),'no_liver')):
            plan=select(static_inputs(image,label),9);self.assertEqual(plan['status'],status)
            ct,gt=apply_raw(image,label,plan);np.testing.assert_array_equal(ct,image);np.testing.assert_array_equal(gt,label)
            saved,_=original(image,label,9);self.assertEqual(saved,{})

    def test_no_place_retains_original_no_resampling_another_donor(self):
        image=np.ones((12,12,12),np.float32);label=np.full(image.shape,2,np.int16);label[0,0,0]=1
        plan=select(static_inputs(image,label),11);self.assertEqual(plan['status'],'no_valid_location')
        expected,_=original(image,label,11);ct,gt=apply_raw(image,label,plan)
        np.testing.assert_array_equal(ct,expected['CT']);np.testing.assert_array_equal(gt,expected['GT'])

    def test_positions_are_resampled_each_visit_no_fixed_128_pool(self):
        image=np.ones((36,36,36),np.float32);label=np.ones(image.shape,np.int16);label[25:28,25:28,25:28]=2
        inputs=static_inputs(image,label);plans=[select(inputs,i) for i in range(10)]
        self.assertTrue(all(p['status']=='placed' for p in plans))
        self.assertGreater(len({tuple(p['center']) for p in plans}),1)

    def test_native_lazy_CT_and_complete_GT_match_offline_reference_preprocessing(self):
        from test_online_raw_bank_preparation_debug import fixture
        from custom_trainers.onlinecp_raw_resampling import prepare_case,prepare_candidate
        from nnunetv2.preprocessing.resampling.default_resampling import resample_data_or_seg_to_shape as resample
        from nnunetv2.training.dataloading.data_loader import crop_and_pad_nd
        from basic_cp_online.runtime import NativeCT
        image,label,props,plans,_,_=fixture();image[12:15,12:15,12:15]=400;label[12:15,12:15,12:15]=2
        case=prepare_case(image,label,props,plans,configuration_name='debug',raw_spacing_xyz=[.7]*3,raw_spatial_unit='mm')
        settings=plans['configurations']['debug']
        for seed in (0,3,8):
            plan=select(static_inputs(image,label),seed);self.assertEqual(plan['status'],'placed')
            candidate=prepare_candidate(case,plan['source_ct'],plan['source_mask'],plan['anchor'],plan['center'])
            ct=NativeCT(case,candidate,plan);rawct,rawgt=apply_raw(image,label,plan)
            expected=resample(rawct.transpose(2,1,0)[None]/200,[12]*3,[.7]*3,[1.]*3,**settings['resampling_fn_data_kwargs'])
            expected_gt=resample(rawgt.transpose(2,1,0)[None],[12]*3,[.7]*3,[1.]*3,**settings['resampling_fn_seg_kwargs'])
            seg=case['baseline_seg'].copy();box=tuple(slice(a,b) for a,b in candidate['output_bbox']);seg[(slice(None),*box)]=candidate['seg_patch']
            np.testing.assert_array_equal(seg,expected_gt)
            for bbox in ([[0,12]]*3,[[2,9],[1,10],[3,11]],[[-2,6],[7,16],[0,9]]):
                np.testing.assert_allclose(crop_and_pad_nd(ct,bbox,0),crop_and_pad_nd(expected,bbox,0),rtol=1e-6,atol=1e-5)

    def test_real_standard_nnunet_loader_batch_and_heldout_guard(self):
        from test_online_raw_bank_preparation_debug import fixture
        from custom_trainers.onlinecp_raw_resampling import prepare_case,baseline_output
        from custom_trainers.onlinecp_raw_bank import save_case
        from basic_cp_online.runtime import Dataset
        from nnunetv2.training.dataloading.data_loader import nnUNetDataLoader
        from nnunetv2.utilities.label_handling.label_handling import LabelManager
        image,label,props,plans,_,_=fixture();image[12:15,12:15,12:15]=400;label[12:15,12:15,12:15]=2
        case=prepare_case(image,label,props,plans,configuration_name='debug',raw_spacing_xyz=[.7]*3,raw_spatial_unit='mm')
        baseline=baseline_output(case);seg=case['baseline_seg'];baseprops=dict(props,class_locations={1:np.argwhere(seg==1),2:np.argwhere(seg==2)})
        class Base:
            identifiers=['A','B']
            def load_case(self,key):return baseline,seg,None,baseprops
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);row={}
            for key,name,value in [('inputs','inputs.json',static_inputs(image,label)),('case','case.json',case),('preparation','prep.json',case['preparation'])]:
                row[key+'_ref']=name;row[key+'_sha']=save_case(root,name,value)
            meta=dict(split=dict(inner_train=['A'],inner_val=['B'],outer_train=['A','B'],outer_val=['H']),cases={'A':row,'B':row})
            with patch('basic_cp_online.runtime.validate_manifest',return_value=meta):wrapper=Dataset(Base(),root/'index.json')
            try:
                with self.assertRaisesRegex(ValueError,'Held-out'):wrapper.load_case('H')
                loader=nnUNetDataLoader(wrapper,2,[12]*3,[12]*3,LabelManager({'background':0,'liver':1,'tumor':2},None),transforms=None)
                batch=loader.generate_train_batch()
                self.assertEqual(tuple(batch['data'].shape),(2,1,12,12,12));self.assertTrue(np.isfinite(batch['data'].numpy()).all())
                self.assertEqual(wrapper.last_audit['case_id'],wrapper.last_audit['donor_case_id'])
                self.assertTrue((root/'online_audit').is_dir())
                np.testing.assert_array_equal(seg,case['baseline_seg'])
            finally:
                if wrapper.store:wrapper.store.close()

    def test_validation_dataset_and_standard_loader_unchanged(self):
        from basic_cp_online.nnUNetTrainer_OriginalBasicCPOnline import nnUNetTrainer_250epochs_OriginalBasicCPOnline as Trainer
        from nnunetv2.training.nnUNetTrainer.nnUNetTrainer import nnUNetTrainer
        obj=Trainer.__new__(Trainer);obj.is_cascaded=False;obj.label_manager=SimpleNamespace(has_regions=False,ignore_label=None)
        obj.configuration_manager=SimpleNamespace(patch_size=[128]*3);obj.basic_manifest=Path('DEBUG')
        train,val=object(),object();wrapped=object()
        with patch.object(nnUNetTrainer,'get_tr_and_val_datasets',return_value=(train,val)),patch('basic_cp_online.nnUNetTrainer_OriginalBasicCPOnline.Dataset',return_value=wrapped) as factory:
            actual=obj.get_tr_and_val_datasets();self.assertIs(actual[0],wrapped);self.assertIs(actual[1],val);factory.assert_called_once_with(train,obj.basic_manifest)
        self.assertIs(Trainer.get_dataloaders,nnUNetTrainer.get_dataloaders)

if __name__=='__main__':unittest.main()
