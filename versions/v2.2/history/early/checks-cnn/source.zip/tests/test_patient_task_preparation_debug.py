"""DEBUG policy wiring: real source inventory/loops, explicitly mocked geometry IO.

Actual L0/foreign donor geometry is exercised separately. These tiny mocked cache
payloads are never interpreted as model inputs or medical experiment results.
"""
from pathlib import Path
from types import SimpleNamespace
from dataclasses import replace
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
import torch
from hiercp.common import CasePaths,LoadedCase
from hiercp.local import PreparedLocalSource
from hiercp_v2 import data
from hiercp_v2.contracts import load_config,write_new,read_json,sha

class PatientTaskPreparationDebugTests(unittest.TestCase):
    def test_full_128_pools_and_zero_positive_patient_not_dropped(self):
        cfg,base=load_config(); cfg=dict(cfg,preparation_workers=2)
        with tempfile.TemporaryDirectory(prefix='patient_task_DEBUG_') as name:
            root=Path(name); patients={}; paths=[]
            for case_id in ['A','B','C','V']:
                ip=root/(case_id+'_image'); lp=root/(case_id+'_label')
                ip.write_bytes(('DEBUG image '+case_id).encode()); lp.write_bytes(('DEBUG label '+case_id).encode())
                path=CasePaths(case_id,ip,lp); paths.append(path)
                label=np.ones((16,16,16),dtype=np.uint8)
                if case_id!='B': label[6:9,6:9,6:9]=2
                patients[case_id]=LoadedCase(path,np.ones(label.shape,dtype=np.float32),label,np.eye(4),np.eye(4),None,None,np.ones(3),{}, {})
            split=dict(inner_train=['A','B','C'],inner_val=['V'],outer_train=['A','B','C','V'],outer_val=['H'])
            hi=root/'UNREAD_HELDOUT_IMAGE'; hl=root/'UNREAD_HELDOUT_LABEL'; hi.write_bytes(b'heldout original image'); hl.write_bytes(b'heldout original label')
            paths.append(CasePaths('H',hi,hl))
            write_new(root/'split.json',split)
            original={c:(v.label.copy(),v.image.copy()) for c,v in patients.items()}
            def source_geometry(case,source,**kwargs):
                return PreparedLocalSource(source.patch_mask.copy(),np.zeros((5,2,2,2)),{}, {},{})
            def debug_record(case,source,center,base,**kwargs):
                return {'DEBUG_mocked_geometry':True,'source_local':{'format':'canonical-full-v22','footprint_voxels':source.voxel_count,'nodes':{},'edges':{}},
                    'target_local':{'format':'canonical-full-v22','nodes':{},'edges':{}},'source_patch':torch.zeros(5,2,2,2),'target_patch':torch.zeros(5,2,2,2)}
            from contextlib import contextmanager
            class DebugVolumeCache:
                def __init__(self,*args):pass
                @contextmanager
                def pair(self,a,b):
                    def value(c):
                        case=patients[c]
                        return dict(case=case,organ=case.label>0,depth=np.ones_like(case.image),sources=data.sources(case,base['cache']['source_pad'],20))
                    yield value(a),value(b)
            with patch('hiercp_v2.volumes.VolumeCache',DebugVolumeCache),patch('hiercp_v2.volumes.volume_memory_bound',return_value=16**3*24),patch.object(data,'discover_cases',return_value=paths),patch.object(data,'load_case',side_effect=lambda path:patients[path.case_id]), \
                 patch.object(data,'prepare_local_source',side_effect=source_geometry),patch.object(data,'local_record',side_effect=debug_record), \
                 patch.object(data,'candidate_pool',return_value=([SimpleNamespace(center=(7,7,7)) for _ in range(128)],{'DEBUG_geometry_boundary':True})):
                index=read_json(data.prepare(root,root/'split.json',root/'cache',cfg,base))
            rows=index['records']
            self.assertEqual(len(rows),3+5*128)
            self.assertEqual(sum(r['evidence']==1 for r in rows),3)
            self.assertFalse(any(r['evidence']==0 for r in rows))
            zero=[r for r in rows if r['case_id']=='B']
            self.assertEqual(len(zero),128); self.assertTrue(all(r['evidence']==-1 for r in zero))
            self.assertTrue({r['donor_case_id'] for r in zero}<={'A','C'})
            for case in ['A','B','C']:
                self.assertEqual(sum(r['case_id']==case and r['evidence']==-1 for r in rows),128)
            self.assertEqual({r['donor_case_id'] for r in rows if r['evidence']==-1},{'A','C'})
            self.assertNotIn('H',{r['case_id'] for r in rows})
            for c,v in patients.items():
                np.testing.assert_array_equal(v.label,original[c][0]); np.testing.assert_array_equal(v.image,original[c][1])

if __name__=='__main__': unittest.main()
