"""Full CP scorer is unavailable until the L2 objective is specified."""
from .contracts import require_training_objective

class Scorer:
    def __init__(self,*args,**kwargs):
        require_training_objective()
