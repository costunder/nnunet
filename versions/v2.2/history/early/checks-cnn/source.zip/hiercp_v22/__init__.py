"""CNN-only L0 and preserved L1 architecture; no clinical validation claim."""
PIPELINE_VERSION="hiercp_prompt_graph_v22_ct_cnn_l0_l1_r3"
