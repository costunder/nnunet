"""Map the complete MSD Liver training cohort and reconstruct existing stratified splits."""
import argparse
import json
from pathlib import Path
import shutil
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def main():
    from hiercp_v2.contracts import sha, write_new, validate_split, verify_v1
    from hiercp.preparation_runtime import run_case_jobs
    from tools.paired_benchmark import Case, profile_case, natural_key, balanced_folds, write_profiles
    import nibabel as nib
    import numpy as np
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--download', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    verify_v1()
    receipt = json.loads((args.download / 'download_complete.json').read_text())
    if not receipt['md5_verified'] or not receipt['complete_archive_extracted']:
        raise ValueError('Verified complete MSD archive required')
    source = Path(receipt['extraction']) / 'Task03_Liver'
    metadata = json.loads((source / 'dataset.json').read_text())
    rows = metadata['training']
    if len(rows) != metadata['numTraining'] or len(rows) != 131:
        raise ValueError('Expected complete 131-case MSD Liver labelled cohort')
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    medical = output / 'medical'
    for name in ('image', 'labels'):
        (medical / 'Data' / name).mkdir(parents=True)
    profiles, inventory = [], []

    def process(row):
        start = time.perf_counter()
        image, label = (source / row[k] for k in ('image', 'label'))
        if not image.resolve().is_relative_to(source.resolve()) or not label.resolve().is_relative_to(source.resolve()):
            raise ValueError('Non-local dataset path')
        case_id = label.name.removesuffix('.nii.gz')
        img, lab = nib.load(image), nib.load(label)
        if img.shape != lab.shape or len(img.shape) != 3 or not np.allclose(img.affine, lab.affine):
            raise ValueError(f'Image/label physical geometry mismatch: {case_id}')
        actual_labels = np.unique(np.asarray(lab.dataobj))
        if not set(actual_labels.tolist()).issubset({0, 1, 2}):
            raise ValueError(f'Unexpected labels: {case_id}')
        targets = [medical / 'Data/image' / f'{case_id}_0000.nii.gz', medical / 'Data/labels' / label.name]
        record = {'case_id': case_id, 'shape': list(img.shape), 'spacing': list(map(float, img.header.get_zooms())), 'labels': actual_labels.tolist()}
        for key, original, target in zip(('image', 'label'), (image, label), targets):
            if target.exists():
                raise ValueError(f'Duplicate target: {target}')
            shutil.copy2(original, target)
            original_sha = sha(original)
            if sha(target) != original_sha:
                raise ValueError(f'Copy failed integrity: {target}')
            record[key] = str(target)
            record[key + '_sha256'] = original_sha
        record['seconds'] = time.perf_counter() - start
        return profile_case(Case(case_id, *targets), 2), record

    def commit(result):
        profile, record = result
        profiles.append(profile)
        inventory.append(record)
        print(f'Validated {len(inventory)}/131: {profile.case_id}', flush=True)

    run_case_jobs(tasks=rows, function=process, commit=commit, workers='auto', report_path=output/'data_resources.json')
    profiles.sort(key=lambda p: natural_key(p.case_id))
    all_ids = {p.case_id for p in profiles}
    if len(all_ids) != 131:
        raise ValueError('Patient identity duplication')
    outer = balanced_folds(profiles, 5, 42 + 270827)
    splits = [{'fold': i, 'train': sorted(all_ids-set(val), key=natural_key), 'val': val} for i, val in enumerate(outer)]
    chosen = splits[0]
    inner_profiles = [p for p in profiles if p.case_id in chosen['train']]
    inner_val = balanced_folds(inner_profiles, 5, 42 + 1000)[0]
    split = {'outer_fold': 0, 'outer_train': chosen['train'], 'outer_val': chosen['val'],
             'inner_train': sorted(set(chosen['train'])-set(inner_val), key=natural_key), 'inner_val': inner_val}
    validate_split(split)
    write_profiles(output/'profiles.csv', profiles)
    write_new(output/'outer_splits.json', {'seed': 42+270827, 'splits': splits})
    write_new(output/'split.json', split)
    write_new(output/'dataset_ready.json', {'dataset': 'MSD Task03_Liver', 'release': 'v2.1', 'medical_root': str(medical),
        'download_receipt_sha256': sha(args.download/'download_complete.json'), 'patients': sorted(inventory,key=lambda r:natural_key(r['case_id'])),
        'split_algorithm': 'unchanged tools.paired_benchmark profile_case(26-connectivity)/balanced_folds; outer seed 270869; inner seed 1042; outer fold 0',
        'server_split_identity_verified': False, 'note': 'Reconstructed from official raw data and existing algorithm; no server split/hash copy was available. Not a paired rerun against historical scores.',
        'training_patients_used': 131, 'public_unlabelled_test_used_for_training': False})
    print(json.dumps({k:len(v) for k,v in split.items() if isinstance(v,list)}), flush=True)


if __name__ == '__main__':
    main()
