"""Preserve the existing tracked pipeline without renaming or modifying it."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[1]

def main():
    git = ['git', '-c', f'safe.directory={ROOT.as_posix()}']
    revision = subprocess.check_output(git + ['rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    files = subprocess.check_output(git + ['ls-files', '-z'], cwd=ROOT).decode().split('\0')
    target = ROOT / 'versions' / 'v1'
    target.mkdir(parents=True, exist_ok=True)
    manifest = target / 'manifest.json'
    if manifest.exists():
        sys.path.insert(0,str(ROOT))
        from hiercp_v2.contracts import verify_v1
        print('Verified preserved v1:', verify_v1(ROOT))
        return
    hashes = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in files if name}
    archive = target / 'pipeline_v1_source.zip'
    with ZipFile(archive, 'x', ZIP_DEFLATED) as z:
        for name in hashes:
            z.write(ROOT / name, name)
    data = {'format': 'hiercp_pipeline_v1_preservation_v1', 'revision': revision,
            'meaning': 'v1 is the pre-Prompt-Graph pipeline; its internal model revision remains v5',
            'entrypoints': ['run.py', 'tools/run_feedback_experiment.py'], 'files': hashes,
            'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}
    with manifest.open('x', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print('Preserved', len(hashes), 'v1 files:', archive)

if __name__ == '__main__':
    main()
