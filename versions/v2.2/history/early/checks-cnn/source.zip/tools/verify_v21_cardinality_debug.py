"""DEBUG synthetic L1/L2 stress at measured full context cardinality; no checkpoint."""
from pathlib import Path
import sys,argparse,time,json,traceback
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
def main():
    import torch
    from hiercp_v2.contracts import load_config,read_json,write_new,source_identity
    from hiercp_v2.donors import donor_pool,context_round
    from hiercp_v2.model import PromptGraphModel,prompt_loss,DESCRIPTOR_DIM
    p=argparse.ArgumentParser();p.add_argument('--run-root',type=Path,required=True);p.add_argument('--output',required=True);args=p.parse_args()
    split=read_json(args.run_root/'dataset/split.json');inv=read_json(args.run_root/'attempt2/gnn_cache/source_inventory.json')['sources'];pool=donor_pool(inv,split)
    ids=split['inner_train'];counts={c:len(inv[c]) for c in ids}
    for e in context_round(pool,ids,42):counts[e['recipient']]+=128
    cfg,base=load_config();torch.manual_seed(42);device='cuda';n=sum(counts.values())
    model=PromptGraphModel(cfg,base,patient_ids=ids,with_local=False).to(device)
    owner=torch.cat([torch.full((counts[c],),i,dtype=torch.long) for i,c in enumerate(ids)]).to(device)
    memory=dict(case_ids=ids,owners=owner,embeddings=torch.randn(n,128,device=device),descriptors=torch.randn(n,DESCRIPTOR_DIM,device=device),
                evidence=torch.where(torch.arange(n,device=device)%128==0,1,-1),donor_allowed=torch.ones(len(ids),device=device,dtype=torch.bool))
    torch.cuda.reset_peak_memory_stats();start=time.perf_counter()
    report=dict(scope='DEBUG synthetic L1/L2 cardinality stress; L0 not exercised; no medical predictions or checkpoint',contexts=n,patients=len(ids),source_identity=source_identity())
    error=None
    try:
        with torch.autocast('cuda',dtype=torch.bfloat16):
            result=model.forward_tasks(memory,torch.randn(8,128,device=device),torch.arange(8,device=device))
            loss,_=prompt_loss(result,memory['descriptors'][:8],memory['evidence'][:8],cfg['loss_weights'],cfg['temperature'])
        loss.backward();torch.cuda.synchronize()
        if not all(p.grad is not None and bool(torch.isfinite(p.grad).all()) for p in model.parameters()):raise RuntimeError('Nonfinite or missing task gradient')
        report.update(status='passed',loss=float(loss.detach()),all_task_gradients_finite=True)
    except Exception as exc:
        error=exc;report.update(status='failed',error=traceback.format_exc())
    report.update(peak_vram=torch.cuda.max_memory_allocated(),seconds=time.perf_counter()-start)
    write_new(args.output,report);print(json.dumps(report),flush=True)
    if error is not None:raise error
if __name__=='__main__':main()
