"""Run verified local dataset preparation and the full 40-epoch v2.1 GNN stage."""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys
import traceback

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def main():
    from hiercp_v2.contracts import read_json, write_new, verify_v1, source_identity, load_config, sha
    from hiercp.preparation_runtime import snapshot
    import torch
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--download', type=Path, required=True)
    parser.add_argument('--run-root', type=Path, required=True)
    parser.add_argument('--prepared-dataset',type=Path,help='Reuse a completed validated raw dataset only; never a partial graph cache/checkpoint')
    args = parser.parse_args()
    run = args.run_root.resolve()
    run.mkdir(parents=True, exist_ok=True)
    if (run/'pipeline_started.json').exists():
        raise ValueError('Run already started; existing logs/results are preserved')
    preflight = read_json(run/'preflight/cuda_smoke.json')
    debug = read_json(run/'preflight/debug/verification.json')
    if not preflight['all_gradients_finite'] or preflight['source_identity'] != source_identity():
        raise ValueError('Current CUDA smoke proof required')
    if debug['test_returncode'] or debug['source_identity'] != source_identity():
        raise ValueError('Current DEBUG regression proof required')
    if torch.__version__ != '2.8.0+cu128' or not torch.cuda.is_available():
        raise RuntimeError('Verified isolated CUDA runtime required')
    verify_v1()
    cfg, base = load_config()
    dataset=args.prepared_dataset.resolve() if args.prepared_dataset else run/'dataset'
    if args.prepared_dataset:
        ready=read_json(dataset/'dataset_ready.json')
        if len(ready['patients'])!=131 or ready['training_patients_used']!=131:raise ValueError('Full verified raw dataset required')
        for patient in ready['patients']:
            for key in ('image','label'):
                if sha(patient[key])!=patient[key+'_sha256']:raise ValueError('Prepared raw dataset changed')
    started = {'release':'v2.1', 'pid':os.getpid(), 'started_utc':datetime.now(timezone.utc).isoformat(),
        'scope':'full cohort outer fold 0 data preparation and 40-epoch GNN; segmentation/evaluation are subsequent stages',
        'config':cfg, 'base_config':base, 'source_identity':source_identity(), 'resources':snapshot(),
        'gpu':torch.cuda.get_device_name(), 'torch':torch.__version__, 'debug':False, 'subset':False,'prepared_dataset':str(dataset)}
    write_new(run/'pipeline_started.json', started)
    env = os.environ.copy()
    env['PYTHONIOENCODING'] = 'utf-8'
    env['PYTHONUNBUFFERED'] = '1'
    env['PYTHONPATH'] = str(ROOT)
    env['PATH'] = str(Path(sys.executable).parent) + os.pathsep + env['PATH']
    stages = ([] if args.prepared_dataset else [
        ('dataset', ['tools/prepare_local_v21_dataset.py','--download',str(args.download.resolve()),'--output',str(dataset)])]) + [
        ('gnn_prepare', ['run_v2.py','prepare','--medical-root',str(dataset/'medical'),'--split',str(dataset/'split.json'),'--output',str(run/'gnn_cache')]),
        ('gnn_train', ['run_v2.py','train','--cache',str(run/'gnn_cache/index.json'),'--output',str(run/'gnn_train')]),
    ]
    for stage, arguments in stages:
        try:
            print(f'START {stage}', flush=True)
            command = [sys.executable, '-u', *arguments]
            write_new(run/f'{stage}_started.json', {'command':command,'utc':datetime.now(timezone.utc).isoformat()})
            with (run/f'{stage}.log').open('x',encoding='utf-8') as stream:
                result = subprocess.run(command,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT)
            if result.returncode:
                raise RuntimeError(f'{stage} failed ({result.returncode}); retained log: {run/stage}.log')
            write_new(run/f'{stage}_complete.json', {'utc':datetime.now(timezone.utc).isoformat(),'log_sha256':sha(run/f'{stage}.log')})
            print(f'COMPLETE {stage}', flush=True)
        except Exception:
            write_new(run/f'{stage}_failed.json', {'utc':datetime.now(timezone.utc).isoformat(),'error':traceback.format_exc()})
            raise
    write_new(run/'gnn_stage_complete.json', {'release':'v2.1','gnn_epochs':40,'checkpoint':str(run/'gnn_train/model.pt'),
        'segmentation_training_completed':False,'medical_evaluation_completed':False})


if __name__ == '__main__':
    main()
