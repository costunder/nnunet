"""DEBUG original-reference equivalence proof; never a full training result."""
from pathlib import Path
import argparse,sys,time,json,subprocess,os
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]

def main():
    from hiercp_v2.contracts import safe_new_root,write_new,verify_v1,sha,read_json
    from basic_cp_online.runtime import source_identity
    from basic_cp_online.reference import reference_digest,static_inputs,select,apply_raw
    from hiercp.preparation_runtime import Measurement
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',required=True)
    parser.add_argument('--real-case',help='Explicit DEBUG patient ID for complete raw CT/GT equivalence; no model training')
    parser.add_argument('--native',type=Path)
    args=parser.parse_args();out=safe_new_root(args.output)
    for file in [*(ROOT/'basic_cp_online').glob('*.py'),ROOT/'run_basic_cp_online.py',Path(__file__),ROOT/'tests/test_original_basic_cp_online_debug.py']:
        compile(file.read_text(encoding='utf-8'),str(file),'exec')
    env=os.environ.copy();env['PYTHONPATH']=os.pathsep.join([str(ROOT),str(ROOT/'tests')])
    result=subprocess.run([sys.executable,'-m','unittest','test_original_basic_cp_online_debug','-v'],cwd=ROOT,env=env,capture_output=True,text=True,encoding='utf-8')
    (out/'tests.txt').write_text(result.stdout+'\n'+result.stderr,encoding='utf-8')
    if result.returncode:raise RuntimeError(f'DEBUG regression failed: {out / "tests.txt"}')
    report=dict(scope='DEBUG original Basic CP equivalence; not training/evaluation',static_passed=True,tests_passed=8,
                source_identity=source_identity(),reference_lf_sha256=reference_digest(),v1_revision=verify_v1(),full_training=False)
    if args.real_case:
        import numpy as np
        from hiercp.common import load_case,CasePaths
        from test_original_basic_cp_online_debug import original
        native=read_json(args.native)
        if args.real_case not in native['split']['outer_train']:raise ValueError('DEBUG raw CP restricted to actual training patients')
        row=next(r for r in native['raw_records'] if r['case_id']==args.real_case)
        before={key:sha(row[key]) for key in ('image','label')}
        print('DEBUG real original-reference comparison: '+args.real_case,flush=True)
        with Measurement() as measurement:
            case=load_case(CasePaths(args.real_case,Path(row['image']),Path(row['label'])))
            inputs=static_inputs(case.image,case.label);plan=select(inputs,42)
            expected,_=original(case.image,case.label,42)
            actual_ct,actual_gt=apply_raw(case.image,case.label,plan)
            if expected:
                np.testing.assert_array_equal(actual_ct,expected['CT']);np.testing.assert_array_equal(actual_gt,expected['GT'])
            else:
                np.testing.assert_array_equal(actual_ct,case.image);np.testing.assert_array_equal(actual_gt,case.label)
            details={k:plan[k] for k in ('status','component','proposals','coverage','scale','shift_hu') if k in plan}
            if plan['status']=='placed':
                voxels=int(plan['source_mask'].sum());details.update(raw_pasted_voxels=voxels,center=plan['center'].tolist(),
                    source_equivalent_diameter_mm=float(2*(3*voxels*np.prod(case.spacing)/(4*np.pi))**(1/3)))
            report['real_data']=dict(case_id=args.real_case,whole_volume_exact_CT=True,whole_volume_exact_GT=True,**details)
        report['resources']=measurement.report
        if before!={key:sha(row[key]) for key in ('image','label')}:raise ValueError('Original CT/GT changed')
        report['original_CT_GT_sha_unchanged']=True
    write_new(out/'verification.json',report);print(json.dumps(report,ensure_ascii=False,indent=2),flush=True)

if __name__=='__main__':main()
