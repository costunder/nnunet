"""Download the complete official MONAI-hosted MSD Liver archive, with integrity checks."""
from concurrent.futures import ThreadPoolExecutor, as_completed
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import tarfile
import time
import urllib.request

URL = 'https://msd-for-monai.s3-us-west-2.amazonaws.com/Task03_Liver.tar'
MD5 = 'a90ec6c4aa7f6a3d087205e23d4e6397'
PROVENANCE = 'https://github.com/Project-MONAI/MONAI/blob/dev/monai/apps/datasets.py'


def digest(path, algorithm):
    h = hashlib.new(algorithm)
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024**2), b''):
            h.update(block)
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--workers', type=int, default=8)
    args = parser.parse_args()
    if args.workers < 1:
        raise ValueError('Positive download concurrency required')
    root = args.output.resolve()
    root.mkdir(parents=True, exist_ok=True)
    archive = root / 'Task03_Liver.tar'
    with urllib.request.urlopen(urllib.request.Request(URL, method='HEAD'), timeout=60) as response:
        total, etag = int(response.headers['Content-Length']), response.headers['ETag']
    receipt = {'url': URL, 'source': PROVENANCE, 'bytes': total, 'etag': etag, 'expected_md5': MD5}
    identity = root / 'download_identity.json'
    if identity.exists():
        if json.loads(identity.read_text()) != receipt:
            raise ValueError('Remote archive identity changed; preserve existing download')
    else:
        with identity.open('x') as stream:
            json.dump(receipt, stream, indent=2)
    if not archive.exists():
        parts = root / 'download_parts'
        parts.mkdir(exist_ok=True)
        chunk = 256 * 1024**2
        jobs = [(i, start, min(total, start + chunk)) for i, start in enumerate(range(0, total, chunk))]
        needed = sum(end - start - ((parts / f'{i:04d}.part').stat().st_size if (parts / f'{i:04d}.part').exists() else 0)
                     for i, start, end in jobs)
        if shutil.disk_usage(root).free < needed + total + 80 * 1024**3:
            raise RuntimeError('Insufficient space for parts, verified archive and 80 GiB reserve')

        def fetch(job):
            i, start, end = job
            path = parts / f'{i:04d}.part'
            size = path.stat().st_size if path.exists() else 0
            if size > end - start:
                raise ValueError(f'Oversized part preserved: {path}')
            if size < end - start:
                request = urllib.request.Request(URL, headers={'Range': f'bytes={start + size}-{end - 1}', 'If-Match': etag})
                with urllib.request.urlopen(request, timeout=60) as response:
                    if response.status != 206 or response.headers.get('Content-Range') != f'bytes {start + size}-{end - 1}/{total}':
                        raise RuntimeError('Server did not honor requested range')
                    with path.open('ab') as stream:
                        shutil.copyfileobj(response, stream, 1024**2)
            if path.stat().st_size != end - start:
                raise RuntimeError(f'Incomplete part retained for explicit retry: {path}')
            return end - start

        completed, started = 0, time.monotonic()
        with ThreadPoolExecutor(max_workers=args.workers) as pool:
            for future in as_completed([pool.submit(fetch, job) for job in jobs]):
                completed += future.result()
                print(f'Download verified ranges {completed}/{total} bytes; elapsed {time.monotonic()-started:.1f}s', flush=True)
        staging = root / f'assembly_{time.time_ns()}.tar'
        h = hashlib.md5()
        with staging.open('xb') as output:
            for i, _, _ in jobs:
                with (parts / f'{i:04d}.part').open('rb') as stream:
                    for block in iter(lambda: stream.read(8 * 1024**2), b''):
                        h.update(block)
                        output.write(block)
        if h.hexdigest() != MD5:
            raise ValueError(f'Official MD5 mismatch; retained download: {staging}')
        staging.rename(archive)
    if archive.stat().st_size != total or digest(archive, 'md5') != MD5:
        raise ValueError('Archive failed official integrity check')
    print('Official archive MD5 verified; extracting complete dataset', flush=True)
    extracted = root / 'extracted'
    extracted.mkdir(exist_ok=True)
    with tarfile.open(archive, 'r:') as source:
        for member in source:
            relative = PurePosixPath(member.name)
            target = extracted.joinpath(*relative.parts)
            if relative.is_absolute() or '..' in relative.parts or not target.resolve().is_relative_to(extracted):
                raise ValueError(f'Unsafe archive member: {member.name}')
            if member.isdir():
                target.mkdir(parents=True, exist_ok=True)
            elif member.isfile():
                target.parent.mkdir(parents=True, exist_ok=True)
                with source.extractfile(member) as stream:
                    if target.exists():
                        with target.open('rb') as previous:
                            for block in iter(lambda: stream.read(8 * 1024**2), b''):
                                if previous.read(len(block)) != block:
                                    raise ValueError(f'Existing extraction differs: {target}')
                            if previous.read(1):
                                raise ValueError(f'Existing extraction oversized: {target}')
                    else:
                        with target.open('xb') as output:
                            shutil.copyfileobj(stream, output, 8 * 1024**2)
            else:
                raise ValueError(f'Unsupported archive member: {member.name}')
    receipt.update(md5_verified=True, complete_archive_extracted=True, extraction=str(extracted))
    marker = root / 'download_complete.json'
    if not marker.exists():
        with marker.open('x') as stream:
            json.dump(receipt, stream, indent=2)
    print(json.dumps(receipt, indent=2), flush=True)


if __name__ == '__main__':
    main()
