"""Explicit DEBUG: one real-medical CUDA optimizer step; never a final/subset experiment."""
import argparse
import json
from pathlib import Path
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

def main():
    import torch
    import numpy as np
    from hiercp_v2.contracts import load_config,read_json,write_new,source_identity,verify_v1
    from hiercp_v2.data import sources,candidate_pool,local_record,materialize,collate
    from hiercp_v2.model import PromptGraphModel,prompt_loss,context_descriptor
    from hiercp.common import discover_cases,load_case,organ_depth_mm
    from hiercp.local import prepare_local_source
    from hiercp.schema import graph_config_from_dict
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-root',type=Path,required=True)
    args=parser.parse_args(); root=args.run_root.resolve(); out=root/'preflight/real_medical_cuda_DEBUG.json'
    if out.exists():raise ValueError('Existing DEBUG report is preserved')
    verify_v1(); cfg,base=load_config(); split=read_json(root/'dataset/split.json'); scale=read_json(root/'preflight/medical_scale.json')
    ids=[c for c in split['inner_train'] if scale['actual_6_connectivity_sources'][c]>0][:3]
    if len(ids)!=3:raise ValueError('DEBUG probe needs three actual positive inner-training patients')
    paths={p.case_id:p for p in discover_cases(root/'dataset/medical/Data')}
    records=[]; inventory=[]; started=time.perf_counter()
    for case_id in ids:
        case=load_case(paths[case_id]); source,diameter=sources(case,base['cache']['source_pad'],20)[0]
        organ=np.isin(case.label,[1,2]); depth=organ_depth_mm(organ,case.spacing)
        prepared=prepare_local_source(case,source,full_organ_mask=organ,organ_depth=depth,
            config=graph_config_from_dict(base['graph']),rng=np.random.default_rng(cfg['seed']),ct_clip=tuple(base['ct_clip']))
        pool,audit=candidate_pool(case,source,cfg,base,depth)
        for center in (source.anchor_center,pool[0].center):
            record=local_record(case,source,center,base,prepared=prepared,depth=depth,organ=organ)
            records.append(record)
        inventory.append({'case_id':case_id,'source_component':source.component_id,'diameter_mm':diameter,'complete_candidate_pool':len(pool)})
        print({'DEBUG_real_case_graphs_ready':case_id},flush=True)
    torch.manual_seed(cfg['seed']); torch.cuda.reset_peak_memory_stats(); device=torch.device('cuda')
    model=PromptGraphModel(cfg,base,patient_ids=ids).to(device).train()
    batch=collate([(materialize(record),i) for i,record in enumerate(records)]).to(device)
    descriptors=context_descriptor(batch); owners=torch.arange(3,device=device).repeat_interleave(2)
    evidence=torch.tensor([1,-1]*3,device=device)
    optimizer=torch.optim.AdamW(model.parameters(),lr=base['training']['lr'],weight_decay=base['training']['weight_decay'])
    with torch.no_grad(),torch.autocast('cuda',dtype=torch.bfloat16):embeddings=model.encode_local(batch).float()
    memory=dict(case_ids=ids,embeddings=embeddings,owners=owners,evidence=evidence,descriptors=descriptors,donor_allowed=torch.ones(3,dtype=torch.bool,device=device))
    before={n:p.detach().clone() for n,p in model.named_parameters()}
    with torch.autocast('cuda',dtype=torch.bfloat16):
        query=model.encode_local(batch); result=model.forward_tasks(memory,query,owners)
        loss,parts=prompt_loss(result,descriptors,evidence,cfg['loss_weights'],cfg['temperature'])
    loss.backward()
    missing=[n for n,p in model.named_parameters() if p.grad is None or not torch.isfinite(p.grad).all()]
    if missing or not torch.isfinite(loss):raise RuntimeError(f'Real-input gradient failure: {missing}')
    optimizer.step(); changed=[n for n,p in model.named_parameters() if bool(torch.any(before[n]!=p))]
    for prefix in ('local.','data_projection.','patient_labels','task.','alignment.','local_decoder.','label_decoder.'):
        if not any(n.startswith(prefix) for n in changed):raise RuntimeError(f'Core module did not update: {prefix}')
    torch.cuda.synchronize()
    report={'scope':'DEBUG real medical integration only; 3 inner-training patients, one T and one U graph each; no checkpoint exported',
        'real_medical_data_used':True,'production_training_started':False,'full_training_completed':False,'optimizer_steps':1,
        'patients':inventory,'physical_graph_batch':6,'configured_epochs_unchanged':cfg['gnn_epochs'],
        'parameters':sum(p.numel() for p in model.parameters()),'gpu':torch.cuda.get_device_name(),'precision':'BF16',
        'loss':float(loss.detach()),'all_gradients_finite':True,'all_core_modules_updated':True,
        'canonical_node_counts':[r['source_local']['counts']|r['target_local']['counts'] for r in records],
        'peak_vram_bytes':torch.cuda.max_memory_allocated(),'seconds':time.perf_counter()-started,'source_identity':source_identity()}
    write_new(out,report); print(json.dumps(report,indent=2),flush=True)

if __name__=='__main__':main()
