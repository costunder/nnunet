"""DEBUG real CT -> external donor -> full 128-pool GNN -> native CT/GT paste.

An explicitly UNTRAINED full-width scorer is injected for integration testing.
No checkpoint or medical accuracy is claimed. The resulting catalog is marked
debug=True and both production native entry points reject it.
"""
from pathlib import Path
import sys,argparse,time,json,threading
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))

def main():
    import torch,numpy as np
    from hiercp_v2.contracts import read_json,write_new,load_config,source_identity,sha
    from hiercp_v2.donors import donor_pool
    from hiercp_v2.data import sources,local_record,materialize,collate
    from hiercp_v2.model import PromptGraphModel,context_descriptor
    from hiercp_v2.scoring import Scorer
    from hiercp_v2 import bank
    from hiercp_v2.native_adapter import SharedDonorBank
    from hiercp.common import discover_cases,load_case
    p=argparse.ArgumentParser();p.add_argument('--run-root',type=Path,required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    out=args.output.resolve();out.mkdir(exist_ok=False);r=args.run_root.resolve();start=time.perf_counter()
    cfg,base=load_config();native_path=r/'native/native.json';native=read_json(native_path);split=native['split']
    inv=read_json(r/'attempt2/gnn_cache/source_inventory.json')['sources'];pool=donor_pool(inv,split)
    ids=[c for c in split['inner_train'] if inv[c]][:3]
    target=next(c for c in split['outer_train'] if not inv[c])
    paths={p.case_id:p for p in discover_cases(r/'dataset/medical/Data')};records=[]
    before={f'{c}:{k}':sha(getattr(paths[c],k+'_path')) for c in [*ids,target] for k in ('image','label')}
    for case_id in ids:
        case=load_case(paths[case_id]);source,_=sources(case,base['cache']['source_pad'],20)[0]
        records.append(local_record(case,source,source.anchor_center,base));print('DEBUG real anchor ready '+case_id,flush=True)
    torch.manual_seed(cfg['seed']);model=PromptGraphModel(cfg,base,patient_ids=ids).cuda().eval()
    batch=collate([(materialize(record),i) for i,record in enumerate(records)]).to('cuda')
    with torch.no_grad(),torch.autocast('cuda',dtype=torch.bfloat16):embeddings=model.encode_local(batch).float()
    memory=dict(case_ids=ids,owners=torch.arange(3,device='cuda'),embeddings=embeddings,
        descriptors=context_descriptor(batch),evidence=torch.ones(3,dtype=torch.long,device='cuda'),donor_allowed=torch.ones(3,dtype=torch.bool,device='cuda'))
    scorer=Scorer.__new__(Scorer);scorer.device=torch.device('cuda');scorer.cfg=cfg;scorer.base=base;scorer.model=model;scorer.memory=memory
    payload=dict(split=split,raw_records=[row for row in native['raw_records'] if row['case_id'] in split['outer_train']],
                 donor_pool=pool,config=cfg,scope='DEBUG untrained model integration; not a checkpoint')
    scorer.payload=payload
    sentinel=out/'DEBUG_UNTRAINED_SENTINEL.txt';sentinel.write_text('Explicit DEBUG dependency injection. This file is not a model checkpoint.',encoding='utf-8')
    with patch.object(bank.torch,'load',return_value=payload),patch('hiercp_v2.contracts.validate_checkpoint',return_value=payload):
        catalog=bank.build(native_path,sentinel,out/'bank')
    meta=read_json(catalog);meta.update(debug=True,completion_scope='DEBUG catalog only; untrained scorer injection; forbidden for production training')
    catalog.write_text(json.dumps(meta,indent=2),encoding='utf-8')
    with patch.object(bank,'Scorer',return_value=scorer):builder=bank.EntryBuilder(catalog,threading.RLock())
    donor_index=next(i for i,p in enumerate(pool) if p['case_id']==ids[0])
    torch.cuda.reset_peak_memory_stats()
    result=builder.materialize(target,donor_index)
    reader=SharedDonorBank(catalog);entry=reader._load(result['relative']);index=int(np.argmax(entry['scores']))
    raw,candidate=reader.load_raw_candidate(entry,index)
    output=reader.raw_apply_function()(raw,candidate,np.asarray(candidate['output_bbox']),scale=1.,shift_hu=0.)
    support=output['pasted_support']
    if not support.any() or not np.all(output['seg'][0][support]==2) or not np.isfinite(output['data']).all():
        raise RuntimeError('Native CT/GT paste integration failed')
    box=np.asarray(candidate['output_bbox']);selection=(slice(None),*[slice(int(a),int(b)) for a,b in box])
    baseline=raw['baseline_seg'][selection]
    if not np.array_equal(output['seg'][0][~support],baseline[0][~support]):raise RuntimeError('GT outside pasted support changed')
    for key,digest in before.items():
        case,k=key.split(':')
        if sha(getattr(paths[case],k+'_path'))!=digest:raise RuntimeError('Original CT/GT was modified')
    report=dict(scope='DEBUG real external-donor CP integration with UNTRAINED full-width scorer; not medical evaluation',
        recipient=target,recipient_small_sources=len(inv[target]),donor=pool[donor_index],donor_pool_count=len(pool),
        candidate_count=len(entry['scores']),selected_candidate=index,pasted_native_voxels=int(support.sum()),
        finite_ct=True,gt_outside_pasted_support_unchanged=True,original_CT_GT_sha_unchanged=True,
        full_training=False,full_evaluation=False,peak_vram=torch.cuda.max_memory_allocated(),
        seconds=time.perf_counter()-start,source_identity=source_identity())
    write_new(out/'verification.json',report);print(json.dumps(report,indent=2),flush=True)

if __name__=='__main__':main()
