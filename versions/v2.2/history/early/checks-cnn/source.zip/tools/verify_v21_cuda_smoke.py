"""Synthetic CUDA DEBUG only: full-width L0/L1/L2 BF16 gradient and optimizer check."""
import argparse
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT/'tests')]


def main():
    import torch
    from hiercp_v2.contracts import load_config, verify_v1, write_new, source_identity
    from hiercp_v2.model import PromptGraphModel, prompt_loss, context_descriptor
    from hiercp_v2.data import LocalBatch
    from hiercp.preparation_runtime import snapshot
    from test_hierarchy_model_debug import debug_batch
    from test_prompt_graph_v2_debug import memory_fixture
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    verify_v1()
    if not torch.cuda.is_available():
        raise RuntimeError('CUDA unavailable; no CPU fallback')
    torch.manual_seed(611)
    torch.set_num_threads(4)
    cfg, base = load_config()
    device = torch.device('cuda:0')
    model = PromptGraphModel(cfg, base, patient_ids=['A','B','C']).to(device).train()
    fixture = debug_batch(counts=(2,2), patch_size=48)
    batch = LocalBatch(fixture.local_batch, fixture.source_patches, fixture.target_patches, torch.tensor([0,0,1,1]), torch.arange(4)).to(device)
    memory = {k: v.to(device) if torch.is_tensor(v) else v for k,v in memory_fixture().items()}
    optimizer = torch.optim.AdamW(model.parameters(), lr=base['training']['lr'])
    before = {n:p.detach().clone() for n,p in model.named_parameters()}
    torch.cuda.reset_peak_memory_stats()
    torch.cuda.synchronize()
    started = time.perf_counter()
    with torch.autocast('cuda', dtype=torch.bfloat16):
        query = model.encode_local(batch)
        output = model.forward_tasks(memory, query, torch.tensor([0,1,1,2], device=device))
        loss, _ = prompt_loss(output, context_descriptor(batch), torch.tensor([1,-1,0,1],device=device),cfg['loss_weights'],cfg['temperature'])
    loss.backward()
    missing = [n for n,p in model.named_parameters() if p.grad is None or not torch.isfinite(p.grad).all()]
    if missing or not torch.isfinite(loss):
        raise RuntimeError(f'Missing/nonfinite gradients: {missing}')
    optimizer.step()
    changed = {n:bool(torch.any(before[n]!=p)) for n,p in model.named_parameters()}
    for prefix in ('local.', 'data_projection.', 'patient_labels', 'local_decoder.', 'label_decoder.', 'task.', 'alignment.'):
        names = [n for n in changed if n.startswith(prefix)]
        if names and not any(changed[n] for n in names):
            raise RuntimeError(f'Core module did not update: {prefix}')
    torch.cuda.synchronize()
    report = {'scope':'synthetic CUDA DEBUG; not real-data throughput or final training', 'release':'v2.1',
        'gpu':torch.cuda.get_device_name(), 'capability':torch.cuda.get_device_capability(), 'torch':torch.__version__,
        'cuda_runtime':torch.version.cuda, 'architectures':torch.cuda.get_arch_list(), 'physical_graph_batch':4,
        'parameters':sum(p.numel() for p in model.parameters()), 'patch_size':[48,48,48], 'precision':'BF16 autocast',
        'optimizer_steps':1, 'loss':float(loss.detach()), 'all_gradients_finite':True,
        'peak_vram_bytes':torch.cuda.max_memory_allocated(), 'seconds':time.perf_counter()-started,
        'real_medical_data_used':False, 'full_training_completed':False, 'resources':snapshot(), 'source_identity':source_identity()}
    write_new(args.output, report)
    print(json.dumps(report, indent=2), flush=True)


if __name__ == '__main__':
    main()
