"""CT-only L0 adapting the project's nnU-Net ResEnc M encoder architecture.

No graph, artificial node grid, feature interpolation, annotation input or
unused decoder. This is not a trained nnU-Net segmentation pipeline.
"""
from copy import deepcopy
from torch import nn
from dynamic_network_architectures.building_blocks.residual_encoders import ResidualEncoder
from dynamic_network_architectures.initialization.weight_init import InitWeights_He


class CNNLocalEncoder(nn.Module):
    def __init__(self, architecture, *, input_shape, embedding_dim):
        super().__init__()
        if architecture['network_class_name'] != 'dynamic_network_architectures.architectures.unet.ResidualEncoderUNet':
            raise ValueError('An explicit ResidualEncoderUNet architecture is required')
        kwargs = deepcopy(architecture['arch_kwargs'])
        if kwargs['conv_op'] != 'torch.nn.modules.conv.Conv3d':
            raise ValueError('This encoder requires a 3D CNN architecture')
        if kwargs['norm_op'] != 'torch.nn.modules.instancenorm.InstanceNorm3d':
            raise ValueError('Unexpected normalization in the source architecture')
        if kwargs['nonlin'] != 'torch.nn.LeakyReLU' or kwargs['dropout_op'] is not None:
            raise ValueError('Unsupported source nonlinearity/dropout, no fallback')
        self.input_shape = tuple(input_shape)
        if len(self.input_shape) != 3 or min(self.input_shape) <= 0 or embedding_dim <= 0:
            raise ValueError('Positive input dimensions and embedding width required')
        self.architecture = deepcopy(architecture)
        kwargs.pop('n_conv_per_stage_decoder')
        kwargs.update(conv_op=nn.Conv3d, norm_op=nn.InstanceNorm3d, nonlin=nn.LeakyReLU)
        self.encoder = ResidualEncoder(input_channels=1, return_skips=True, **kwargs)
        self.readout = nn.Sequential(nn.AdaptiveAvgPool3d(1), nn.Flatten(1),
            nn.Linear(kwargs['features_per_stage'][-1], embedding_dim),
            nn.LayerNorm(embedding_dim), nn.SiLU())
        self.encoder.apply(InitWeights_He(1e-2))

    def forward(self, ct, *, return_pyramid=False):
        if ct.ndim != 5 or ct.shape[1] != 1 or tuple(ct.shape[2:]) != self.input_shape:
            raise ValueError(f'CT-only [B,1,{self.input_shape}] input required')
        pyramid = self.encoder(ct)
        embedding = self.readout(pyramid[-1])
        return (embedding, pyramid) if return_pyramid else embedding
