"""v2.2 CNN L0 baseline, separate from historical graph releases."""
