// Isolated JavaScript interaction test; does not drive or access a browser.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const html = fs.readFileSync(process.argv[2], 'utf8');
const payload = /<script type="application\/json" data-role="payload">([\s\S]*?)<\/script>/.exec(html)[1];
const script = /<script>\s*([\s\S]*?)<\/script>/.exec(html)[1];
const elements = new Map();
let paints = 0, saves = 0;
for (const match of html.matchAll(/data-role="([^"]+)"/g)) {
  const role = match[1];
  elements.set(role, {value:'',textContent:role==='payload'?payload:'', handlers:{},
    addEventListener(event, callback){this.handlers[event]=callback;},
    getContext(){return {createImageData:(w,h)=>({data:new Uint8ClampedArray(w*h*4)}),
      putImageData(image){assert.ok(image.data.length>0);paints++;}};}});
}
const events = {};
const sandbox = {Uint8Array, Math, Number, String, JSON, console, atob,
  document:{getElementById(id){assert.equal(id,'v22-cnn-one-case');return {
    querySelector(selector){const role=/data-role="([^"]+)"/.exec(selector)[1];assert.ok(elements.has(role));return elements.get(role);}
  };}},
  window:{openai:{widgetState:null,setWidgetState(state){assert.equal(state.modelContent.trained,false);saves++;return Promise.resolve();}},
    addEventListener(name,callback){events[name]=callback;}}
};
vm.runInNewContext(script,sandbox,{timeout:5000});
assert.equal(paints,2);
let combinations=0;
for(let stage=0;stage<6;stage++) for(let axis=0;axis<3;axis++) {
  elements.get('stage').value=String(stage);elements.get('stage').handlers.change();
  elements.get('axis').value=String(axis);elements.get('axis').handlers.change();
  const slider=elements.get('slice');
  for(const index of [0,Number(slider.max)]) {slider.value=String(index);slider.handlers.input();}
  assert.ok(elements.get('ct-label').textContent.includes(['D','H','W'][axis]));
  combinations++;
}
events['openai:set_globals']({detail:{globals:{widgetState:{privateContent:{stage:2,axis:1,position:5}}}}});
assert.equal(elements.get('stage').value,'2');assert.equal(elements.get('slice').value,'5');
assert.ok(saves>0);
process.stdout.write(JSON.stringify({complete:true,stage_axis_combinations:combinations,paints,saves,
  controls_and_restore_verified:true,browser_render_verified:false})+'\n');
