"""Actual one-case CNN L0 DEBUG execution; no training or learned heatmap claim."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import argparse
import base64
import csv
import hashlib
import importlib.metadata
import inspect
import json
import sys
import time
import numpy as np
import psutil
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from hiercp_v22_cnn.l0 import CNNLocalEncoder
from hiercp_v222.contracts import verify_v1


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(4 * 1024**2), b''):
            h.update(chunk)
    return h.hexdigest()


def write(path, value):
    with path.open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2, allow_nan=False)


def display_volume(array, *, limits=None):
    lo, hi = (float(array.min()), float(array.max())) if limits is None else limits
    if not np.isfinite(array).all() or not hi > lo:
        raise ValueError('Invalid or constant volume for display')
    pixels = np.rint(np.clip((array - lo) / (hi - lo), 0, 1) * 255).astype(np.uint8)
    return dict(shape=list(array.shape), min=lo, max=hi,
                bytes=base64.b64encode(pixels.tobytes()).decode('ascii'))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--profile', default='config/v22_cnn_l0_one_case_debug.json')
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    profile_path = ROOT / args.profile
    profile = json.loads(profile_path.read_text(encoding='utf-8'))
    if not profile['debug'] or profile['whole_training'] or profile['whole_evaluation'] or profile['optimizer_steps'] != 0:
        raise ValueError('Only explicit untrained one-case DEBUG execution is supported')
    if not torch.cuda.is_available():
        raise RuntimeError('CUDA required, no CPU fallback')
    cfg_path = ROOT / profile['model_config']
    cfg = json.loads(cfg_path.read_text(encoding='utf-8'))
    plan_path = ROOT / cfg['architecture_plans']
    plan = json.loads(plan_path.read_text(encoding='utf-8'))
    architecture = plan['configurations'][cfg['architecture_configuration']]['architecture']
    index_path = ROOT / cfg['input_contract_source']
    index = json.loads(index_path.read_text(encoding='utf-8'))
    if profile['case_id'] not in index['split']['inner_train']:
        raise ValueError('One-case diagnostic must use an inner-training case')
    if cfg['input_shape'] != [index['input_contract']['patch_size']] * 3:
        raise ValueError('Stored patch resolution must match the declared L0 input')
    rows = [r for r in index['records'] if r['case_id'] == profile['case_id']]
    if not rows or len(rows) < max(profile['batch_candidates']):
        raise ValueError('Insufficient actual one-case data for requested batch calibration')
    out = Path(args.output).resolve()
    if not out.is_relative_to(ROOT / 'work'):
        raise ValueError('Output must be a new project work directory')
    out.mkdir(parents=True, exist_ok=False)
    torch.manual_seed(profile['seed'])
    torch.cuda.manual_seed_all(profile['seed'])
    torch.set_num_threads(profile['torch_cpu_threads'])
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    resources = dict(gpu=torch.cuda.get_device_name(), gpu_count=torch.cuda.device_count(),
        gpu_total_vram=torch.cuda.get_device_properties(0).total_memory,
        cpu_physical=psutil.cpu_count(logical=False), cpu_logical=psutil.cpu_count(),
        ram_total=psutil.virtual_memory().total, ram_available=psutil.virtual_memory().available,
        drive_free=psutil.disk_usage(str(ROOT)).free)
    frozen = verify_v1()

    def read(row):
        path = index_path.parent / row['patch']
        if sha(path) != row['patch_sha256']:
            raise ValueError(f'CT file content mismatch: {path}')
        array = np.load(path, allow_pickle=False)
        if array.shape != (1, *cfg['input_shape']) or not np.isfinite(array).all():
            raise ValueError(f'Invalid CT patch: {path}')
        return array

    t = time.perf_counter()
    with ThreadPoolExecutor(max_workers=profile['io_workers']) as pool:
        cpu = torch.from_numpy(np.stack(list(pool.map(read, rows)))).pin_memory()
    io_seconds = time.perf_counter() - t
    model = CNNLocalEncoder(architecture, input_shape=cfg['input_shape'],
                            embedding_dim=cfg['embedding_dim']).cuda().eval()
    parameters = sum(p.numel() for p in model.parameters())
    write(out / 'started.json', dict(profile=profile, model_config=cfg, architecture=architecture,
        resources=resources, parameter_count=parameters, trainable_parameters=parameters,
        actual_CT=True, trained=False, optimizer_steps=0, records=rows,
        used_case_records=len(rows), all_case_records=len(rows), case_usage_fraction=1.0,
        all_context_records=len(index['records']), global_case_scope='user_requested_one_case_DEBUG',
        input_contract=index['input_contract'], io_seconds=io_seconds,
        precision='float32', graph_nodes=0, graph_edges=0, feature_interpolation=False,
        architecture_plan_sha256=sha(plan_path), input_index_sha256=sha(index_path),
        profile_sha256=sha(profile_path), model_config_sha256=sha(cfg_path),
        implementation_sha256=sha(ROOT / 'hiercp_v22_cnn/l0.py'), runner_sha256=sha(__file__),
        dynamic_network_architectures_version=importlib.metadata.version('dynamic-network-architectures'),
        encoder_source_sha256=sha(inspect.getfile(type(model.encoder))), frozen_v1=frozen))
    print(json.dumps(dict(stage='started', case=profile['case_id'], records=len(rows),
                         parameters=parameters, architecture=architecture['arch_kwargs'])), flush=True)
    timing = []
    for count in profile['batch_candidates']:
        # Release unused blocks from the previous shape before benchmarking a
        # larger shape. On Windows cached reservations can pressure residency.
        torch.cuda.empty_cache()
        x = cpu[:count].cuda(non_blocking=True)
        torch.cuda.synchronize()
        with torch.inference_mode():
            for _ in range(profile['timing_warmups']):
                model(x)
            torch.cuda.synchronize()
            torch.cuda.reset_peak_memory_stats()
            samples = []
            for _ in range(profile['timing_repeats']):
                t = time.perf_counter()
                y = model(x)
                torch.cuda.synchronize()
                samples.append(time.perf_counter() - t)
            if not torch.isfinite(y).all():
                raise FloatingPointError('Nonfinite CNN output')
        record = dict(physical_batch=count, median_seconds=float(np.median(samples)),
            patches_per_second=count / float(np.median(samples)),
            peak_vram_bytes=torch.cuda.max_memory_allocated(),
            peak_reserved_bytes=torch.cuda.max_memory_reserved())
        timing.append(record)
        with (out / 'batch_progress.jsonl').open('a', encoding='utf-8') as progress:
            progress.write(json.dumps(record) + '\n')
        print(json.dumps(dict(stage='batch_calibration', **record)), flush=True)
        del x, y
    safe = [r for r in timing if r['peak_reserved_bytes'] <=
            resources['gpu_total_vram'] * profile['max_reserved_vram_fraction']]
    if not safe:
        raise RuntimeError('No measured physical batch satisfies the explicit VRAM headroom policy')
    batch = max(safe, key=lambda row: row['patches_per_second'])['physical_batch']
    torch.cuda.empty_cache()
    with (out / 'batch_timing.csv').open('x', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(timing[0])); writer.writeheader(); writer.writerows(timing)
    output = []
    torch.cuda.reset_peak_memory_stats()
    t = time.perf_counter()
    with torch.inference_mode():
        for start in range(0, len(cpu), batch):
            output.append(model(cpu[start:start + batch].cuda(non_blocking=True)).cpu())
    elapsed = time.perf_counter() - t
    embeddings = torch.cat(output).numpy()
    if embeddings.shape != (len(rows), cfg['embedding_dim']) or not np.isfinite(embeddings).all():
        raise ValueError('Incomplete one-case L0 output')
    np.save(out / 'embeddings.npy', embeddings, allow_pickle=False)
    write(out / 'embedding_rows.json', [dict(id=r['id'], center=r['center'], patch_sha256=r['patch_sha256']) for r in rows])
    cohort_peak = torch.cuda.max_memory_allocated()

    # Actual-case regression checks, no synthetic CT and no optimized weights.
    check = cpu[:2].cuda(non_blocking=True)
    with torch.inference_mode():
        pair = model(check)
        one = model(check[:1])
        swapped = model(check.flip(0)).flip(0)
        torch.testing.assert_close(pair[:1], one, rtol=2e-4, atol=2e-4)
        torch.testing.assert_close(pair, swapped, rtol=2e-4, atol=2e-4)
        torch.testing.assert_close(pair.cpu(), torch.from_numpy(embeddings[:2]), rtol=2e-4, atol=2e-4)
        difference = float((pair[0] - pair[1]).abs().max().cpu())
        if difference <= 1e-6:
            raise ValueError('Different actual CT patches produce constant embeddings')
        vector, pyramid = model(check[:1], return_pyramid=True)
        maps = [a[0].cpu().numpy() for a in pyramid]
    np.save(out / 'visual_input.npy', cpu[0].numpy(), allow_pickle=False)
    np.savez_compressed(out / 'visual_feature_pyramid.npz', **{f'stage_{i}': a for i, a in enumerate(maps)})
    del vector, pyramid, pair, one, swapped
    torch.cuda.reset_peak_memory_stats()
    check.requires_grad_(True)
    # This scalar is a Jacobian probe, NOT a clinical task loss or training.
    direction = torch.linspace(-1, 1, cfg['embedding_dim'], device='cuda')
    probe = (model(check) * direction).sum()
    probe.backward()
    missing = [name for name, p in model.named_parameters() if p.requires_grad and p.grad is None]
    invalid = [name for name, p in model.named_parameters() if p.grad is not None and not torch.isfinite(p.grad).all()]
    if missing or invalid or not torch.isfinite(check.grad).all() or not check.grad.abs().sum() > 0:
        raise ValueError(f'Invalid autograd connectivity: missing={missing}, invalid={invalid}')
    gradients = {}
    for name, module in [('stem', model.encoder.stem),
                         *[(f'stage_{i}', v) for i, v in enumerate(model.encoder.stages)], ('readout', model.readout)]:
        total = sum(p.grad.detach().float().square().sum() for p in module.parameters() if p.grad is not None)
        gradients[name] = float(total.sqrt().cpu())
        if gradients[name] <= 0:
            raise ValueError(f'No gradient through {name}')
    backward_peak = torch.cuda.max_memory_allocated()
    model.zero_grad(set_to_none=True)
    display = dict(release='v2.2', case=profile['case_id'], record=rows[0]['id'],
        trained=False, case_records=len(rows), source_sha256=rows[0]['patch_sha256'],
        ct=display_volume(cpu[0, 0].numpy(), limits=(-1.0, 1.0)),
        stages=[dict(channels=a.shape[0], stride=2**i,
                     rms=display_volume(np.sqrt(np.mean(a*a, axis=0)))) for i, a in enumerate(maps)],
        embedding=embeddings[0].tolist(), feature_display='channel_RMS_not_saliency',
        radius_mm=index['input_contract']['outer_radius_mm'],
        ct_clip=index['input_contract']['ct_clip'])
    write(out / 'visual_data.json', display)
    result = dict(complete=True, release='v2.2', implementation_id=cfg['implementation_id'],
        case=profile['case_id'], actual_CT=True, trained=False, optimizer_steps=0,
        whole_training=False, whole_evaluation=False, L1_L2_executed=False,
        records_processed=len(rows), all_records_in_case=len(rows), case_usage_fraction=1.0,
        input_shape=list(cpu.shape), embedding_shape=list(embeddings.shape),
        feature_shapes=[list(a.shape) for a in maps], parameters=parameters,
        chosen_physical_batch=batch, gradient_accumulation_steps=None,
        effective_training_batch=None, inference_seconds=elapsed, patches_per_second=len(rows)/elapsed,
        peak_inference_vram_bytes=cohort_peak, peak_debug_backward_vram_bytes=backward_peak,
        cpu_percent_at_end=psutil.cpu_percent(interval=.2),
        process_RSS_bytes=psutil.Process().memory_info().rss,
        ram_available_bytes=psutil.virtual_memory().available,
        checks=dict(sha_all_case_patches=True, all_outputs_finite=True, batch_independence=True,
            permutation_equivariance=True, first_two_outputs_match_case_run=True,
            actual_input_sensitivity_max_abs=difference, jacobian_probe_only=True,
            gradients_by_module=gradients, no_missing_parameter_gradients=True,
            no_optimizer_updates=True, frozen_v1=verify_v1()),
        limitations=['Untrained initial activations, not learned importance or tumor probabilities.',
            'Encoder-only ResEnc M adaptation with existing 48-cubed L0 input, not full nnU-Net reproduction.',
            'One case only; no CP utility, quality, whole-training or whole-evaluation claim.',
            'Global pooling baseline has not been validated for small-lesion context preservation.'])
    write(out / 'result.json', result)
    print(json.dumps(dict(stage='complete', **result)), flush=True)


if __name__ == '__main__':
    main()
