"""Publish actual CNN activations; never label untrained maps as importance."""
from pathlib import Path
import argparse
import json
import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--run', required=True)
    p.add_argument('--html', required=True)
    args = p.parse_args()
    run = Path(args.run)
    result = json.loads((run / 'result.json').read_text())
    if not result['complete'] or result['trained']:
        raise ValueError('This view requires a completed, explicitly untrained diagnostic')
    data = json.loads((run / 'visual_data.json').read_text())
    template = (ROOT / 'tools/v22_cnn_l0_fragment.html').read_text(encoding='utf-8')
    html = template.replace('__L0_DATA__', json.dumps(data, separators=(',', ':')))
    if '__L0_DATA__' in html or len(html.encode()) >= 1024**2:
        raise ValueError('Invalid or oversized inline visualization')
    with Path(args.html).open('x', encoding='utf-8') as f:
        f.write(html)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    ct = np.load(run / 'visual_input.npy')[0]
    with np.load(run / 'visual_feature_pyramid.npz') as payload:
        maps = [payload[f'stage_{i}'] for i in range(6)]
    fig, axes = plt.subplots(2, 4, figsize=(14, 7.7), layout='constrained')
    axes.flat[0].imshow(ct[24], cmap='gray', vmin=-1, vmax=1, interpolation='nearest')
    axes.flat[0].set_title('Actual CT input | 48 x 48 x 48\nD = 24 | liver_108:0')
    for i, a in enumerate(maps):
        rms = np.sqrt(np.mean(a * a, axis=0))
        plane = min(round(24 / 2**i), rms.shape[0] - 1)
        axes.flat[i+1].imshow(rms[plane], cmap='gray', vmin=float(rms.min()),
                            vmax=float(rms.max()), interpolation='nearest')
        axes.flat[i+1].set_title(f'CNN stage {i+1} | {a.shape[0]} channels\n{a.shape[1]} x {a.shape[2]} x {a.shape[3]} | D = {plane}')
    for ax in axes.flat:
        ax.set_xticks([]); ax.set_yticks([])
    axes.flat[-1].set_axis_off()
    axes.flat[-1].text(.02,.9,'UNTRAINED\n\nActual activation RMS\nNot saliency or probability\n\nAll 187 case patches processed\nOutput: 187 x 128\nNo graph / no node interpolation',
                       va='top', fontsize=12, transform=axes.flat[-1].transAxes)
    fig.suptitle('v2.2 CNN L0 | Real CT, initial weights | Each stage has its own RMS intensity range', fontsize=15)
    fig.savefig(run / 'cnn_l0_preview.png', dpi=130)
    plt.close(fig)
    print(json.dumps({'html_bytes':len(html.encode()),'stages':len(maps),'preview':str(run / 'cnn_l0_preview.png')}))


if __name__ == '__main__':
    main()
