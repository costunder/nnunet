"""Explicit real-CT DEBUG; full architecture/topology, physical CUDA batch 2/4.

Two declared inner-training patients and two placements each are diagnostics,
not a reduced production dataset. Uses the preserved observed-transfer loss;
this term alone admits uniform solutions and is not a complete training objective.
No learned checkpoint or segmentation metric is produced.
"""
from pathlib import Path
import argparse,json,time,sys
from concurrent.futures import ThreadPoolExecutor
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]

def main():
    import numpy as np,torch,psutil
    from hiercp.common import discover_cases,load_case,organ_depth_mm
    from hiercp.schema import graph_config_from_dict
    from hiercp_v22.schema import LOCAL_NODE_TYPES,LOCAL_EDGE_TYPES
    from hiercp_v22.contracts import load_config,verify_v1,read_json,write_new,sha,safe_new_root,source_identity
    from hiercp_v22.data import sources,local_record,candidate_pool,materialize,collate
    from hiercp_v22.geometry import prepare_local_source
    from hiercp_v22.model import PromptGraphModel,prompt_loss
    from hiercp_v2.data import local_record as old_record,materialize as old_materialize
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--medical-root',type=Path,required=True);p.add_argument('--split',type=Path,required=True)
    p.add_argument('--cases',nargs=2,required=True);p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();cfg,base=load_config();verify_v1();split=read_json(args.split)
    if len(set(args.cases))!=2 or not set(args.cases)<=set(split['inner_train']):raise ValueError('Two explicit inner-train cases required')
    if not torch.cuda.is_available():raise RuntimeError('CUDA required; no CPU fallback')
    root=safe_new_root(args.output);torch.set_num_threads(4);began=time.perf_counter()
    paths={c.case_id:c for c in discover_cases(args.medical_root/'Data')}
    resources=dict(gpu=torch.cuda.get_device_name(),gpu_count=torch.cuda.device_count(),vram=torch.cuda.mem_get_info(),
                   logical_cpus=psutil.cpu_count(),ram=psutil.virtual_memory()._asdict(),graph_workers=2,debug=True)
    write_new(root/'started.json',dict(resources=resources,config=cfg,source_identity=source_identity()))
    def build(case_id):
        start=time.perf_counter();case=load_case(paths[case_id]);organ=np.isin(case.label,[1,2]);depth=organ_depth_mm(organ,case.spacing)
        collection=sources(case,base['cache']['source_pad'],20)
        if not len(collection):raise ValueError(f'Explicit DEBUG donor {case_id} has no eligible tumor')
        source,diameter=collection[0]
        prepared=prepare_local_source(case,source,full_organ_mask=organ,organ_depth=depth,
            config=graph_config_from_dict(base['graph']),rng=np.random.default_rng(cfg['seed']),ct_clip=tuple(base['ct_clip']))
        pool,_=candidate_pool(case,source,cfg,base,depth)
        tensors=[];audits=[]
        for label,center in [('T',source.anchor_center),('U',pool[0].center)]:
            fresh=local_record(case,source,center,base,prepared=prepared,depth=depth,organ=organ)
            old=old_record(case,source,center,base,depth=depth,organ=organ)
            g,source_patch,target_patch=materialize(fresh);og,os,ot=old_materialize(old)
            for branch in ('source_local','target_local'):
                for kind in fresh[branch]['nodes']:
                    torch.testing.assert_close(fresh[branch]['nodes'][kind]['pos_mm'],old[branch]['nodes'][kind]['pos_mm'],rtol=0,atol=0)
                for edge in fresh[branch]['edges']:
                    torch.testing.assert_close(fresh[branch]['edges'][edge],old[branch]['edges'][edge],rtol=0,atol=0)
            for kind in LOCAL_NODE_TYPES:torch.testing.assert_close(g[kind].full_id,og[kind].full_id)
            for edge in LOCAL_EDGE_TYPES:torch.testing.assert_close(g[edge].edge_index,og[edge].edge_index)
            torch.testing.assert_close(source_patch,os[:1],rtol=0,atol=0);torch.testing.assert_close(target_patch,ot[:1],rtol=0,atol=0)
            tensors.append((g,source_patch,target_patch))
            audits.append(dict(case=case_id,evidence=label,component=source.component_id,diameter_mm=diameter,
                center=list(map(int,center)),nodes=g.num_nodes,edges=sum(g[e].edge_index.shape[1] for e in g.edge_types),
                canonical_nodes=sum(sum(fresh[b]['counts'].values()) for b in ('source_local','target_local')),
                canonical_edges=sum(sum(fresh[b]['edge_counts'].values()) for b in ('source_local','target_local')),
                ct_shape=list(source_patch.shape),retained_topology_and_CT_equal=True,no_tumor_interior_nodes=True))
        print(json.dumps(dict(case=case_id,graphs=2,seconds=time.perf_counter()-start),ensure_ascii=False),flush=True)
        return tensors,audits,dict(case=case_id,image_sha=sha(paths[case_id].image_path),label_sha=sha(paths[case_id].label_path))
    with ThreadPoolExecutor(max_workers=2) as executor:built=list(executor.map(build,args.cases))
    values=[row for group,_,_ in built for row in group];audit=[row for _,group,_ in built for row in group]
    write_new(root/'geometry.json',dict(graphs=audit,raw=[r for _,_,r in built],full_graph_rules=True,debug_subset=True))
    model=PromptGraphModel(cfg,base,patient_ids=args.cases).cuda().train()
    def forward_loss(batch,owners):
        evidence=torch.where(batch.indices%2==0,1,-1)
        result=model(batch,owners,evidence=evidence,donor_allowed=torch.ones(2,dtype=torch.bool,device='cuda'))
        value,terms=prompt_loss(result,evidence,cfg['loss_weights'])
        if int(terms['supervised_observations'])!=2:raise ValueError('Expected two actual T observations in DEBUG batch')
        return result,value
    reports=[]
    for ids in ([0,2],[0,1,2,3]):
        batch=collate([(values[i],i) for i in ids]).to('cuda')
        owners=torch.tensor([i//2 for i in ids],device='cuda')
        model.zero_grad(set_to_none=True)
        # Warm-up kernels without updating weights.
        with torch.autocast('cuda',dtype=torch.bfloat16):output,loss=forward_loss(batch,owners)
        loss.backward();torch.cuda.synchronize();model.zero_grad(set_to_none=True)
        del loss,output
        torch.cuda.reset_peak_memory_stats();start=time.perf_counter()
        for repeat in range(3):
            with torch.autocast('cuda',dtype=torch.bfloat16):output,loss=forward_loss(batch,owners)
            loss.backward();torch.cuda.synchronize()
            missing=[n for n,v in model.named_parameters() if v.grad is None]
            if missing:raise RuntimeError(f'No gradient: {missing}')
            if not all(torch.isfinite(v.grad).all() for v in model.parameters()):raise FloatingPointError('Nonfinite gradient')
            model.zero_grad(set_to_none=True)
        seconds=time.perf_counter()-start
        report=dict(physical_batch=len(ids),effective_batch=len(ids),gradient_accumulation=1,repeats=3,
            seconds=seconds,graphs_per_second=3*len(ids)/seconds,peak_allocated=torch.cuda.max_memory_allocated(),
            peak_reserved=torch.cuda.max_memory_reserved(),nodes=batch.graph.num_nodes,
            edges=sum(batch.graph[e].edge_index.shape[1] for e in batch.graph.edge_types),
            all_parameter_gradients_finite=True,objective='preserved observed-transfer loss only; incomplete production objective')
        reports.append(report);print(json.dumps(report),flush=True)
        del batch,output,loss;torch.cuda.empty_cache()
    # DEBUG optimizer update on real CT with the existing observed-transfer term only.
    batch=collate([(v,i) for i,v in enumerate(values)]).to('cuda');owners=torch.tensor([0,0,1,1],device='cuda')
    optimizer=torch.optim.AdamW(model.parameters(),lr=1e-4)
    before={n:p.detach().clone() for n,p in model.named_parameters()}
    with torch.autocast('cuda',dtype=torch.bfloat16):output,loss=forward_loss(batch,owners)
    loss.backward();optimizer.step();torch.cuda.synchronize()
    groups=['local.dense_encoder.','local.project.','data_projection.','patient_labels']
    groups += [f'local.blocks.{i}.' for i in range(3)]+[f'task.to_label.{i}.' for i in range(2)]+[f'task.to_data.{i}.' for i in range(2)]
    groups += [f'alignment.layers.{i}.' for i in range(2)]+[f'alignment.updates.{i}.' for i in range(2)]
    updated={g:any(not torch.equal(before[n],p) for n,p in model.named_parameters() if n.startswith(g)) for g in groups}
    if not all(updated.values()):raise RuntimeError(f'Unchanged parameter groups {updated}')
    result=dict(debug=True,actual_CT=True,patients=args.cases,graphs=audit,resources=resources,benchmarks=reports,
        parameter_count=sum(p.numel() for p in model.parameters()),trainable_parameter_count=sum(p.numel() for p in model.parameters() if p.requires_grad),
        updated_groups=updated,source_identity=source_identity(),elapsed_seconds=time.perf_counter()-began,
        full_training=False,full_evaluation=False,L2_forward_restored=True,observed_transfer_loss=True,full_training_objective_complete=False,checkpoint_created=False,
        limitation='Actual T/U DEBUG validates CT through L2 and observed loss gradients only. T/U-only loss admits uniform solutions; no ranking or segmentation quality claim.')
    write_new(root/'verification.json',result)
    print(str(root/'verification.json'),flush=True)

if __name__=='__main__':main()
