"""Full-cohort, source-resolved local graph caches; no v1 upper graphs."""
from __future__ import annotations
from dataclasses import dataclass,replace
from pathlib import Path
import math
import numpy as np
import torch
from torch.utils.data import Dataset
from torch_geometric.data import Batch
from scipy import ndimage as ndi
from hiercp.common import (discover_cases,load_case,SourceTumor,bbox_of_mask,organ_depth_mm,stable_case_seed,build_candidate_pool)
from hiercp.curriculum import CandidateSpec
from hiercp.local import prepare_local_source,build_local_graph
from hiercp.sample import build_local_view
from hiercp.schema import graph_config_from_dict
from hiercp.preparation_runtime import run_case_jobs
from .contracts import read_json,write_new,sha,safe_new_root,validate_split
from . import PIPELINE_VERSION
from .storage import GraphWriter,load_record

class SourceCollection:
    """Repeatable source sequence; retain one component map, not N full masks."""
    def __init__(self,case,pad,maximum):
        self.case,self.pad=case,pad
        self.components,count=ndi.label(case.label==2,structure=ndi.generate_binary_structure(3,1))
        self.sizes=np.bincount(self.components.ravel(),minlength=count+1)
        self.entries=[]
        for component in range(1,count+1):
            diameter=2*(3*int(self.sizes[component])*float(np.prod(case.spacing))/(4*math.pi))**(1/3)
            if diameter<=maximum:self.entries.append((component,diameter))
    def __len__(self):return len(self.entries)
    def __getitem__(self,index):
        component,diameter=self.entries[index]; case=self.case
        mask=self.components==component; box=bbox_of_mask(mask,pad=self.pad)
        center=tuple((s.start+s.stop-1)//2 for s in box)
        return SourceTumor(component,mask,mask[box].copy(),case.image[box].copy(),box,center,
                        tuple(np.argwhere(mask).mean(0)),int(self.sizes[component])),diameter
    def __iter__(self):
        for index in range(len(self)):yield self[index]

def sources(case,pad,maximum):return SourceCollection(case,pad,maximum)

def candidate_spec(source,center,coverage=1.):
    # These legacy transport fields never enter an upper graph in v2.
    return CandidateSpec(tuple(map(int,center)),0,0,-1,-1,float(coverage),0.,0.,0.,0.)

def local_record(case,source,center,base,*,prepared=None,depth=None,organ=None):
    gc=graph_config_from_dict(base['graph']); organ=np.isin(case.label,[1,2]) if organ is None else organ
    depth=organ_depth_mm(organ,case.spacing) if depth is None else depth
    rng=np.random.default_rng(stable_case_seed(base['seed'],case.paths.case_id,str(source.component_id)))
    prepared=prepared or prepare_local_source(case,source,full_organ_mask=organ,organ_depth=depth,config=gc,rng=rng,ct_clip=tuple(base['ct_clip']))
    built=build_local_graph(case,source,candidate_spec(source,center),full_organ_mask=organ,organ_depth=depth,
                            config=gc,rng=rng,ct_clip=tuple(base['ct_clip']),prepared_source=prepared)
    return {'format':PIPELINE_VERSION,'case_id':case.paths.case_id,'component_id':source.component_id,
            'seed':base['seed'],
            'source_patch':torch.from_numpy(built.source_patch).half(),'target_patch':torch.from_numpy(built.target_patch).half(),
            'source_local':built.source_local,'target_local':built.target_local,'graph_config':gc.to_dict()}

def candidate_pool(case,source,cfg,base,depth):
    settings=base['generation']; organ=np.isin(case.label,[1,2]); diagnostics={}
    pool,_=build_candidate_pool(case,source,placement_mask=case.label==1,full_organ_mask=organ,
        occupied_mask=case.label==2,organ_distance=depth,
        rng=np.random.default_rng(stable_case_seed(cfg['seed'],case.paths.case_id,str(source.component_id))),
        num_candidates=cfg['candidate_count'],max_draws=settings['max_draws'],
        min_liver_coverage=settings['min_liver_coverage'],occupied_clearance_vox=settings['occupied_clearance_vox'],
        min_center_separation_mm=settings['min_center_separation_mm'],
        min_center_separation_vox=settings['min_center_separation_vox'],diagnostics=diagnostics)
    if len(pool)!=cfg['candidate_count']: raise ValueError('Complete candidate pool required; no source silently dropped')
    return pool,diagnostics

def donor_in_target_spacing(source,donor_spacing,target_spacing):
    """Real donor regridded about its exact anchor for context-only foreign queries.

    No patient GT is changed. Source node physical coordinates remain from the
    donor; only the virtual target footprint uses target-native spacing.
    """
    anchor=np.asarray(source.anchor_center)-np.asarray([s.start for s in source.patch_slices])
    shape=np.asarray(source.patch_mask.shape)
    before=np.ceil(anchor*donor_spacing/target_spacing).astype(int)
    after=np.ceil((shape-1-anchor)*donor_spacing/target_spacing).astype(int)
    new_shape=before+after+1
    axes=np.indices(tuple(new_shape),dtype=np.float64)
    coordinates=(axes-before[:,None,None,None])*target_spacing[:,None,None,None]/donor_spacing[:,None,None,None]+anchor[:,None,None,None]
    mask=ndi.map_coordinates(source.patch_mask.astype(np.uint8),coordinates,order=0,mode='constant',cval=0)>0
    image=ndi.map_coordinates(source.patch_image,coordinates,order=1,mode='nearest').astype(np.float32)
    if not mask.any(): raise ValueError('Real donor disappears at target spacing; no fabricated footprint')
    # build_candidate_pool only consumes the real resampled patch fields.
    return replace(source,patch_mask=mask,patch_image=image,voxel_count=int(mask.sum()),
                   anchor_center=tuple(map(int,before)),patch_slices=tuple(slice(0,int(s)) for s in new_shape)),mask

def prepare(medical,split_path,output,cfg,base):
    split=read_json(split_path); validate_split(split)
    paths={c.case_id:c for c in discover_cases(Path(medical)/'Data')}
    if set(split['outer_train']+split['outer_val'])!=set(paths): raise ValueError('Split must match complete cohort')
    root=safe_new_root(output); records=[]; cases=[]; storage=GraphWriter(root)
    write_new(root/'split.json',split); write_new(root/'config.json',cfg); write_new(root/'base_config.json',base)
    # Full scan establishes real donor IDs, including patients without eligible T.
    donor_ids={}
    def scan(case_id):
        case=load_case(paths[case_id])
        collection=sources(case,base['cache']['source_pad'],cfg['donor_max_diameter_mm'])
        return case_id,[component for component,_ in collection.entries]
    run_case_jobs(tasks=split['outer_train'],function=scan,commit=lambda item:donor_ids.__setitem__(*item),
                  workers=cfg['preparation_workers'],report_path=root/'source_inventory_resources.json')
    if sum(bool(donor_ids[c]) for c in split['inner_train'])<2:
        raise ValueError('Cross-patient training needs observed positive donors from at least two inner-training patients')
    total_sources=sum(len(donor_ids[c]) for c in split['inner_train'])
    expected={c:len(donor_ids[c])*129 if donor_ids[c] else total_sources*128 for c in split['outer_train']}
    write_new(root/'source_inventory.json',{'sources':donor_ids,'expected_graphs_per_case':expected,'total_graphs':sum(expected.values()),'storage':'lossless_gzip_shared_source_v1'})
    print({'stage':'source_inventory_complete','total_graphs':sum(expected.values())},flush=True)
    def one(case_id):
        case=load_case(paths[case_id]); rows=[]; audits=[]
        organ=np.isin(case.label,[1,2]); depth=organ_depth_mm(organ,case.spacing)
        # A no-positive patient receives context queries from ALL inner-train
        # donor templates, not a fake tumor or an arbitrary one-donor fallback.
        origins=[case_id] if donor_ids[case_id] else [c for c in split['inner_train'] if donor_ids[c]]
        for donor_id in origins:
            donor=case if donor_id==case_id else load_case(paths[donor_id])
            donor_depth=depth if donor_id==case_id else organ_depth_mm(np.isin(donor.label,[1,2]),donor.spacing)
            for original,diameter in sources(donor,base['cache']['source_pad'],cfg['donor_max_diameter_mm']):
                prepared=prepare_local_source(donor,original,full_organ_mask=np.isin(donor.label,[1,2]),
                    organ_depth=donor_depth,config=graph_config_from_dict(base['graph']),
                    rng=np.random.default_rng(cfg['seed']),ct_clip=tuple(base['ct_clip']))
                source=original
                if donor_id!=case_id:
                    source,footprint=donor_in_target_spacing(original,donor.spacing,case.spacing)
                    # exact_source_footprint centers arbitrary donor anchors first.
                    from hiercp.local import exact_source_footprint
                    prepared=replace(prepared,source_footprint=exact_source_footprint(source))
                pool,audit=candidate_pool(case,source,cfg,base,depth)
                points=([(source.anchor_center,1)] if donor_id==case_id else [])+[(p.center,-1) for p in pool]
                for index,(center,evidence) in enumerate(points):
                    record=local_record(case,source,center,base,prepared=prepared,depth=depth,organ=organ)
                    record.update(donor_case_id=donor_id,evidence=evidence,center=list(center))
                    record['target_virtual_footprint_voxels']=int(prepared.source_footprint.sum())
                    record['source_local']['footprint_voxels']=int(original.voxel_count)
                    record['donor_spacing']=donor.spacing.tolist(); record['target_spacing']=case.spacing.tolist()
                    relative=f'graphs/{case_id}/{donor_id}__{source.component_id:05d}__{index:04d}.pt.gz'
                    saved=storage.write(relative,record,(case_id,donor_id,source.component_id))
                    rows.append({'id':f'{case_id}:{donor_id}:{source.component_id}:{index}',
                        'case_id':case_id,'donor_case_id':donor_id,'component_id':source.component_id,
                        'evidence':evidence,'diameter_mm':diameter,'center':list(map(int,center)),
                        **saved})
                audits.append(dict(donor_case_id=donor_id,component_id=source.component_id,
                                   candidates=len(pool),search=audit))
        return rows,{'case_id':case_id,'sources':len(donor_ids[case_id]),'context_records':len(rows),
            'status':'observed_T_and_U' if donor_ids[case_id] else 'U_only_real_external_donor_contexts',
            'image':str(paths[case_id].image_path.resolve()),'image_sha256':sha(paths[case_id].image_path),
            'label':str(paths[case_id].label_path.resolve()),'label_sha256':sha(paths[case_id].label_path),
            'candidate_audits':audits}
    def commit(result):
        rows,case=result; records.extend(rows); cases.append(case)
        print({'stage':'patient_graphs_complete','case_id':case['case_id'],'graphs':len(rows),'completed_patients':len(cases)},flush=True)
    run_case_jobs(tasks=split['outer_train'],function=one,commit=commit,
                  workers=cfg['preparation_workers'],report_path=root/'resources.json')
    write_new(root/'index.json',{'format':PIPELINE_VERSION,'complete':True,'split':split,
        'records':sorted(records,key=lambda r:r['id']),'cases':sorted(cases,key=lambda r:r['case_id']),
        'config':cfg,'base_config':base,'evidence_contract':cfg['evidence_contract'],
        'hard_F_policy':'geometrically invalid placements are excluded before L0/CP; normal liver remains U'})
    return root/'index.json'

class LocalDataset(Dataset):
    def __init__(self,root,rows,*,view=0,epoch=0,verify=True):
        self.root=Path(root); self.rows=list(rows); self.view=view; self.epoch=epoch
        if verify:
            for row in rows:
                if sha(self.root/row['path'])!=row['sha256']: raise ValueError('Local cache SHA mismatch')
    def __len__(self): return len(self.rows)
    def __getitem__(self,index):
        row=self.rows[index]
        record=load_record(self.root,row['path'])
        return materialize(record,view=self.view,epoch=self.epoch),index

def materialize(record,view=0,epoch=0):
    if record['format']!=PIPELINE_VERSION: raise ValueError('Wrong local cache version')
    seed=stable_case_seed(record['seed'],record['case_id'],f"{record['component_id']}:{view}:{epoch}")
    graph=build_local_view(record['source_local'],record['target_local'],graph_config_from_dict(record['graph_config']),seed=seed)
    return graph,record['source_patch'],record['target_patch']

@dataclass
class LocalBatch:
    graph: Batch
    source_patches: torch.Tensor
    target_patches: torch.Tensor
    source_index: torch.Tensor
    indices: torch.Tensor
    def to(self,device):
        self.graph=self.graph.to(device)
        self.source_patches=self.source_patches.to(device,non_blocking=True).float()
        self.target_patches=self.target_patches.to(device,non_blocking=True).float()
        self.source_index=self.source_index.to(device,non_blocking=True)
        self.indices=self.indices.to(device)
        return self
    def pin_memory(self):
        self.graph=self.graph.pin_memory()
        for key in ('source_patches','target_patches','source_index','indices'):
            setattr(self,key,getattr(self,key).pin_memory())
        return self

def collate(items):
    payload,indices=zip(*items); graphs,sources_,targets=zip(*payload)
    return LocalBatch(Batch.from_data_list(list(graphs)),torch.stack(sources_),torch.stack(targets),
                      torch.arange(len(items)),torch.tensor(indices))
