"""New v2 scores + the unchanged raw-target/native CP transport contract."""
from pathlib import Path
import numpy as np
import torch
from hiercp.common import discover_cases,load_case,organ_depth_mm,build_candidate_pool,stable_case_seed
from hiercp.local import prepare_local_source
from hiercp.schema import graph_config_from_dict
from hiercp.preparation_runtime import run_case_jobs
from tools.online_raw_bank_preparation import prepare_raw_case,prepare_source_candidates
from . import PIPELINE_VERSION
from .contracts import read_json,write_new,safe_new_root,sha,validate_native
from .data import sources,local_record
from .scoring import Scorer

def map_center(point,plans,properties,shape):
    xyz=np.asarray(point,dtype=np.float64)[::-1][plans['transpose_forward']]
    crop=xyz-np.asarray(properties['bbox_used_for_cropping'])[:,0]
    return np.rint((crop+.5)*np.asarray(shape)/np.asarray(properties['shape_after_cropping_and_before_resampling'])-.5).astype(np.int32)

def build(native_path,checkpoint,output):
    from nnunetv2.training.dataloading.nnunet_dataset import infer_dataset_class
    native=validate_native(read_json(native_path))
    if native['format']!=PIPELINE_VERSION: raise ValueError('v2 native preparation required')
    scorer=Scorer(checkpoint); cfg,base=scorer.cfg,scorer.base
    if native['split']!=scorer.payload['split']: raise ValueError('Bank/native/GNN patient split differs')
    raw_records={r['case_id']:r for r in native['raw_records']}
    for row in scorer.payload['raw_records']:
        for key in ('image','label'):
            if row[key+'_sha256']!=raw_records[row['case_id']][key+'_sha256']:
                raise ValueError('GNN/native raw cohort content differs')
    for row in native['raw_records']:
        for key in ('image','label'):
            if sha(row[key])!=row[key+'_sha256']: raise ValueError('Original raw data changed since preparation')
    paths={p.case_id:p for p in discover_cases(Path(native['medical'])/'Data')}
    root=safe_new_root(output); (root/'entries').mkdir()
    plans=read_json(native['plans']); plan=plans['configurations']['3d_fullres']
    pre_root=Path(native['preprocessed'])/plan['data_identifier']
    dataset=infer_dataset_class(str(pre_root))(str(pre_root),native['split']['outer_train'])
    entries={}; inventory={}; slots={}; hashes={}; manifests=[]
    for case_id in native['split']['outer_train']:
        raw=load_case(paths[case_id]); pre,seg,_,props=dataset.load_case(case_id)
        organ=np.isin(raw.label,[1,2]); depth=organ_depth_mm(organ,raw.spacing)
        source_list=sources(raw,base['generation']['source_pad'],cfg['donor_max_diameter_mm'])
        inventory[case_id]=[s.component_id for s,_ in source_list]; slots[case_id]=[]
        if not source_list: continue
        native_case,case_ref,case_sha=prepare_raw_case(root,case_id,raw.image,raw.label,props,plans,pre,seg,
            configuration_name='3d_fullres',raw_spacing=raw.spacing,raw_spatial_unit=raw.image_header.get_xyzt_units()[0],
            minimum_free_bytes=int(cfg['minimum_free_gb']*1024**3))
        for source,diameter in source_list:
            generation=base['generation']; diagnostics={}
            pool,_=build_candidate_pool(raw,source,placement_mask=raw.label==1,full_organ_mask=organ,
                occupied_mask=raw.label==2,organ_distance=depth,rng=np.random.default_rng(stable_case_seed(cfg['seed'],case_id,str(source.component_id))),
                num_candidates=cfg['candidate_count'],max_draws=generation['max_draws'],min_liver_coverage=generation['min_liver_coverage'],
                occupied_clearance_vox=generation['occupied_clearance_vox'],min_center_separation_mm=generation['min_center_separation_mm'],
                min_center_separation_vox=generation['min_center_separation_vox'],diagnostics=diagnostics)
            if len(pool)!=cfg['candidate_count']:
                raise ValueError(f'{case_id}/{source.component_id}: incomplete candidate pool; source not silently skipped')
            centers=np.asarray([p.center for p in pool],dtype=np.int32)
            mapped=np.stack([map_center(p.center,plans,props,pre.shape[1:]) for p in pool])
            if np.any(mapped<0) or np.any(mapped>=np.asarray(pre.shape[1:])):
                raise ValueError('Mapped candidate outside native volume')
            prepared=prepare_local_source(raw,source,full_organ_mask=organ,organ_depth=depth,
                config=graph_config_from_dict(base['graph']),rng=np.random.default_rng(cfg['seed']),ct_clip=tuple(base['ct_clip']))
            graph_rows={}
            def build_graph(item):
                index,center=item
                r=local_record(raw,source,center,base,prepared=prepared,depth=depth)
                relative=f'graphs/{case_id}__{source.component_id:05d}/{index:04d}.pt'; file=root/relative
                file.parent.mkdir(parents=True,exist_ok=True)
                with file.open('xb') as f: torch.save(r,f)
                return index,{'id':f'{case_id}:{source.component_id}:{index}','case_id':case_id,'path':relative,'sha256':sha(file)}
            def commit(result): graph_rows[result[0]]=result[1]
            run_case_jobs(tasks=list(enumerate([source.anchor_center,*centers.tolist()])),function=build_graph,commit=commit,
                workers=cfg['preparation_workers'],report_path=root/f'resources_{case_id}_{source.component_id}.json')
            score,resources=scorer.score(root,graph_rows[0],[graph_rows[i] for i in range(1,129)],case_id)
            write_new(root/f'scoring_{case_id}_{source.component_id}.json',resources)
            anchor=np.asarray(source.anchor_center)-np.asarray([s.start for s in source.patch_slices])
            refs,digests,audit=prepare_source_candidates(root,case_id,source.component_id,native_case,case_sha,
                source.patch_image,source.patch_mask,anchor,centers,plan['patch_size'])
            relative=f'entries/{case_id}__{source.component_id:05d}.npz'; file=root/relative
            with file.open('xb') as f:
                np.savez(f,paste_contract=np.asarray(['onlinecp_raw_target_paste_v1']),case_id=np.asarray([case_id]),
                    candidate_payloads=refs,candidate_payload_sha256=digests,raw_case_reference=np.asarray([case_ref]),
                    raw_case_reference_sha256=np.asarray([case_sha]),candidate_centers=mapped,candidate_raw_centers=centers,
                    scores=score,source_component=np.asarray([source.component_id],dtype=np.int64),source_diameter_mm=np.asarray([diameter],dtype=np.float32))
            entries.setdefault(case_id,[]).append(relative); hashes[relative]=sha(file)
            slots[case_id].append({'source_component':source.component_id,'status':'ok','entry':relative})
            manifests.append({'case_id':case_id,'source_component':source.component_id,'candidate_count':len(pool),'audit':audit,'search':diagnostics})
    if not entries: raise ValueError('No usable source; bank not published')
    index={'format':'hiercp_online_bank_v2','pipeline_version':PIPELINE_VERSION,'complete':True,
        'paste_contract':'onlinecp_raw_target_paste_v1','entry_storage':'npz_candidate_refs_raw_target_v1',
        'source_mapping_policy':'online_cp_raw_target_resampling_v2','candidate_count':128,'hier_top_k':1,
        'tumor_label':2,'liver_label':1,'cp_probability':.5,'intensity_scale_range':[.95,1.05],
        'intensity_shift_range_hu':[-5.,5.],'entries_by_case':entries,'entry_sha256':hashes,
        'no_placement_policy':'retain_original','source_schedule_format':'onlinecp_all_source_slots_v1',
        'source_slots_by_case':slots,'eligible_sources_by_case':inventory,'eligible_source_slots':sum(map(len,slots.values())),
        'no_placement_sources':0,'split':native['split'],'checkpoint':str(Path(checkpoint).resolve()),'checkpoint_sha256':sha(checkpoint),
        'native_preparation':str(Path(native_path).resolve()),'native_sha256':sha(native_path),
        'selection':cfg['selection'],'label_semantics':cfg['label_definition'],'alignment_semantics':cfg['alignment_target']}
    write_new(root/'manifest.json',manifests); write_new(root/'index.json',index)
    return root/'index.json'
