"""DEBUG synthetic volumes: real local construction, cache IO and size metrics."""
import csv
import hashlib
import tempfile
import unittest
from pathlib import Path
from zipfile import ZipFile
import numpy as np
import nibabel as nib
import torch
from hiercp.common import LoadedCase,CasePaths
from hiercp_v2 import PIPELINE_VERSION
from hiercp_v2.contracts import load_config,write_new,sha,validate_native,verify_v1
from hiercp_v2.data import sources,local_record,LocalDataset,collate,donor_in_target_spacing
from hiercp_v2.training import full_inventory
from hiercp_v2.evaluation import evaluate


class PromptGraphV2IODebugTests(unittest.TestCase):
    def preserved_fixture(self,root):
        directory=root/'versions/v1'; directory.mkdir(parents=True)
        originals={'gpt_handoff.md':b'old handoff','code.txt':b'old code export','runtime.py':b'value=1'}
        archive=directory/'pipeline_v1_source.zip'
        with ZipFile(archive,'x') as f:
            for name,content in originals.items():
                f.writestr(name,content); (root/name).write_bytes(content)
        write_new(directory/'manifest.json',dict(revision='DEBUG',archive_sha256=sha(archive),
                    files={name:hashlib.sha256(content).hexdigest() for name,content in originals.items()}))
        return archive

    def test_handoff_refresh_keeps_runtime_guard_exact(self):
        with tempfile.TemporaryDirectory(prefix='prompt_v2_debug_') as name:
            root=Path(name); self.preserved_fixture(root)
            (root/'gpt_handoff.md').write_bytes(b'new handoff'); (root/'code.txt').write_bytes(b'new export')
            self.assertEqual(verify_v1(root),'DEBUG')
            (root/'runtime.py').write_bytes(b'value=2')
            with self.assertRaisesRegex(ValueError,'v1 source changed'): verify_v1(root)

    def test_changed_v1_archive_is_rejected(self):
        with tempfile.TemporaryDirectory(prefix='prompt_v2_debug_') as name:
            root=Path(name); archive=self.preserved_fixture(root)
            with archive.open('ab') as f: f.write(b'changed')
            with self.assertRaisesRegex(ValueError,'archive changed'): verify_v1(root)

    def test_actual_full_config_geometry_cache_and_batch(self):
        cfg,base=load_config()
        grid=np.indices((64,64,64)); organ=((grid-32)**2).sum(0)<28**2
        tumor=((grid-np.array([25,30,32])[:,None,None,None])**2).sum(0)<4**2
        labels=np.zeros(organ.shape,np.uint8); labels[organ]=1; labels[tumor]=2
        image=(40+grid[0]+grid[1]*.3-grid[2]*.1).astype(np.float32)
        case=LoadedCase(CasePaths('DEBUG_GEOMETRY',Path('unused_image'),Path('unused_label')),image,labels,
                        np.eye(4),np.eye(4),None,None,np.ones(3),{}, {})
        source_list=sources(case,base['cache']['source_pad'],cfg['donor_max_diameter_mm'])
        self.assertEqual(len(source_list),1)
        source,diameter=source_list[0]
        self.assertLessEqual(diameter,20)
        record=local_record(case,source,(38,32,32),base)
        self.assertEqual(record['source_patch'].shape,(5,48,48,48))
        with tempfile.TemporaryDirectory(prefix='prompt_v2_debug_') as name:
            root=Path(name); torch.save(record,root/'graph.pt')
            row={'id':'debug:1','path':'graph.pt','sha256':sha(root/'graph.pt')}
            ds=LocalDataset(root,[row,row]); batch=collate([ds[0],ds[1]])
            self.assertEqual(batch.graph.num_graphs,2)
            self.assertEqual(batch.source_patches.shape,(2,5,48,48,48))
            inventory=full_inventory(root,[row,row])
            self.assertGreater(inventory[0]['nodes'],0); self.assertGreater(inventory[0]['edges'],0)
            self.assertEqual(batch.source_index.tolist(),[0,1])
            row['sha256']='0'*64
            with self.assertRaisesRegex(ValueError,'SHA'): LocalDataset(root,[row])

    def test_foreign_real_donor_footprint_does_not_change_target_GT(self):
        from hiercp.local import prepare_local_source,exact_source_footprint
        from hiercp.schema import graph_config_from_dict
        from hiercp.common import organ_depth_mm
        from dataclasses import replace
        cfg,base=load_config()
        grid=np.indices((64,64,64)); organ=((grid-32)**2).sum(0)<28**2
        tumor=((grid-30)**2).sum(0)<4**2
        labels=organ.astype(np.uint8); labels[tumor]=2
        image=(grid[0]+grid[1]+30).astype(np.float32)
        donor=LoadedCase(CasePaths('DEBUG_DONOR',Path('unused'),Path('unused')),image,labels,np.eye(4),np.eye(4),None,None,np.ones(3),{}, {})
        target=replace(donor,paths=CasePaths('DEBUG_NO_T',Path('unused'),Path('unused')),label=organ.astype(np.uint8),spacing=np.array([1.5,1.,.8]))
        source,_=sources(donor,2,20)[0]
        template,_=donor_in_target_spacing(source,donor.spacing,target.spacing)
        prepared=prepare_local_source(donor,source,full_organ_mask=organ,organ_depth=organ_depth_mm(organ,donor.spacing),
            config=graph_config_from_dict(base['graph']),rng=np.random.default_rng(42),ct_clip=tuple(base['ct_clip']))
        prepared=replace(prepared,source_footprint=exact_source_footprint(template))
        before=target.label.copy(); before_ct=target.image.copy()
        record=local_record(target,template,(32,32,32),base,prepared=prepared)
        self.assertEqual(record['case_id'],'DEBUG_NO_T')
        self.assertGreater(record['source_local']['footprint_voxels'],0)
        np.testing.assert_array_equal(before,target.label); np.testing.assert_array_equal(before_ct,target.image)
        self.assertFalse(np.any(target.label==2))

    def test_full_cohort_csv_metrics_and_native_tamper_guard(self):
        with tempfile.TemporaryDirectory(prefix='prompt_v2_debug_') as name:
            root=Path(name); raw=root/'raw'; pre=root/'pre'; pred=root/'pred'
            (raw/'imagesTr').mkdir(parents=True); (raw/'labelsTr').mkdir(); pre.mkdir(); pred.mkdir()
            split=dict(inner_train=['a'],inner_val=['b'],outer_train=['a','b'],outer_val=['c','d'])
            records=[]
            for case in ['a','b','c','d']:
                label=np.zeros((20,20,20),np.uint8)
                if case=='c': label[3:6,3:6,3:6]=2
                image=nib.Nifti1Image(label.astype(np.float32),np.eye(4)); image.header.set_xyzt_units('mm')
                lab=nib.Nifti1Image(label,np.eye(4)); lab.header.set_xyzt_units('mm')
                ip=raw/'imagesTr'/f'{case}_0000.nii.gz'; lp=raw/'labelsTr'/f'{case}.nii.gz'
                nib.save(image,ip); nib.save(lab,lp)
                records.append(dict(case_id=case,image=str(ip),image_sha256=sha(ip),label=str(lp),label_sha256=sha(lp)))
                if case in split['outer_val']: nib.save(lab,pred/f'{case}.nii.gz')
            write_new(pre/'plans.json',{}); write_new(pre/'splits_final.json',[{'train':['a','b'],'val':['c','d']}])
            native=dict(format=PIPELINE_VERSION,complete=True,split=split,raw=str(raw),raw_records=records,
                        preprocessed=str(pre),plans=str(pre/'plans.json'),plans_sha256=sha(pre/'plans.json'),splits_sha256=sha(pre/'splits_final.json'))
            write_new(root/'native.json',native)
            result=evaluate(root/'native.json',pred,root/'metrics',debug=True)
            with (result/'size_metrics.csv').open(encoding='utf-8-sig') as f: rows=list(csv.DictReader(f))
            small=[r for r in rows if r['size_bin']=='le_10mm']
            self.assertEqual(len(small),6)
            self.assertTrue(all(r['gt']=='1' and r['recall']=='1.0' and r['mean_lesion_dice']=='1.0' for r in small))
            self.assertTrue(all(r['recall']=='' for r in rows if r['size_bin']=='gt_20mm'))
            (pre/'plans.json').write_text('{"changed":true}',encoding='utf-8')
            with self.assertRaisesRegex(ValueError,'plans/split changed'): validate_native(native)


if __name__=='__main__': unittest.main()
