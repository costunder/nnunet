"""Record DEBUG verification explicitly separately from medical experiments."""
import argparse
import ast
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))


def main():
    from hiercp_v2.contracts import safe_new_root,write_new,verify_v1,source_identity
    from hiercp.preparation_runtime import snapshot
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',required=True)
    args=parser.parse_args(); out=safe_new_root(args.output)
    sources=list((ROOT/'hiercp_v2').glob('*.py'))+[ROOT/'run_v1.py',ROOT/'run_v2.py',Path(__file__)]
    sources+=list((ROOT/'tests').glob('test_prompt_graph_v2*debug.py'))
    for path in sources:
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    env=os.environ.copy(); env['PYTHONIOENCODING']='utf-8'
    env['PYTHONPATH']=os.pathsep.join([str(ROOT),str(ROOT/'tests'),env.get('PYTHONPATH','')])
    started=time.perf_counter()
    command=[sys.executable,'-m','unittest','test_prompt_graph_v2_debug','test_prompt_graph_v2_io_debug','test_gpt_handoff_export_debug','-v']
    run=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,text=True,encoding='utf-8')
    with (out/'tests.txt').open('x',encoding='utf-8') as f: f.write(run.stdout+'\n'+run.stderr)
    report={'scope':'synthetic DEBUG unit/integration/smoke only','v1_revision':verify_v1(),
        'static_files':len(sources),'static_passed':True,'test_command':command,'test_returncode':run.returncode,
        'seconds':time.perf_counter()-started,'resources':snapshot(),'source_identity':source_identity(),
        'nnunet_installed':importlib.util.find_spec('nnunetv2') is not None,
        'real_medical_data_used':False,'full_gnn_training':False,'full_segmentation_training':False,
        'full_medical_evaluation':False,'native_end_to_end_execution':False,'target_gpu_throughput_benchmarked':False}
    write_new(out/'verification.json',report)
    print(run.stdout,run.stderr); print(out/'verification.json')
    if run.returncode: raise RuntimeError('DEBUG tests failed; preserved diagnostics above')


if __name__=='__main__': main()
