"""L0 local encoding -> L1 prompt task graph -> L2 task-label alignment.

L1 labels are task-local pseudo labels. Queries never send messages to support
or label states. L2 learns soft cross-task correspondence from shared supports,
not from an assumed absolute ordering or a hard-coded population atlas.
"""
from __future__ import annotations
from dataclasses import dataclass
import math
import torch
from torch import nn
from torch.nn import functional as F

@dataclass
class TaskOutput:
    query: torch.Tensor
    labels: torch.Tensor
    logits: torch.Tensor

def distribution_js(p, q):
    m = (p + q) * .5
    return .5 * ((p * (p.clamp_min(1e-8).log()-m.clamp_min(1e-8).log())).sum(-1)
                 + (q * (q.clamp_min(1e-8).log()-m.clamp_min(1e-8).log())).sum(-1)).mean()

class TypedAttention(nn.Module):
    """Batched attention with T/F/unknown edge messages, no label-ID embedding."""
    def __init__(self, dim, heads, dropout, relation_count=2):
        super().__init__()
        self.heads, self.width = heads, dim // heads
        if dim % heads: raise ValueError('hidden dimension must divide heads')
        self.q, self.k, self.v = (nn.Linear(dim, dim, bias=False) for _ in range(3))
        self.relation_count = relation_count
        self.edge_key = nn.Embedding(relation_count, dim) if relation_count else None
        self.edge_value = nn.Embedding(relation_count, dim) if relation_count else None
        self.out = nn.Linear(dim, dim)
        self.norm = nn.LayerNorm(dim)
        self.ff = nn.Sequential(nn.Linear(dim, 4*dim), nn.SiLU(), nn.Dropout(dropout), nn.Linear(4*dim, dim))
        self.ffnorm = nn.LayerNorm(dim)
        self.drop = nn.Dropout(dropout)

    def forward(self, destination, source, edge_type, allowed=None):
        # Destination B,N,H; source B,M,H; edges B,N,M. All nodes processed together.
        b,n,d = destination.shape; m = source.shape[1]
        q=self.q(destination).view(b,n,self.heads,self.width)
        k=self.k(source).view(b,m,self.heads,self.width)
        v=self.v(source).view(b,m,self.heads,self.width)
        logits=torch.einsum('bnhd,bmhd->bhnm',q,k)
        if self.relation_count:
            ek=self.edge_key.weight.view(self.relation_count,self.heads,self.width)
            ev=self.edge_value.weight.view(self.relation_count,self.heads,self.width)
            # Unknown query edges carry no fabricated T/F relation embedding.
            type_q=torch.einsum('bnhd,thd->bnht',q,ek)
            type_q=F.pad(type_q,(0,1))
            logits=logits+type_q.gather(-1,edge_type[:,:,None,:].expand(b,n,self.heads,m)).permute(0,2,1,3)
        logits=logits/math.sqrt(self.width)
        if allowed is not None:
            if not bool(allowed.any(-1).all()): raise ValueError('Attention destination without support')
            logits=logits.masked_fill(~allowed[:,None], -torch.inf)
        weights=logits.softmax(-1)
        content=torch.einsum('bhnm,bmhd->bnhd',weights,v)
        if self.relation_count:
            type_mass=torch.stack([(weights*(edge_type[:,None]==t)).sum(-1) for t in range(self.relation_count)],-1)
            content=content+torch.einsum('bhnt,thd->bnhd',type_mass,ev)
        x=self.norm(destination+self.drop(self.out(content.reshape(b,n,d))))
        return self.ffnorm(x+self.drop(self.ff(x)))

class PromptTaskGraph(nn.Module):
    def __init__(self, dim=128, heads=4, layers=2, dropout=.1, temperature=.2):
        super().__init__(); self.temperature=temperature
        self.to_label=nn.ModuleList([TypedAttention(dim,heads,dropout) for _ in range(layers)])
        self.to_data=nn.ModuleList([TypedAttention(dim,heads,dropout,relation_count=2 if i<layers-1 else 0) for i in range(layers)])

    def forward(self, support, support_labels, query, label_count, support_mask=None):
        # Different rows may exclude a different query patient. Label indices are local.
        if support.ndim==2: support=support.unsqueeze(0)
        if support_labels.ndim==1: support_labels=support_labels.unsqueeze(0)
        if query.ndim==2: query=query.unsqueeze(0)
        b,s,d=support.shape; q=query.shape[1]
        if support_labels.shape != (b,s) or query.shape[0]!=b:
            raise ValueError('Misaligned task tensors')
        if bool(((support_labels<0)|(support_labels>=label_count)).any()):
            raise ValueError('Support label outside local task vocabulary')
        mask=torch.ones((b,s),dtype=torch.bool,device=support.device) if support_mask is None else support_mask
        membership=F.one_hot(support_labels,num_classes=label_count).to(support.dtype)*mask[...,None]
        counts=membership.sum(1)
        if bool((counts==0).any()):
            raise ValueError('Every provisional label needs actual eligible support; do not invent label nodes')
        labels=torch.einsum('bsk,bsd->bkd',membership,support)/counts[...,None]
        edges=F.one_hot(support_labels,num_classes=label_count).long() # T=1, F=0
        unknown=torch.full((b,q,label_count),2,dtype=torch.long,device=query.device)
        for index,(to_label,to_data) in enumerate(zip(self.to_label,self.to_data)):
            # Support and label branches exchange messages; query only receives.
            labels=to_label(labels,support,edges.transpose(1,2),mask[:,None,:].expand(-1,label_count,-1))
            if index==len(self.to_label)-1:
                # No unused terminal support branch or trainable query-label targets.
                query=to_data(query,labels,unknown)
            else:
                together=torch.cat((support,query),1)
                together=to_data(together,labels,torch.cat((edges,unknown),1))
                support,query=together[:,:s],together[:,s:]
        logits=torch.einsum('bqd,bkd->bqk',F.normalize(query,dim=-1),F.normalize(labels,dim=-1))/self.temperature
        return TaskOutput(query,labels,logits)

class CrossTaskAlignment(nn.Module):
    """Permutation-equivariant learned alignment; no global fixed label IDs."""
    def __init__(self,dim=128,heads=4,layers=2,dropout=.1,temperature=.2):
        super().__init__(); self.temperature=temperature
        self.layers=nn.ModuleList([nn.MultiheadAttention(dim,heads,dropout=dropout,batch_first=True) for _ in range(layers)])
        self.norms=nn.ModuleList([nn.LayerNorm(dim) for _ in range(layers)])
        self.ff=nn.ModuleList([nn.Sequential(nn.Linear(dim,4*dim),nn.SiLU(),nn.Linear(4*dim,dim)) for _ in range(layers)])
        self.ffnorm=nn.ModuleList([nn.LayerNorm(dim) for _ in range(layers)])

    def forward(self,a,b):
        for attention,norm,ff,fnorm in zip(self.layers,self.norms,self.ff,self.ffnorm):
            # Simultaneous updates prevent directional update-order shortcuts.
            da=attention(a,b,b,need_weights=False)[0]
            db=attention(b,a,a,need_weights=False)[0]
            a,b=norm(a+da),norm(b+db)
            a,b=fnorm(a+ff(a)),fnorm(b+ff(b))
        score=torch.einsum('bkd,bld->bkl',F.normalize(a,dim=-1),F.normalize(b,dim=-1))/self.temperature
        return a,b,score.softmax(-1),score.transpose(1,2).softmax(-1)

class PromptGraphModel(nn.Module):
    def __init__(self,cfg,base,*,with_local=True):
        super().__init__(); self.cfg=cfg
        m=base['model']; d=m['hidden_dim']
        if with_local:
            from hiercp.model import LocalTumorContextPyGEncoder
            self.local=LocalTumorContextPyGEncoder(hidden_dim=d,heads=m['heads'],layers=m['local_layers'],dropout=m['dropout'],
                dense_base_channels=m['dense_base_channels'],dense_feature_dim=m['dense_feature_dim'],dense_batch_size=m['dense_batch_size'],
                channels_last_3d=m['channels_last_3d'],checkpoint_local_blocks=m['checkpoint_local_blocks'],checkpoint_dense_encoder=m['checkpoint_dense_encoder'])
            self.data_projection=nn.Sequential(nn.Linear(d*6,d),nn.LayerNorm(d),nn.SiLU())
        self.task=PromptTaskGraph(d,m['heads'],cfg['task_layers'],m['dropout'],cfg['temperature'])
        self.alignment=CrossTaskAlignment(d,m['heads'],cfg['alignment_layers'],m['dropout'],cfg['temperature'])

    def encode_local(self,batch):
        fields=self.local(batch.graph,batch.source_patches,batch.source_index,batch.target_patches)
        names=('tumor','source_context','target_context','source_relation','target_relation','fused')
        return self.data_projection(torch.cat([fields[k] for k in names],-1))

    def forward_tasks(self,support_a,support_b,labels_a,labels_b,query_a,query_b,mask=None):
        k=self.cfg['label_count']
        a=self.task(support_a,labels_a,query_a,k,mask)
        b=self.task(support_b,labels_b,query_b,k,mask)
        la,lb,ab,ba=self.alignment(a.labels,b.labels)
        pa,pb=a.logits.softmax(-1),b.logits.softmax(-1)
        # Relations to provisional labels, in aligned latent space, determine CP similarity.
        za=F.normalize(pa@la,dim=-1); zb=F.normalize(pb@lb,dim=-1)
        return {'a':a,'b':b,'ab':ab,'ba':ba,'za':za,'zb':zb,
                'embedding':F.normalize(za+zb,dim=-1)}

def prompt_loss(output,support_labels_a,support_labels_b,query_labels_a,query_labels_b,weights,mask=None):
    a,b=output['a'],output['b']; k=a.labels.shape[1]
    if support_labels_a.ndim==1:
        support_labels_a=support_labels_a[None]; support_labels_b=support_labels_b[None]
    oa=F.one_hot(support_labels_a,k).float(); ob=F.one_hot(support_labels_b,k).float()
    if mask is not None: oa=oa*mask[...,None]
    counts=oa.transpose(1,2)@ob
    if bool((counts.sum(-1)==0).any()) or bool((counts.sum(-2)==0).any()):
        raise ValueError('Alignment requires shared support for every local label')
    tab=counts/counts.sum(-1,keepdim=True); tba=counts.transpose(1,2)/counts.sum(-2)[...,None]
    alignment=-(tab*output['ab'].clamp_min(1e-8).log()).sum(-1).mean()
    alignment=(alignment-(tba*output['ba'].clamp_min(1e-8).log()).sum(-1).mean())*.5
    local=(F.cross_entropy(a.logits.reshape(-1,k),query_labels_a.reshape(-1))+
           F.cross_entropy(b.logits.reshape(-1,k),query_labels_b.reshape(-1)))*.5
    aligned=(distribution_js(a.logits.softmax(-1)@output['ab'],b.logits.softmax(-1))+
             distribution_js(b.logits.softmax(-1)@output['ba'],a.logits.softmax(-1)))*.5
    view=(1-(output['za']*output['zb']).sum(-1)).mean()
    terms={'local_pseudo_label':local,'alignment_transport':alignment,'aligned_query':aligned,'view_consistency':view}
    total=sum(weights[key]*value for key,value in terms.items())
    if not bool(torch.isfinite(total)): raise FloatingPointError('Nonfinite prompt graph objective')
    return total,terms
