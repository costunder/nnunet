"""Full-cohort, source-resolved local graph caches; no v1 upper graphs."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import math
import numpy as np
import torch
from torch.utils.data import Dataset
from torch_geometric.data import Batch
from scipy import ndimage as ndi
from hiercp.common import (discover_cases,load_case,SourceTumor,bbox_of_mask,organ_depth_mm,stable_case_seed)
from hiercp.curriculum import CandidateSpec
from hiercp.local import prepare_local_source,build_local_graph
from hiercp.sample import build_local_view
from hiercp.schema import graph_config_from_dict
from hiercp.preparation_runtime import run_case_jobs
from .contracts import read_json,write_new,sha,safe_new_root,validate_split
from . import PIPELINE_VERSION

def sources(case,pad,maximum):
    components,count=ndi.label(case.label==2,structure=ndi.generate_binary_structure(3,1))
    sizes=np.bincount(components.ravel(),minlength=count+1)
    result=[]
    for component in range(1,count+1):
        diameter=2*(3*int(sizes[component])*float(np.prod(case.spacing))/(4*math.pi))**(1/3)
        if diameter>maximum: continue
        mask=components==component; box=bbox_of_mask(mask,pad=pad)
        center=tuple((s.start+s.stop-1)//2 for s in box)
        result.append((SourceTumor(component,mask,mask[box].copy(),case.image[box].copy(),box,center,
                        tuple(np.argwhere(mask).mean(0)),int(sizes[component])),diameter))
    return result

def candidate_spec(source,center,coverage=1.):
    # These legacy transport fields never enter an upper graph in v2.
    return CandidateSpec(tuple(map(int,center)),0,0,-1,-1,float(coverage),0.,0.,0.,0.)

def local_record(case,source,center,base,*,prepared=None,depth=None):
    gc=graph_config_from_dict(base['graph']); organ=np.isin(case.label,[1,2])
    depth=organ_depth_mm(organ,case.spacing) if depth is None else depth
    rng=np.random.default_rng(stable_case_seed(base['seed'],case.paths.case_id,str(source.component_id)))
    prepared=prepared or prepare_local_source(case,source,full_organ_mask=organ,organ_depth=depth,config=gc,rng=rng,ct_clip=tuple(base['ct_clip']))
    built=build_local_graph(case,source,candidate_spec(source,center),full_organ_mask=organ,organ_depth=depth,
                            config=gc,rng=rng,ct_clip=tuple(base['ct_clip']),prepared_source=prepared)
    return {'format':PIPELINE_VERSION,'case_id':case.paths.case_id,'component_id':source.component_id,
            'seed':base['seed'],
            'source_patch':torch.from_numpy(built.source_patch).half(),'target_patch':torch.from_numpy(built.target_patch).half(),
            'source_local':built.source_local,'target_local':built.target_local,'graph_config':gc.to_dict()}

def prepare(medical,split_path,output,cfg,base):
    split=read_json(split_path); validate_split(split)
    paths={c.case_id:c for c in discover_cases(Path(medical)/'Data')}
    if not set(split['outer_train']+split['outer_val'])==set(paths):
        raise ValueError('Split must match the complete discovered raw cohort')
    root=safe_new_root(output); records=[]; cases=[]
    write_new(root/'split.json',split); write_new(root/'config.json',cfg); write_new(root/'base_config.json',base)
    def one(case_id):
        case=load_case(paths[case_id]); case_rows=[]
        organ=np.isin(case.label,[1,2]); depth=organ_depth_mm(organ,case.spacing)
        for source,diameter in sources(case,base['cache']['source_pad'],cfg['donor_max_diameter_mm']):
            record=local_record(case,source,source.anchor_center,base,depth=depth)
            relative=f'graphs/{case_id}__{source.component_id:05d}.pt'; file=root/relative
            file.parent.mkdir(parents=True,exist_ok=True)
            with file.open('xb') as handle: torch.save(record,handle)
            case_rows.append({'id':f'{case_id}:{source.component_id}','case_id':case_id,'component_id':source.component_id,
                              'diameter_mm':diameter,'path':relative,'sha256':sha(file),
                              'nodes':sum(record['source_local']['counts'].values())+sum(record['target_local']['counts'].values()),
                              'edges':sum(record['source_local']['edge_counts'].values())+sum(record['target_local']['edge_counts'].values())})
        return case_rows,{'case_id':case_id,'sources':len(case_rows),'status':'ok' if case_rows else 'no_eligible_source',
                         'image':str(paths[case_id].image_path.resolve()),'image_sha256':sha(paths[case_id].image_path),
                         'label':str(paths[case_id].label_path.resolve()),'label_sha256':sha(paths[case_id].label_path)}
    def commit(result):
        r,c=result; records.extend(r); cases.append(c)
    run_case_jobs(tasks=split['outer_train'],function=one,commit=commit,workers=cfg['preparation_workers'],report_path=root/'resources.json')
    write_new(root/'index.json',{'format':PIPELINE_VERSION,'complete':True,'split':split,'records':sorted(records,key=lambda r:r['id']),
                               'cases':sorted(cases,key=lambda r:r['case_id']),'config':cfg,'base_config':base})
    return root/'index.json'

class LocalDataset(Dataset):
    def __init__(self,root,rows,*,view=0,epoch=0,verify=True):
        self.root=Path(root); self.rows=list(rows); self.view=view; self.epoch=epoch
        if verify:
            for row in rows:
                if sha(self.root/row['path'])!=row['sha256']: raise ValueError('Local cache SHA mismatch')
    def __len__(self): return len(self.rows)
    def __getitem__(self,index):
        row=self.rows[index]
        record=torch.load(self.root/row['path'],map_location='cpu',weights_only=False,mmap=True)
        return materialize(record,view=self.view,epoch=self.epoch),index

def materialize(record,view=0,epoch=0):
    if record['format']!=PIPELINE_VERSION: raise ValueError('Wrong local cache version')
    seed=stable_case_seed(record['seed'],record['case_id'],f"{record['component_id']}:{view}:{epoch}")
    graph=build_local_view(record['source_local'],record['target_local'],graph_config_from_dict(record['graph_config']),seed=seed)
    return graph,record['source_patch'],record['target_patch']

@dataclass
class LocalBatch:
    graph: Batch
    source_patches: torch.Tensor
    target_patches: torch.Tensor
    source_index: torch.Tensor
    indices: torch.Tensor
    def to(self,device):
        self.graph=self.graph.to(device)
        self.source_patches=self.source_patches.to(device,non_blocking=True).float()
        self.target_patches=self.target_patches.to(device,non_blocking=True).float()
        self.source_index=self.source_index.to(device,non_blocking=True)
        self.indices=self.indices.to(device)
        return self
    def pin_memory(self):
        self.graph=self.graph.pin_memory()
        for key in ('source_patches','target_patches','source_index','indices'):
            setattr(self,key,getattr(self,key).pin_memory())
        return self

def collate(items):
    payload,indices=zip(*items); graphs,sources_,targets=zip(*payload)
    return LocalBatch(Batch.from_data_list(list(graphs)),torch.stack(sources_),torch.stack(targets),
                      torch.arange(len(items)),torch.tensor(indices))
