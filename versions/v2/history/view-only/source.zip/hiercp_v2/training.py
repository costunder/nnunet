"""Full-cohort episodic training with measured physical batching and CSV logs."""
from __future__ import annotations
from pathlib import Path
import copy
import csv
import time
import math
import gc
import numpy as np
import torch
from torch.nn import functional as F
from torch.utils.data import DataLoader, Subset
from hiercp.preparation_runtime import snapshot
from hiercp.training_resources import _local_bound,host_input_budget
from . import PIPELINE_VERSION
from .contracts import read_json,write_new,sha,safe_new_root,source_identity,validate_split
from .data import LocalDataset,collate
from .model import PromptGraphModel,prompt_loss

def require_device(name):
    device=torch.device(name)
    if device.type!='cuda' or not torch.cuda.is_available():
        raise RuntimeError('Production v2 training/scoring requires the configured CUDA environment; no CPU fallback')
    if torch.cuda.device_count()>1:
        raise RuntimeError('v2 single-device trainer: select an allocated device explicitly with CUDA_VISIBLE_DEVICES; multi-GPU training is not implemented')
    return device

def loader(dataset,batch,workers,shuffle=False):
    return DataLoader(dataset,batch_size=batch,shuffle=shuffle,num_workers=workers,collate_fn=collate,
                      pin_memory=True,persistent_workers=workers>0,**({'prefetch_factor':1} if workers else {}))

def candidates(n):
    out=[]; b=1
    while b<=n: out.append(b); b*=2
    if out[-1]!=n: out.append(n)
    return out

def kmeans(values,k,iterations,seed):
    """Full learned-embedding table, fixed budget, no hidden row subsampling."""
    x=F.normalize(values.float(),dim=-1)
    if len(x)<k: raise ValueError(f'{len(x)} real graphs cannot support {k} provisional labels')
    gen=torch.Generator(device=x.device).manual_seed(seed)
    # Farthest-first initialization keeps all examples eligible, not a subset fit.
    ids=[int(torch.randint(len(x),(1,),generator=gen,device=x.device))]
    distance=1-x@x[ids[0]]
    for _ in range(1,k):
        ids.append(int(distance.argmax())); distance=torch.minimum(distance,1-x@x[ids[-1]])
    centers=x[ids].clone()
    for _ in range(iterations):
        assignment=(x@centers.T).argmax(-1)
        count=torch.bincount(assignment,minlength=k)
        if bool((count==0).any()): raise ValueError('Empty provisional cluster; cannot manufacture label support')
        sums=torch.zeros_like(centers).index_add_(0,assignment,x)
        centers=F.normalize(sums/count[:,None],dim=-1)
    assignment=(x@centers.T).argmax(-1)
    if bool((torch.bincount(assignment,minlength=k)==0).any()): raise ValueError('Final provisional labels have empty support')
    return centers,assignment

def full_inventory(root,rows):
    result=[]
    for row in rows:
        r=torch.load(Path(root)/row['path'],weights_only=False,mmap=True,map_location='cpu')
        a,b=_local_bound(r['source_local']),_local_bound(r['target_local'])
        result.append({'id':row['id'],'nodes':a[0]+b[0],'edges':a[1]+b[1],
                       'bytes':a[2]+b[2]+r['source_patch'].numel()*4+r['target_patch'].numel()*4})
    return result

def calibrate(model,dataset,device,cfg,objective=None,*,inference_only=False):
    """Largest/mixed full graphs, full loss/backward when objective is available.

    Failed resource candidates never drop samples from the final epoch. Trials
    restore RNG and do not change parameters or optimizer moments.
    """
    inventory=full_inventory(dataset.root,dataset.rows)
    order=sorted(range(len(dataset)),key=lambda i:inventory[i]['bytes'],reverse=True)
    mixed=np.random.default_rng(cfg['seed']).permutation(len(dataset)).tolist()
    trials=[]; best=None
    state={k:v.detach().cpu().clone() for k,v in model.state_dict().items()}
    cpu_rng=torch.get_rng_state(); gpu_rng=torch.cuda.get_rng_state_all()
    parameter_bytes=sum(p.numel()*p.element_size() for p in model.parameters())
    try:
        for b in candidates(len(dataset)):
            budget=host_input_budget(sum(sorted((r['bytes'] for r in inventory),reverse=True)[:b])*2,
                                     workers=0,prefetch_factor=1,pin_memory=True)
            if not budget['accepted']:
                trials.append({'batch':b,'status':'host_memory_rejected','host':budget}); continue
            started=time.perf_counter(); peak=0; count=0; accepted=True
            for chosen in (order,mixed):
                for _ in range(cfg['batch_calibration_repeats']):
                    model.zero_grad(set_to_none=True)
                    batch=encoded=loss=None
                    try:
                        torch.cuda.reset_peak_memory_stats(device)
                        batch=collate([dataset[i] for i in chosen[:b]]).to(device)
                        with torch.set_grad_enabled(objective is not None and not inference_only), torch.autocast('cuda',dtype=torch.bfloat16):
                            encoded=model.encode_local(batch)
                            if objective is not None:
                                loss=objective(encoded,batch.indices)
                            else:
                                # Inference sizing bootstrap only, never a training target.
                                loss=None
                        if loss is not None and not inference_only: loss.backward()
                        torch.cuda.synchronize(device)
                        # AdamW states are reserved even though calibration does not update weights.
                        peak=max(peak,torch.cuda.max_memory_allocated(device)+(2*parameter_bytes if objective and not inference_only else 0))
                        free,total=torch.cuda.mem_get_info(device)
                        capacity=min(total*cfg['max_vram_fraction'],free+torch.cuda.memory_allocated(device))
                        if peak>capacity: accepted=False
                        count+=b
                    except torch.cuda.OutOfMemoryError:
                        accepted=False
                    finally:
                        batch=encoded=loss=None
                        if not accepted:
                            model.zero_grad(set_to_none=True); gc.collect(); torch.cuda.empty_cache()
                    if not accepted: break
                if not accepted: break
            elapsed=time.perf_counter()-started
            trial={'batch':b,'status':'accepted' if accepted else 'gpu_memory_rejected','peak_reserved_estimate':peak,
                   'graphs_per_second':count/max(elapsed,1e-9),'host':budget,'objective':('full_prompt_inference' if inference_only else 'actual_pseudo_label_and_alignment') if objective else 'encoder_inference_bootstrap'}
            trials.append(trial)
            if accepted and (best is None or trial['graphs_per_second']>best['graphs_per_second']): best=trial
            model.zero_grad(set_to_none=True); torch.cuda.empty_cache()
        if best is None: raise RuntimeError('No full-scale batch fits; graphs/model were not reduced')
    finally:
        model.load_state_dict(state); torch.set_rng_state(cpu_rng); torch.cuda.set_rng_state_all(gpu_rng)
        model.zero_grad(set_to_none=True)
    return best['batch'],{'trials':trials,'selected_batch':best['batch'],'inventory':inventory,'resources':snapshot()}

def calibrate_workers(dataset,batch,cfg):
    inventory=full_inventory(dataset.root,dataset.rows); reports=[]
    for workers in cfg['worker_candidates']:
        budget=host_input_budget(sum(sorted((r['bytes'] for r in inventory),reverse=True)[:batch])*2,
                                 workers=workers,prefetch_factor=1,pin_memory=True)
        if not budget['accepted']:
            reports.append({'workers':workers,'status':'host_memory_rejected','host':budget}); continue
        start=time.perf_counter(); count=0
        # Entire loader pass includes every graph. Worker timing includes startup.
        for value in loader(dataset,batch,workers): count+=len(value.indices)
        reports.append({'workers':workers,'status':'accepted','graphs_per_second':count/(time.perf_counter()-start),'host':budget})
    good=[r for r in reports if r['status']=='accepted']
    if not good: raise RuntimeError('No loader concurrency fits measured host memory')
    return max(good,key=lambda r:r['graphs_per_second'])['workers'],reports

@torch.no_grad()
def embeddings(model,dataset,batch,workers,device):
    model.eval(); values=[]
    for item in loader(dataset,batch,workers):
        with torch.autocast('cuda',dtype=torch.bfloat16): values.append(model.encode_local(item.to(device)).float().cpu())
    return torch.cat(values).to(device)

def tasks(model,memory,query_a,query_b,query_cases):
    support_a,support_b,labels_a,labels_b=memory['a'],memory['b'],memory['labels_a'],memory['labels_b']
    b=len(query_a)
    mask=torch.tensor([[c!=q for c in memory['case_ids']] for q in query_cases],device=query_a.device)
    return model.forward_tasks(support_a[None].expand(b,-1,-1),support_b[None].expand(b,-1,-1),
        labels_a[None].expand(b,-1),labels_b[None].expand(b,-1),query_a[:,None],query_b[:,None],mask),mask

def step_loss(model,memory,qa,qb,case_ids,weights):
    output,mask=tasks(model,memory,qa,qb,case_ids)
    ya=(F.normalize(qa.detach().float(),dim=-1)@memory['centers_a'].T).argmax(-1)
    yb=(F.normalize(qb.detach().float(),dim=-1)@memory['centers_b'].T).argmax(-1)
    b=len(qa)
    return prompt_loss(output,memory['labels_a'][None].expand(b,-1),memory['labels_b'][None].expand(b,-1),ya,yb,weights,mask)

def train(cache_path,output,cfg,base):
    device=require_device(cfg['training_device']); root=Path(cache_path).resolve().parent
    index=read_json(cache_path)
    if index['format']!=PIPELINE_VERSION or not index['complete'] or index['config']!=cfg or index['base_config']!=base:
        raise ValueError('Cache/config/version mismatch')
    validate_split(index['split'])
    tr=[r for r in index['records'] if r['case_id'] in index['split']['inner_train']]
    va=[r for r in index['records'] if r['case_id'] in index['split']['inner_val']]
    if not tr or not va: raise ValueError('Real inner-training and validation graphs are required')
    out=safe_new_root(output)
    torch.manual_seed(cfg['seed']); np.random.seed(cfg['seed'])
    model=PromptGraphModel(cfg,base).to(device)
    dataset=LocalDataset(root,tr)
    model.eval()
    bootstrap,bootstrap_report=calibrate(model,dataset,device,cfg)
    workers,worker_report=calibrate_workers(dataset,bootstrap,cfg)
    def make_memory(epoch):
        a=embeddings(model,LocalDataset(root,tr,view=0,epoch=epoch,verify=False),bootstrap,workers,device)
        b=embeddings(model,LocalDataset(root,tr,view=1,epoch=epoch,verify=False),bootstrap,workers,device)
        ca,ya=kmeans(a,cfg['label_count'],cfg['cluster_iterations'],cfg['seed']+2*epoch)
        cb,yb=kmeans(b,cfg['label_count'],cfg['cluster_iterations'],cfg['seed']+2*epoch+1)
        memory={'a':a,'b':b,'labels_a':ya,'labels_b':yb,'centers_a':ca,'centers_b':cb,'case_ids':[r['case_id'] for r in tr]}
        # Full leave-patient-out coverage audit before any update.
        for case in sorted(set(memory['case_ids'])):
            mask=torch.tensor([c!=case for c in memory['case_ids']],device=device)
            for labels in (ya,yb):
                if bool((torch.bincount(labels[mask],minlength=cfg['label_count'])==0).any()):
                    raise ValueError(f'No independent patient support for a provisional label when querying {case}; redesign label budget explicitly')
        return memory
    memory=make_memory(0)
    second_dataset=LocalDataset(root,tr,view=1,epoch=0,verify=False)
    def objective(encoded,indices):
        ids=indices.cpu().tolist(); cases=[tr[i]['case_id'] for i in ids]
        second=collate([second_dataset[i] for i in ids]).to(device)
        other=model.encode_local(second)
        return step_loss(model,memory,encoded,other,cases,cfg['loss_weights'])[0]
    model.train(); batch,report=calibrate(model,dataset,device,cfg,objective)
    workers,worker_report=calibrate_workers(dataset,batch,cfg)
    optimizer=torch.optim.AdamW(model.parameters(),lr=base['training']['lr'],weight_decay=base['training']['weight_decay'])
    write_new(out/'execution.json',{'format':PIPELINE_VERSION,'config':cfg,'base_config':base,'bootstrap':bootstrap_report,
              'calibration':report,'workers':worker_report,'selected_workers':workers,'physical_batch':batch,
              'effective_batch':batch,'gradient_accumulation':1,'parameters':sum(p.numel() for p in model.parameters()),
              'trainable_parameters':sum(p.numel() for p in model.parameters() if p.requires_grad),
              'training_graphs':len(tr),'validation_graphs':len(va),'source_identity':source_identity(),
              'gpu':torch.cuda.get_device_name(device),'device_count':torch.cuda.device_count(),'debug':False,
              'sampling':'unchanged full L0 canonical graph and configured induced views; full source cohort',
              'validation_interpretation':'provisional-label consistency, not medical placement accuracy'})
    with (out/'metrics.csv').open('x',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fieldnames=['epoch','train_loss','validation_loss','graphs','steps','peak_vram','seconds','graphs_per_second'])
        writer.writeheader(); total_steps=0
        for epoch in range(cfg['gnn_epochs']):
            if epoch: memory=make_memory(epoch)
            model.train(); total=0.; seen=0; steps=0; start=time.perf_counter()
            torch.cuda.reset_peak_memory_stats(device)
            da=LocalDataset(root,tr,view=0,epoch=epoch,verify=False); db=LocalDataset(root,tr,view=1,epoch=epoch,verify=False)
            for a,b in zip(loader(da,batch,workers),loader(db,batch,workers)):
                ids=a.indices.tolist(); cases=[tr[i]['case_id'] for i in ids]
                optimizer.zero_grad(set_to_none=True)
                with torch.autocast('cuda',dtype=torch.bfloat16):
                    qa=model.encode_local(a.to(device)); qb=model.encode_local(b.to(device))
                    loss,_=step_loss(model,memory,qa,qb,cases,cfg['loss_weights'])
                loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),base['training']['grad_clip'],error_if_nonfinite=True)
                optimizer.step(); total+=float(loss.detach())*len(ids); seen+=len(ids); steps+=1
            if seen!=len(tr): raise RuntimeError('Training epoch did not cover every graph')
            model.eval(); val=0.; nv=0
            with torch.no_grad():
                dva=LocalDataset(root,va,view=0,epoch=0,verify=False); dvb=LocalDataset(root,va,view=1,epoch=0,verify=False)
                for a,b in zip(loader(dva,batch,workers),loader(dvb,batch,workers)):
                    ids=a.indices.tolist(); cases=[va[i]['case_id'] for i in ids]
                    with torch.autocast('cuda',dtype=torch.bfloat16):
                        loss,_=step_loss(model,memory,model.encode_local(a.to(device)),model.encode_local(b.to(device)),cases,cfg['loss_weights'])
                    val+=float(loss)*len(ids); nv+=len(ids)
            if nv!=len(va): raise RuntimeError('Validation omitted graphs')
            total_steps+=steps; elapsed=time.perf_counter()-start
            row=dict(epoch=epoch+1,train_loss=total/seen,validation_loss=val/nv,graphs=seen,steps=steps,
                     peak_vram=torch.cuda.max_memory_allocated(device),seconds=elapsed,graphs_per_second=seen/elapsed)
            writer.writerow(row); f.flush(); print(row,flush=True)
            payload={'format':PIPELINE_VERSION,'complete':False,'epoch':epoch+1,'total_steps':total_steps,
                     'config':cfg,'base_config':base,'state_dict':model.state_dict(),'optimizer':optimizer.state_dict(),
                     'memory':{k:v.cpu() if torch.is_tensor(v) else v for k,v in memory.items()},
                     'split':index['split'],'raw_records':index['cases'],'cache_sha256':sha(cache_path),'source_identity':source_identity(),
                     'torch_rng':torch.get_rng_state(),'cuda_rng':torch.cuda.get_rng_state_all(),'physical_batch':batch,'workers':workers}
            with (out/f'epoch_{epoch+1:03d}.pt').open('xb') as handle: torch.save(payload,handle)
    # Recompute support from final weights; never export stale pre-update support as final memory.
    memory=make_memory(cfg['gnn_epochs'])
    payload['memory']={k:v.cpu() if torch.is_tensor(v) else v for k,v in memory.items()}
    payload['complete']=True
    with (out/'model.pt').open('xb') as handle: torch.save(payload,handle)
    write_new(out/'completion.json',{'format':PIPELINE_VERSION,'epochs':cfg['gnn_epochs'],'checkpoint_sha256':sha(out/'model.pt'),
               'metrics_sha256':sha(out/'metrics.csv'),'actual_medical_training':True})
    return out/'model.pt'
