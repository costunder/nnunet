"""Frozen learned L0/L1/L2 scoring of every raw placement, without query labels."""
from pathlib import Path
import numpy as np
import torch
from .contracts import validate_checkpoint
from .model import PromptGraphModel
from .training import require_device,tasks,loader,calibrate,calibrate_workers
from .data import LocalDataset,collate

class Scorer:
    def __init__(self,checkpoint,device='cuda'):
        self.device=require_device(device)
        self.payload=validate_checkpoint(torch.load(checkpoint,map_location='cpu',weights_only=False))
        self.cfg=self.payload['config']; self.base=self.payload['base_config']
        self.model=PromptGraphModel(self.cfg,self.base).to(self.device)
        self.model.load_state_dict(self.payload['state_dict'],strict=True); self.model.eval()
        self.memory={k:v.to(self.device) if torch.is_tensor(v) else v for k,v in self.payload['memory'].items()}

    @torch.no_grad()
    def encode(self,root,rows,case_id):
        dataset=LocalDataset(root,rows)
        # Calibrate complete model scoring, not encoder-only memory.
        second=LocalDataset(root,rows,view=1,verify=False)
        def actual_score(encoded,indices):
            qb=self.model.encode_local(collate([second[i] for i in indices.cpu().tolist()]).to(self.device))
            result,_=tasks(self.model,self.memory,encoded,qb,[case_id]*len(encoded))
            return result['embedding']
        batch,report=calibrate(self.model,dataset,self.device,self.cfg,actual_score,inference_only=True)
        workers,worker_report=calibrate_workers(dataset,batch,self.cfg)
        report.update(selected_workers=workers,worker_calibration=worker_report)
        values=[]
        for a,b in zip(loader(dataset,batch,workers),loader(second,batch,workers)):
            with torch.autocast('cuda',dtype=torch.bfloat16):
                qa=self.model.encode_local(a.to(self.device)); qb=self.model.encode_local(b.to(self.device))
                result,_=tasks(self.model,self.memory,qa,qb,[case_id]*len(qa))
            values.append(result['embedding'].squeeze(1).float().cpu())
        return torch.cat(values),report

    def score(self,root,source_row,candidate_rows,case_id):
        if len(candidate_rows)!=self.cfg['candidate_count']:
            raise ValueError('The complete 128-candidate source pool is required')
        vectors,report=self.encode(root,[source_row,*candidate_rows],case_id)
        scores=(vectors[1:]*vectors[0]).sum(-1).numpy()
        if scores.shape!=(self.cfg['candidate_count'],) or not np.isfinite(scores).all():
            raise ValueError('Nonfinite or incomplete aligned scores')
        return scores,report
