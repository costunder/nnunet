"""Synthetic DEBUG tests only; no patient data or medical performance claims."""
import copy
import json
import time
import unittest
import torch
from hiercp_v2.contracts import load_config,validate_split,verify_v1
from hiercp_v2.model import PromptGraphModel,prompt_loss
from hiercp_v2.data import LocalBatch
from test_hierarchy_model_debug import debug_batch


class PromptGraphV2DebugTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.threads=torch.get_num_threads(); torch.set_num_threads(4)
        cls.cfg,cls.base=load_config()

    @classmethod
    def tearDownClass(cls): torch.set_num_threads(cls.threads)

    def setUp(self):
        torch.manual_seed(611)
        self.model=PromptGraphModel(self.cfg,self.base,with_local=False).eval()
        self.a=torch.randn(2,48,128); self.b=torch.randn(2,48,128)
        self.la=torch.arange(16).repeat(3)[None].expand(2,-1)
        self.lb=self.la.roll(5,1)
        self.qa=torch.randn(2,3,128); self.qb=torch.randn(2,3,128)

    def forward(self,**kw):
        args=dict(support_a=self.a,support_b=self.b,labels_a=self.la,labels_b=self.lb,query_a=self.qa,query_b=self.qb)
        args.update(kw)
        return self.model.forward_tasks(**args)

    def test_label_permutation_equivariance_through_L2(self):
        with torch.no_grad():
            x=self.forward(); pa=torch.randperm(16); pb=torch.randperm(16)
            y=self.forward(labels_a=pa[self.la],labels_b=pb[self.lb])
        torch.testing.assert_close(x['embedding'],y['embedding'],rtol=2e-5,atol=2e-6)
        torch.testing.assert_close(x['ab'],y['ab'][:,pa][:,:,pb],rtol=2e-5,atol=2e-6)

    def test_query_cannot_modify_labels_or_other_queries(self):
        modified=self.qa.clone(); modified[:,0]+=20*torch.randn(2,128)
        with torch.no_grad(): x=self.forward(); y=self.forward(query_a=modified)
        torch.testing.assert_close(x['a'].labels,y['a'].labels)
        torch.testing.assert_close(x['embedding'][:,1:],y['embedding'][:,1:])
        self.assertFalse(torch.allclose(x['embedding'][:,0],y['embedding'][:,0]))

    def test_excluded_patient_support_is_invisible(self):
        mask=torch.ones(2,48,dtype=torch.bool); mask[:,:16]=False
        changed=self.a.clone(); changed[:,:16]=100*torch.randn(2,16,128)
        with torch.no_grad(): x=self.forward(mask=mask); y=self.forward(mask=mask,support_a=changed)
        torch.testing.assert_close(x['embedding'],y['embedding'])

    def test_support_order_and_batch_independence(self):
        perm=torch.randperm(48)
        with torch.no_grad():
            x=self.forward()
            y=self.forward(support_a=self.a[:,perm],support_b=self.b[:,perm],labels_a=self.la[:,perm],labels_b=self.lb[:,perm])
            one=self.model.forward_tasks(self.a[:1],self.b[:1],self.la[:1],self.lb[:1],self.qa[:1],self.qb[:1])
        torch.testing.assert_close(x['embedding'],y['embedding'],rtol=2e-5,atol=2e-6)
        torch.testing.assert_close(x['embedding'][:1],one['embedding'],rtol=2e-5,atol=2e-6)

    def test_relations_and_alignment_change_candidate_scores(self):
        changed=self.la.clone(); changed[:,[0,1]]=changed[:,[1,0]]
        with torch.no_grad(): x=self.forward(); y=self.forward(labels_a=changed)
        self.assertFalse(torch.allclose(x['embedding'],y['embedding']))
        def alter(_module,_input,output):
            a,b,ab,ba=output
            delta=torch.linspace(-3,3,128)[None,None,:]
            return a+delta,b-delta,ab,ba
        hook=self.model.alignment.register_forward_hook(alter)
        try:
            with torch.no_grad(): z=self.forward()
        finally: hook.remove()
        sx=(x['embedding'][:,1:]*x['embedding'][:,:1]).sum(-1)
        sz=(z['embedding'][:,1:]*z['embedding'][:,:1]).sum(-1)
        self.assertFalse(torch.allclose(sx,sz))

    def test_loss_permutation_invariant_and_missing_support_rejected(self):
        targets=torch.tensor([[0,1,2],[3,4,5]])
        x=self.forward(); pa=torch.randperm(16); pb=torch.randperm(16)
        y=self.forward(labels_a=pa[self.la],labels_b=pb[self.lb])
        a,_=prompt_loss(x,self.la,self.lb,targets,targets,self.cfg['loss_weights'])
        b,_=prompt_loss(y,pa[self.la],pb[self.lb],pa[targets],pb[targets],self.cfg['loss_weights'])
        torch.testing.assert_close(a,b)
        with self.assertRaisesRegex(ValueError,'actual eligible support'):
            self.forward(labels_a=torch.zeros_like(self.la))

    def test_full_width_L0_L1_L2_loss_backward_optimizer_debug(self):
        start=time.perf_counter()
        model=PromptGraphModel(self.cfg,self.base).train()
        fixture=debug_batch(counts=(2,2),patch_size=48)
        batch=LocalBatch(fixture.local_batch,fixture.source_patches,fixture.target_patches,
                         torch.tensor([0,0,1,1]),torch.arange(4))
        second=LocalBatch(fixture.local_batch_view2,fixture.source_patches,fixture.target_patches,
                         torch.tensor([0,0,1,1]),torch.arange(4))
        optimizer=torch.optim.AdamW(model.parameters(),lr=1e-4)
        before={n:p.detach().clone() for n,p in model.named_parameters()}
        qa=model.encode_local(batch); qb=model.encode_local(second)
        out=model.forward_tasks(self.a[:1],self.b[:1],self.la[:1],self.lb[:1],qa[None],qb[None])
        loss,_=prompt_loss(out,self.la[:1],self.lb[:1],torch.arange(4)[None],torch.arange(4)[None],self.cfg['loss_weights'])
        loss.backward()
        missing=[n for n,p in model.named_parameters() if p.grad is None]
        self.assertEqual(missing,[])
        self.assertTrue(all(torch.isfinite(p.grad).all() for p in model.parameters()))
        optimizer.step()
        prefixes=['local.','data_projection.']+[f'task.to_label.{i}.' for i in range(2)]+[f'task.to_data.{i}.' for i in range(2)]+[f'alignment.layers.{i}.' for i in range(2)]
        for prefix in prefixes:
            self.assertTrue(any(not torch.equal(before[n],p.detach()) for n,p in model.named_parameters() if n.startswith(prefix)),prefix)
        print(json.dumps({'scope':'DEBUG synthetic full-width model, sparse fixture graphs','parameters':sum(p.numel() for p in model.parameters()),
            'patch':[48,48,48],'physical_graph_batch':4,'all_parameter_gradients':True,'optimizer_steps':1,
            'elapsed_seconds':time.perf_counter()-start,'real_medical_data':False,'full_training':False}),flush=True)

    def test_v1_unchanged_and_patient_split_contract(self):
        self.assertEqual(verify_v1(),'74dcc2cf03d2d40d1f582223321d96004333f661')
        good=dict(inner_train=['a'],inner_val=['b'],outer_train=['a','b'],outer_val=['c'])
        validate_split(good)
        with self.assertRaises(ValueError): validate_split(dict(good,outer_val=['a']))


if __name__=='__main__': unittest.main()
