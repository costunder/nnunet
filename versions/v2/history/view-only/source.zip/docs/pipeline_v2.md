# Prompt Graph 기반 nnU-Net 파이프라인 v2

2026-09-19. 기존 파이프라인은 v1으로 보존했다. 이 문서는 새 v2 구현과 그 검증 범위를 설명한다. **실제 환자 데이터로 v2 학습·평가를 수행한 결과는 아직 없다.**

## 사용자의 설계 의도와 구현 선택

사용자가 확정한 구조는 다음과 같다.

1. L0: KD-tree 이웃 질의로 만든 국소 그래프를 인코딩한다.
2. L1: L0 인코딩을 data node로 사용하고, data node와 label node의 관계를 추천 시스템과 비슷한 방식으로 학습한다. label은 국소적·잠정적인 기준이며 절대 정답이 아니다.
3. L2: 서로 다른 L1에서 생긴 잠정적인 기준을 정렬한다.

현재 v2는 이 의미를 **두 task view의 label 공간을 공통 support로 정렬하는 self-supervised 모델**로 구현한다. 원본 GACP 슬라이드의 모든 미지정 사항까지 이미 정해져 있었다고 주장하지 않는다. task 생성 방식, 아래 loss 구성 및 16개 label 예산은 이번 v2의 명시적인 구현 선택이다. 실제 데이터 기반의 적절성은 후속 실험으로 확인해야 한다.

## 데이터에서 후보 선택까지

```mermaid
flowchart TD
    A[전체 환자 데이터와 고정 split] --> B[outer train의 모든 적격 source tumor]
    B --> C[L0: 물리 좌표 KD-tree 국소 그래프 + CT patch]
    C --> D[L0 GNN encoding → data embedding]
    D --> E1[L1 task A: support data ↔ provisional labels]
    D --> E2[L1 task B: support data ↔ provisional labels]
    E1 --> F[L2: 공통 support를 기준으로 label 공간 정렬]
    E2 --> F
    F --> G[source와 128개 후보의 정렬된 관계 embedding 비교]
    G --> H[argmax 후보의 raw-space copy-paste bank]
    H --> I[nnU-Net: CP 확률 0.5, 250 epoch]
    I --> J[전체 outer validation 예측]
    J --> K[환자별·병변별·크기별 CSV 평가]
```

### L0: 국소 그래프와 data node

`hiercp/local.py`, `hiercp/spatial.py`, `hiercp/sample.py`의 기존 물리 좌표·KD-tree·반경 연결·전체 source 형상 계약을 재사용한다. canonical graph를 저장하고, 기존 설정의 context seed 384 및 2-hop induced view를 사용한다. 반경, 간격, ROI 및 그래프 안전 한계는 기존 `config/train.json` 그대로다. 기존 한계를 초과하면 오류가 발생하며 조용히 node/edge를 잘라내지 않는다.

소형 donor는 기존 donor 정의인 **6-connectivity component의 등가 구 직경 ≤20 mm**로 선별한다. 적격 component를 모두 사용한다. 기존 cache의 `samples_per_case=2`, 후보 8개 ranking curriculum은 새 v2의 source 수 제한으로 사용하지 않는다. 적격 source가 없는 환자도 cohort 기록에는 남는다.

source/target CT patch는 각각 5×48×48×48이고 CNN channel은 12/24/32다. L0는 hidden 128, 4 heads, 3 message-passing layers를 유지한다. 인코더의 tumor/source context/target context/source relation/target relation/fused 출력 6개를 연결하여 128차원 data embedding으로 투영한다.

**KD-tree는 그래프를 만드는 방법이고 GNN은 그 그래프의 인코더다.** 이번 구현은 기존 L0의 gated GATv2 연산자를 재사용한다. L1/L2를 기존 GATv2 patient/prototype 그래프로 설명하지 않는다. L0 연산자 자체의 새 구조를 사용자가 지정한 것으로 간주하지도 않는다.

### L1: 잠정 label과 관계 학습

각 epoch 시작에 현재 L0로 inner-train의 모든 적격 graph를 두 stochastic view로 인코딩한다. 각 view에서 독립적으로 spherical k-means를 수행해 두 task의 잠정 label을 만든다. 16은 기존 범주 예산을 가져온 **실험용 capacity 설정**이며, 해부학적 절대 범주 16개를 의미하지 않는다. 각 fit은 전체 embedding을 사용하고 30회 갱신한다. 빈 cluster나 환자 제외 후 support가 없는 label을 가짜 node로 채우지 않고 오류로 보고한다.

label node의 초기값은 현재 task에서 해당 label에 속하는 실제 support embedding의 평균이다. 이는 미리 저장한 고정 population prototype이 아니다. 평균으로 초기화한 뒤 관계 message passing으로 갱신한다. label ID별 학습 embedding을 두지 않으므로 label 번호 순서에 의미를 부여하지 않는다.

support data–label 사이에는 현재 잠정 할당에 따른 T/F edge가 있으며 두 방향으로 메시지를 교환한다. query는 label→query 메시지만 받는다. query가 support나 label state를 갱신하지 않는다. query 환자 전체는 해당 task의 support에서 제외한다. 두 layer를 사용하고 마지막에는 사용되지 않을 support 갱신 branch를 만들지 않는다.

L1 loss는 잠정 label에 대한 query 분류다. GT tumor class를 학습하는 segmentation loss나 ‘이 위치에 붙이면 정답’이라는 clinical label이 아니다. inner-val/outer-val을 clustering fit에 사용하지 않는다.

### L2: L1의 기준을 정렬

공통 support i가 task A에서 a, task B에서 b에 속하면 correspondence count N[a,b]를 늘린다. N의 행 정규화로 A→B soft target을, 전치 행 정규화로 B→A soft target을 만든다. 두 task의 label들이 일대일 대응한다고 강제하지 않는다.

2층 양방향 cross-attention이 L1 label 표현을 교환한다. 정렬된 label 표현 사이의 cosine similarity를 temperature 0.2의 row-softmax로 바꾸어 A→B/B→A 대응을 학습한다. 그 다음 query의 L1 label posterior로 정렬된 label 표현을 가중합한다. 두 view의 결과를 정규화하여 최종 embedding을 만든다.

loss 구성은 다음과 같다.

| 항 | 계수 | 역할 |
|---|---:|---|
| local pseudo-label CE | 1.0 | 각 task의 잠정 관계 학습 |
| alignment transport soft CE | 1.0 | 같은 support가 제공하는 task 간 soft 대응 학습 |
| aligned query JSD | 1.0 | 대응을 거친 두 query posterior의 일관성 |
| aligned embedding cosine consistency | 0.1 | 두 view의 정렬 표현 일관성 |

**L2가 잠정 label을 의학적인 절대 정답으로 바꾸는 것은 아니다.** L1의 서로 다른 기준을 비교 가능한 공간으로 맞추는 역할이다. 이 목적함수가 실제 placement 품질이나 소형암 성능을 높이는지는 실험 전에는 알 수 없다.

### 후보와 nnU-Net

각 outer-train source에 대해 기존 hard geometry 조건을 만족하는 후보 128개를 모두 생성한다. source 원래 위치의 embedding과 각 후보 embedding의 cosine similarity로 점수를 계산하고 argmax를 고른다. 후보별 query가 support에 역으로 정보를 보내지 않으므로 physical batch의 다른 후보와 섞여 예측이 달라지는 구조가 아니다.

현재 v2는 **frozen GNN bank + aligned-relation argmax** 실험이다. 기존 v1의 별도 난이도/feedback curriculum을 적용한 실험과는 목적함수·선택 정책이 함께 달라지므로, 둘의 성능 차이를 곧바로 L2 하나의 효과라고 해석하면 안 된다.

raw-target paste 및 nnU-Net preprocessing transport는 기존 검증 모듈을 재사용한다. 새 native runtime에 복사하여 새 trainer를 등록하며 기존 설치의 trainer를 덮어쓰지 않는다. ResEncM/3d_fullres, CP=0.5, 250 epoch, augmentation 및 validation 시 CP 미적용을 유지한다. fingerprint/planning은 outer-train만 사용한다. 선택된 outer split은 격리된 native 디렉터리에서 fold 0으로 실행하며 원래 outer fold 번호는 split 기록에 보존한다.

## 실행

저장소 루트에서 실행한다. `MEDICAL`은 `Data/image/<case>_0000.nii.gz`, `Data/labels/<case>.nii.gz`가 있는 실제 데이터 루트이고, `WORK`는 **새 출력 경로**다. native 준비 단계에서 새 `imagesTr`/`labelsTr`로 복사한다. 각 단계는 기존 출력 경로를 거부한다. 실패한 일부 출력도 보존하며 자동 resume/덮어쓰기는 구현하지 않았다. 아래 경로명은 사용 환경에 맞게 정할 입력값이다.

```text
python run_v2.py check
python run_v2.py import-split --outer-splits OUTER_SPLITS.json --inner-split INNER_SPLIT.json --outer-fold 0 --output WORK/split.json
python run_v2.py prepare --medical-root MEDICAL --split WORK/split.json --output WORK/gnn_cache
python run_v2.py train --cache WORK/gnn_cache/index.json --output WORK/gnn_train
python run_v2.py nnunet-plan --medical-root MEDICAL --split WORK/split.json --output WORK/native --dataset-id DATASET_ID
python run_v2.py bank --native WORK/native/native.json --checkpoint WORK/gnn_train/model.pt --output WORK/bank
python run_v2.py nnunet-train --native WORK/native/native.json --bank WORK/bank/index.json
python run_v2.py predict --native WORK/native/native.json --output WORK/inference
python run_v2.py evaluate --native WORK/native/native.json --predictions WORK/inference/predictions --output WORK/evaluation
```

inner split JSON의 `train`/`val`은 outer-train을 정확하게 나누어야 한다. outer-train과 outer-val의 합은 발견된 전체 데이터와 일치해야 한다. 새 v2 GNN 학습에는 CUDA PyTorch, PyG, SciPy, nibabel이 필요하고 segmentation 단계에는 실제 nnU-Net 실행 환경이 필요하다.

## 자원 사용 및 기록

GNN의 physical batch는 1부터 전체 graph 수까지 powers-of-two와 전체 수를 후보로 실제 full-size graph/loss/backward 처리량을 측정하여 선택한다. batch=1은 측정 후보일 뿐 기본 최종값이 아니다. largest/mixed graph 묶음을 모두 시험한다. 모델 크기를 줄이거나 학습 데이터 일부를 버리지 않는다. PyG disjoint-union batching과 task tensor batching을 사용한다. gradient accumulation=1이므로 현재 effective batch는 physical batch와 같다.

DataLoader worker 0/2/4/8을 전체 graph pass로 비교하고 RAM admission을 확인한다. 0은 비교용 후보로 포함한다. 준비 단계의 case 및 후보 graph 생성은 실제 RSS/처리량을 측정하는 기존 병렬 실행기를 사용한다. 정적 canonical graph는 디스크 cache로 재사용하고 support embedding은 epoch마다 갱신한다. GNN은 BF16 autocast를 사용한다. OOM 측정 후보는 tensor reference를 해제한 후 다른 physical batch를 검토한다.

현재 구현은 단일 GPU용이다. 여러 GPU가 보이면 오류를 내며 조용히 한 장만 사용하지 않는다. 여러 GPU를 할당받은 본실험의 DDP는 추가 구현·검증이 필요하다. nnU-Net은 원래 planner가 정한 physical batch/patch를 보존한다. **해당 native batch와 worker 처리량의 목표 GPU 실측은 아직 수행하지 않았다.** 이를 자원 최적화 완료라고 보고하지 않는다.

GNN 실행 설정/parameter 수/cohort 수/측정 batch/worker/RAM/GPU는 `execution.json`, epoch loss·step·VRAM·시간은 `metrics.csv`, 모델은 `model.pt`에 기록한다. `epoch_*.pt`는 미완료 checkpoint로 구분하며, 마지막 가중치로 support를 재계산한 `model.pt`만 bank에서 허용한다. checkpoint에는 config, split, 원본 해시, 코드 해시, optimizer/RNG가 포함된다. 저장된 optimizer가 있어도 현재 CLI에 resume 기능이 있다는 뜻은 아니다.

## 결과 CSV

| 파일 | 내용 |
|---|---|
| `case_metrics.csv` | 모든 outer-val 환자의 tumor Dice 및 기준별 TP/FP/FN |
| `lesion_metrics.csv` | GT 병변별 등가 직경, 크기 구간, 기준별 검출, 1:1 lesion Dice |
| `summary.csv` | 기준별 recall/precision/F1/FP per case 및 평균 tumor Dice |
| `size_metrics.csv` | ≤10 mm, 10–20 mm, >20 mm 각각의 GT 수·검출 수·recall·평균 lesion Dice |
| `completion.json` | 입력/출력 SHA 및 실행 범위 |

평가는 기존 `tools/online_eval_v2.py`의 v5 metric 함수와 26-connectivity를 그대로 사용한다. any-overlap legacy, Lesion Dice≥0.10/0.25/0.50, GT coverage≥0.10, IoU≥0.10을 각각 기록한다. **Dice≥0.10은 크기 기준이 아니라 검출 매칭 기준**이며, 작은 병변 여부는 GT의 물리 직경으로 따로 나눈다. source 선별 6-connectivity와 평가 26-connectivity는 목적이 다르며 이 차이를 숨기지 않는다. 분모가 없는 지표는 CSV 빈칸으로 기록하고 가짜 0점을 넣지 않는다.

이 평가는 v2 단일 arm의 전체 outer-val 평가다. paired bootstrap, 모든 fold 실행, ablation sweep의 완료를 의미하지 않는다. prediction receipt는 실행 명령·checkpoint 파일·입출력 해시의 증거이며 실제 로드된 tensor를 별도로 계측한 증거는 아니다.

## 검증 결과와 남은 범위

2026-09-19 로컬: 논리 CPU 16개, RAM 약 68.6 GB, RTX 5070 Ti 16 GB. 실제 검증에 사용한 PyTorch 2.5.1은 CPU 빌드여서 CUDA를 사용할 수 없다. PyG 2.6.1/nibabel 5.3.2 등은 저장소 내부 `.v2-test-deps`에만 설치했다. conda 전역 환경이나 서버 CUDA를 변경하지 않았다.

합성 DEBUG 테스트에서 label 순열 불변성, query 역류 차단, 환자 support 제외, batch 독립성, relation/L2 출력의 점수 영향, loss, 실제 KD-tree graph 생성/cache/batching, 전체 합성 cohort의 크기별 CSV 및 hash 위변조 거부를 검증했다. 전체 폭 모델은 **6,889,060 parameters**, 48³ patch, L0/L1/L2 깊이 3/2/2를 사용했고 모든 parameter에 유한한 gradient가 연결되며 각 핵심 block의 optimizer update가 발생했다. 이 optimizer step은 합성 DEBUG 테스트 1회다.

구현 및 정적/단위/smoke 검증과 별개로 **실제 의료 데이터 GNN 40 epoch, nnU-Net 250 epoch, 실제 native 환경에서의 처음부터 끝까지 실행, 전체 의료 평가, target GPU 처리량 검증은 미실행**이다. 실제 학습 가중치나 개선된 Dice 수치를 새로 만들어 보고하지 않는다.

## 작업 완료 체크리스트

- [x] 서버 또는 원격 세션 종료 위험이 있는 명령을 사용하지 않았다.
- [x] 사용자 파일과 기존 결과를 파괴적으로 변경하지 않았다.
- [x] 모델 깊이와 너비를 편의상 축소하지 않았다.
- [x] 그래프와 데이터 규모를 편의상 축소하지 않았다.
- [x] 숨겨진 subset, cap, fast mode를 추가하지 않았다.
- [x] physical batch size와 병렬화 가능성을 실제로 검토했다. 목표 GPU 및 native 처리량 실측은 미완료다.
- [x] GPU, CPU, RAM 활용 상태를 측정하거나 확인했다. 테스트는 CPU로 실행했다.
- [x] OOM 발생 시 모델 축소보다 메모리 및 병목 원인을 먼저 조사하도록 구현했다. 실제 GPU OOM 시험은 미실행이다.
- [x] 디버그 설정과 최종 설정을 분리했다.
- [x] 생산 코드에 dummy, placeholder, random fallback을 사용하지 않았다.
- [x] 핵심 GNN 모듈이 forward, loss, gradient와 optimizer에 연결되어 있다.
- [x] 실제 실행 설정과 변경 사항을 명확하게 보고했다.
- [x] smoke test와 전체 학습 또는 전체 평가를 구분해서 보고했다.
