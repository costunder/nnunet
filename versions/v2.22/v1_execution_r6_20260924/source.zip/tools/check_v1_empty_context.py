"""Actual-CT DEBUG regression for legitimately absent recipient parenchyma."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import json
import torch
from hiercp_v222.v1_cache import configuration,read_json,load_verified,provenance
from hiercp_v222.v1_local import pair_record,materialize,collate,model
from hiercp_v222.training import configure_runtime
from hiercp_v222.v1_training import gradient_check
from hiercp_v222.model import supervised_loss
from hiercp_v22.storage import load_record

def equal_tree(a,b):
    if torch.is_tensor(a): assert torch.equal(a,b)
    elif isinstance(a,dict):
        assert a.keys()==b.keys()
        for k in a:equal_tree(a[k],b[k])
    else: assert a==b

def main():
    output=Path(sys.argv[1]);output.mkdir(parents=True,exist_ok=False)
    cfg,base=configuration();configure_runtime(base,cfg['seed']);torch.set_num_threads(8)
    previous=ROOT/'work/v222_v1_recovered_training_20260924/cache'
    meta=read_json(ROOT/'work/v222_raw_ct_r3_training_20260923/context/index_vram_affine.json')
    case,organ,depth=load_verified(next(r for r in meta['raw_records'] if r['case_id']=='liver_46'))
    assignments=read_json(previous/'pair_assignment.json');rows=[];values=[];counts=[]
    for identity in ('liver_46:0','liver_46:1','liver_46:100'):
        row=next(r for r in assignments if r['id']==identity)
        d=torch.load(previous/'donors'/f'{row["donor_case_id"]}_{row["donor_component"]}.pt',map_location='cpu',weights_only=False,mmap=True)
        record=pair_record(case,d['source'],d['spacing'],d['prepared'],row['center'],organ,depth,base,donor_id=row['donor_case_id'])
        if identity=='liver_46:0':
            old=load_record(previous,'graphs/liver_46/0.pt.gz')
            for key in ('source_patch','target_patch','source_local','target_local'):equal_tree(old[key],record[key])
            for epoch in (0,1,39):
                a,b=materialize(old,epoch=epoch),materialize(record,epoch=epoch)
                for kind in a[0].node_types:
                    for key in a[0][kind].keys():equal_tree(a[0][kind][key],b[0][kind][key])
                for edge in a[0].edge_types:equal_tree(a[0][edge].edge_index,b[0][edge].edge_index)
            continue
        assert record['target_context_observed_absent']
        values.append(materialize(record));rows.append(row)
        counts.append(dict(id=identity,**record['target_local']['counts']))
    fixture=torch.load(ROOT/'work/v222_v1_l0_20260924/debug2/actual_graphs_DEBUG.pt',weights_only=False,map_location='cpu')
    net=model(cfg,base).cuda();net.local.dense_batch_size=6;net.eval()
    with torch.no_grad(),torch.autocast('cuda',dtype=torch.bfloat16):
        support=net.local(collate([(v,i) for i,v in enumerate(fixture['values'])]).cuda()).float()
        query=collate([(v,i) for i,v in enumerate(values)]).cuda()
        original=net.local(query)
        changed=collate([(v,i) for i,v in enumerate(values)]).cuda()
        changed.target_patches.zero_() # Explicit input-sensitivity probe only.
        delta=(original-net.local(changed)).abs().max().item()
        assert delta>0,'Actual target CT ignored'
    owners=torch.tensor([0,0,1,1,2,2],device='cuda');classes=torch.tensor([1,0,1,0,1,0],device='cuda')
    net.train();optimizer=torch.optim.AdamW(net.parameters(),lr=base['training']['lr'],weight_decay=0.,fused=True)
    before={k:v.detach().clone() for k,v in net.named_parameters()}
    with torch.autocast('cuda',dtype=torch.bfloat16):
        plan=net.fit_support_clusters(support,owners,classes)
        result=net(query,support,owners,classes,cluster_plan=plan)
        loss=supervised_loss(result,torch.tensor([r['target'] for r in rows],device='cuda'))
    loss.backward();checks=gradient_check(net)
    torch.nn.utils.clip_grad_norm_(net.parameters(),5,error_if_nonfinite=True);optimizer.step()
    changed={prefix:any(not torch.equal(before[n],p) for n,p in net.named_parameters() if n.startswith(prefix)) for prefix in ('local.dense_encoder','local.blocks.0','local.blocks.1','local.blocks.2','local.final_fuse','l1.0','l1.1','l2.0','l2.1')}
    assert all(changed.values()),changed
    result=dict(debug=True,full_training=False,real_CT=True,observations=counts,loss=float(loss.detach()),
        target_CT_sensitivity=delta,nonempty_graph_CT_edges_exact=True,nonempty_epoch_views_exact=[0,1,39],
        updated=changed,**checks,old_source_identity=read_json(previous/'started.json')['source_identity'],current_source_identity=provenance())
    with (output/'result.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2)
    print(json.dumps({k:v for k,v in result.items() if 'source_identity' not in k}),flush=True)

if __name__=='__main__':main()
