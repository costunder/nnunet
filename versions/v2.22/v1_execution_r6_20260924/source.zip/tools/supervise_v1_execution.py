"""Run one resumable local training job; expose live PID, phase and saved progress."""
import argparse
import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import psutil
ROOT=Path(__file__).resolve().parents[1]

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--cache',required=True);parser.add_argument('--output',required=True)
    parser.add_argument('--calibration');parser.add_argument('--resume')
    parser.add_argument('--release-unused',action='store_true')
    args=parser.parse_args();output=Path(args.output).resolve()
    if not output.is_relative_to(ROOT/'work') or output.exists():raise ValueError('New workspace run directory required')
    status_path=Path(str(output)+'.status.json')
    if status_path.exists():raise FileExistsError(status_path)
    command=[str(ROOT/'.venv/Scripts/python.exe'),'-u',str(ROOT/'run_v222_v1_l0.py'),'train',
        '--cache',str(Path(args.cache).resolve()),'--output',str(output)]
    for key in ('calibration','resume'):
        if getattr(args,key):command.extend(['--'+key,str(Path(getattr(args,key)).resolve())])
    if args.release_unused:command.append('--release-unused')
    logs=[Path(str(output)+suffix) for suffix in ('.stdout.log','.stderr.log')]
    with logs[0].open('x',encoding='utf-8') as stdout,logs[1].open('x',encoding='utf-8') as stderr:
        process=subprocess.Popen(command,cwd=ROOT,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        while True:
            code=process.poll();saved={};checkpoint=output/'checkpoint_status.json'
            if checkpoint.exists():saved=json.loads(checkpoint.read_text(encoding='utf-8'))
            phase=saved.get('phase','initialization')
            if (output/'training_complete.json').exists():phase='GNN_training_complete'
            elif (output/'paused.json').exists():phase='paused'
            elif code is not None and code!=0:phase='failed'
            children=[]
            if code is None:
                try:processes=[psutil.Process(process.pid)]+psutil.Process(process.pid).children(recursive=True)
                except psutil.NoSuchProcess:processes=[]
                for child in processes:
                    try:children.append(dict(pid=child.pid,created=child.create_time(),command=child.cmdline(),rss=child.memory_info().rss))
                    except psutil.NoSuchProcess:continue
            value=dict(updated=datetime.datetime.now().astimezone().isoformat(),supervisor_pid=os.getpid(),launcher_pid=process.pid,
                processes=children,stage=phase,exit_code=code,checkpoint=saved,optimizer_started=saved.get('step',0)>0,
                training_complete=(output/'training_complete.json').exists(),nnunet_started=False,
                command=command,stdout=str(logs[0]),stderr=str(logs[1]))
            temp=Path(str(status_path)+'.tmp');temp.write_text(json.dumps(value,indent=2),encoding='utf-8');os.replace(temp,status_path)
            if code is not None:break
            time.sleep(10)
    print(status_path,flush=True)
if __name__=='__main__':main()
