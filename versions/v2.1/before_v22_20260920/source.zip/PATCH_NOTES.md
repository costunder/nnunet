# HierCP 패치 노트

현재 버전: **v2.1** · 버전 명칭 정리: **2026-09-19 KST**

이 문서는 설계·구현 변경 이력의 기준이다. 버전 번호는 로컬 파이프라인을 구분하며 GitHub release/tag 생성, 서버 배포 또는 전체 학습 완료를 뜻하지 않는다.

| 버전 | 상태 | 무엇을 했는가 |
|---|---|---|
| v1 | 기존 기준선 보존 | 기존 L0 국소 그래프, L1 patient/region, L2 population/prototype 및 feedback CP 파이프라인 |
| v2.0 | 잘못된 view-only 설계, 폐기·원본 보존 | 동일 데이터의 두 stochastic view에 각각 label을 만들고 view 간 일치만 학습 |
| **v2.1** | **현재 구현** | 실제 환자별 L1의 임의적 label 공간을 L2에서 정렬하고 다른 환자의 관측 positive evidence 전달 |

상세 구조는 [현재 파이프라인](docs/pipeline_v2.md), 인계 상태는 [gpt_handoff.md](gpt_handoff.md), 보존 위치는 [버전 안내](versions/README.md)를 따른다.

## v2.1 — 실제 환자별 L1 / 환자 간 L2 정렬

### 2026-09-19 사용자 정정: Basic CP는 원본 정책을 유지하고 온라인화만 수행

- 기존 실험용 Basic이라는 이름에 들어 있던 ≤20 mm source 제한과 128개 후보 풀은 원본 Basic CP의 규칙이 아니다. 공통 donor 풀도 원본 규칙이 아니다. 과거 결과를 원본 Basic 결과로 재표기하지 않는다.
- `basic_cp_online/`과 `run_basic_cp_online.py`를 새로 분리했다. 자기 환자의 전체 종양 중 균등 무작위 1개, 무작위 탐색 첫 유효 위치, 원본 4,000회 한도, 1회 paste, 원본 HU jitter를 유지한다. 추가 50% 적용 gate는 없다. 학습 case 방문마다 새로 추출하며 native nnU-Net crop과 validation 경로를 유지한다.
- 원본 uint8 mask inversion 거리 오류는 literal 원본 재현 경로에 명시적으로 보존한다. 오류 수정 실험과 원본 온라인화 실험을 섞지 않는다. 12개 seed의 원본 실행 CT/GT 대조, native 변환과 실제 표준 loader를 포함한 DEBUG 8개가 통과했다. 전체 학습은 미실행이다.
- 상세 계약과 실행·미검증 범위: [원본 Basic CP 온라인](docs/original_basic_cp_online.md). 기존 v1/v2 런타임과 실행 중인 GNN 코드는 변경하지 않았다.
- 실제 `liver_2`의 자기 종양 25.3166 mm / 14,131 voxel을 축소 없이 증강했고, 원본 스크립트 실행과 전체 raw CT/GT 완전 일치·원본 SHA 불변을 확인했다. 이 환자는 기존 ≤20 mm 변형에서 제외됐지만 원본 Basic에서는 제외되지 않는다. `work/original_basic_cp_online_20260919/debug1/`에 현재 소스 SHA의 DEBUG 증거를 보존했다. 전체 Basic 학습·native 의료 평가 완료를 뜻하지 않는다.

### 2026-09-19 추가 패치: 모든 학습 환자의 공통 donor 증강과 분할 누수 방지

- 소형 종양 조건을 donor 자격에만 적용한다. outer-train 105명 모두 동일한 inner-train 적격 donor 527개에 접근하며, native CP 이벤트마다 균등 선택한다. 원래 소형 종양이 없는 환자도 제외하지 않는다. CP 확률 0.5는 유지한다.
- 잘못된 81명 자기 donor / 24명 전체 donor 분기를 제거했다. GNN context는 실제 T anchor 662개 전부와, donor·recipient를 모두 포함하는 균형 round의 128개 후보로 구성한다. train 67,983개 + validation 67,591개 = 총 135,574개다. native CP의 이벤트별 전체 풀 추출과 별도이며 환자별 donor를 고정하지 않는다.
- native bank는 전체 recipient/donor catalog를 검증한 뒤, 실제 요청된 pair에서 전체 128개 graph와 점수를 계산한다. 고정 argmax의 실제 raw CT/GT paste 한 개와 전체 점수·좌표를 저장한다. 원본 CT/GT는 수정하지 않는다. preparation subtree를 runtime bank 재로딩 시 복원하도록 저장 경로를 보완했다.
- donor는 inner-train만, GNN gradient·support도 inner-train만 사용한다. outer-val은 CP recipient에도 넣지 않는다. nnU-Net validation은 기존 일반 loader를 유지한다. split 중복, 분할을 넘는 동일 원본 영상, donor membership, checkpoint support IDs 및 원본·plan·catalog·payload SHA를 검사한다. 단계별 경계와 검사 한계는 [누수 방지 계약](docs/shared_donor_leakage_v21.md)에 명시했다.
- 작업 queue를 연속 배정하고 실제 측정에 따른 CPU/RAM admission과 공유 volume cache를 연결했다. L1의 모든 context를 유지하면서 activation checkpointing과 attention 실행 분할을 적용해 CUDA kernel의 65,535-row 제한을 해결했다. batch/worker는 실제 후보 측정으로 선택하며, 과대 allocation 전 측정 메모리 증가율을 검사한다. 모델·graph·후보·40/250 epoch는 유지한다.
- 수정 전 17개 소스는 `versions/v2/pre_shared_donor_fix_20260919/`에 보존했다. 이전 비대칭 cache/bank/checkpoint는 재사용하지 않는다. 회귀 39/39 통과. 실제 CT의 128후보→native paste 검증 및 전체 학습 상태는 [로컬 실행 기록](docs/local_v21_5070ti_run.md)을 따른다. DEBUG 검사 통과를 의료 성능이나 전체 학습 완료로 보지 않는다.
- 실제 외부 donor를 원래 적격 source가 없는 `liver_2`에 적용하는 DEBUG 연결 검사도 통과했다. 128개 전체 점수 argmax에 CT/GT 3,165 voxel을 paste했으며 영역 밖 GT·원본 SHA를 보존했다. 미학습 모델을 사용한 검사로 의료 성능 결과는 아니다.
- 22:21 KST에 `attempt3_shared_donor/`에서 전체 준비→GNN 40 epoch launcher를 시작했다. 원본 131명만 재사용하며 이전 부분 graph cache는 재사용하지 않는다. 현재 소스 SHA의 최종 정적 22개·회귀 39개·CUDA optimizer·67,983 context 역전파·실데이터 native paste 증거를 `versions/v2/verification_shared_donor_20260919/`에 보존했다. 학습 완료나 nnU-Net 250 epoch 실행 완료를 뜻하지 않는다.

### 2026-09-19 실행 중단 정정: donor 유무에 따른 후보 정책 불일치

사용자 지적에 따라 실제 분기를 확인했다. 소형 source가 있는 81명은 자기 환자 source만 사용하지만, 없는 24명에게만 전체 inner-train source 527개×128개 후보를 적용한다. 예: liver_1은 11개 source/1,419 graphs, liver_3은 1개/129 graphs, liver_2는 자기 source 0개인데 외부 527개/67,456 graphs다. 모든 환자에게 같은 donor 정책을 적용한 것이 아니며, L2 정렬의 필수 조건으로 설명할 근거가 없다. 이 정책을 확정된 설계로 실행한 점을 정정한다.

해당 graph 준비 프로세스 PID 37104만 중단했다. 전체 GNN optimizer는 미시작이며 부분 cache는 학습에 사용할 수 없다. 원본 131명 데이터·기존 결과·완료된 native 131명 전처리는 보존했다. 아직 후보 정책이나 모델 규모를 변경하지 않았으며 자동 재실행하지 않는다. 실행 중단 기록은 `work/local_v21_5070ti_20260919/attempt2/stopped_donor_policy_review.json`이다. 아래 실행 중이라는 설명은 중단 이전 이력이다.

### 2026-09-19 추가 패치: 전체 의료 데이터 준비와 실데이터 CUDA 검증

- MSD Task03 Liver archive 28,925,891,584 bytes의 다운로드·공식 MD5 검증·추출을 완료했다. 정답이 있는 131명 전부의 CT/GT를 검증했으며 outer train/val 105/26, inner train/val 84/21이다. 서버 실험과 분할 byte 동일성을 확인한 것은 아니다.
- 첫 준비 실행은 105명 중 37명의 source inventory 처리 후 RAM admission `MemoryError`로 중단됐다. 실패 로그와 부분 출력은 `work/local_v21_5070ti_20260919/`에 남겼다. GPU 학습 OOM이나 학습 완료로 기록하지 않는다.
- 환자별 모든 종양 mask를 동시에 보관하던 코드를 반복 가능한 lazy source collection으로 바꿨다. 후보별 공통 source tensor는 SHA로 식별해 한 번 저장하고 나머지는 gzip으로 무손실 저장한다. 원래 tensor와 로딩 결과의 정확한 일치를 검사했다. 모델·환자·병변·후보 수는 변경하지 않았다. 수정 전 원본은 `versions/v2/pre_storage_fix_20260919/`에 보존했다.
- 전체 원본의 기존 6-connectivity/≤20 mm 규칙에서 inner-train donor source는 527개다. 적격 T가 없는 outer-train 환자 24명도 모든 donor의 128개 후보를 쓰므로 예정 cache는 **1,704,342개 graph**다. 전체 cache 용량·소요시간과 이 규모의 L1/L2 GPU 메모리는 아직 검증되지 않았다.
- `attempt2/`에서 완료된 131명 원본 데이터의 SHA를 다시 확인하고 전체 graph 준비→GNN 40 epoch 실행을 시작했다. nnU-Net train-only fingerprint/planning은 완료됐고 131명 전처리를 별도로 실행했다. GNN optimizer 시작과 native 학습 완료는 별도 단계다.
- 새 source identity에서 정적 검사 17개, CPU/CUDA 회귀 **26/26 통과**, 실패·skip 0개. 실제 CT 환자 3명의 full-scale graph 6개로 **실데이터 DEBUG BF16 optimizer 1 step**도 통과했다. loss 3.203799247741699, 모든 gradient 유한값, L0/L1/L2를 포함한 핵심 모듈 갱신, peak allocated VRAM 1,086,012,416 bytes. DEBUG subset이며 checkpoint를 생성하지 않았다. 전체 학습 결과나 의료 성능 점수가 아니다.
- 최신 증거는 `versions/v2/verification_storage_real_cuda_20260919/`, 상세 단계·제한은 [로컬 실행 기록](docs/local_v21_5070ti_run.md)을 따른다. 아래 문서 정리 당시의 CPU-only/미실행 설명은 역사적 상태다.

### 2026-09-19 추가 패치: RTX 5070 Ti 실제 CUDA 실행

- 프로젝트 전용 `.venv`에 PyTorch 2.8.0+cu128 / torchvision 0.23.0+cu128 / PyG 2.6.1 / nnU-Net 2.8.1을 설치했다. 재설치 시 `config/runtime_windows_v21.txt`의 제약을 적용한다. 시스템 드라이버와 기존 Python 환경은 변경하지 않았다.
- 첫 실제 CUDA BF16 검사에서 L1의 `index_add_` 버퍼(BF16)와 weighted message(FP32) 자료형 불일치가 발견됐다. 버퍼를 곱셈 결과의 승격된 dtype으로 만들도록 수정했다. 레이어·채널·그래프·학습 규모와 L1/L2 의미는 유지한다.
- 수정 전 파일은 `versions/v2/pre_cuda_dtype_fix_20260919/`에 보존했다. 런타임 소스 SHA가 바뀌었으므로 과거 source identity를 가진 checkpoint의 자동 재사용은 허용하지 않는다.
- 실제 5070 Ti에서 7,086,156-parameter DEBUG 모델의 BF16 forward/backward/optimizer 1 step 통과. 회귀 **26/26 통과**, 실패·skip 0개. 기존 25개 CPU 검사와 구별한다. 이 합성 검사는 의료 성능 결과가 아니다.
- 공식 MONAI 배포 MSD Task03 Liver 전체 archive 다운로드·체크섬 검증, 환자 131명 검증 및 기존 stratified split 재구성 도구를 추가했다. 서버 원본 split/hash 동일성은 미확인이다.
- 실행 절차와 진행 상태는 [로컬 실행 기록](docs/local_v21_5070ti_run.md)을 따른다. 전체 학습 완료와 nnU-Net 성능 평가 완료는 해당 완료 파일이 생긴 뒤에만 기록한다.

기록일: 2026-09-19. 기존 문서의 `cross-patient r1` 구현을 **v2.1**로 명명한다. 이번 패치 노트 정리는 버전 명칭·문서 동기화이며 모델을 다시 변경하거나 학습한 작업이 아니다.

### 수정한 문제와 구현

- **L0:** 기존 KD-tree 질의로 만드는 국소 physical graph와 GNN 인코더를 유지한다. 그래프 구성과 그래프 인코딩은 별개 단계다.
- **L1:** task를 실제 patient ID로 정의한다. 각 환자마다 독립적으로 초기화한 학습 가능한 label nodes를 두고 data↔label 관계를 학습한다. 이 label은 국소적·임의적 표현이며 절대 정답이나 모든 환자에게 공통인 class ID가 아니다. K-means label과 view를 task로 취급하던 방식을 제거했다.
- **L2:** 환자별 L1 label 공간의 대응 관계를 학습한다. 다른 inner-train 환자의 관측 T를 target 환자의 공간으로 전달해 U 후보와의 compatibility를 계산한다. target 자신의 T와 inner-val 환자를 evidence donor로 사용하지 않는다. T가 없는 환자도 U-only task로 참여한다.
- **T/F/U:** T는 실제 적격 tumor source 원위치, F는 명확한 기하학적 불가능, U는 유효하지만 positive가 관측되지 않은 위치다. U를 negative로 감독하지 않는다. 생산 cache는 T/U를 만들며 불가능한 후보는 geometry 검사에서 제외한다. 점수는 암 존재 확률이 아니다.
- **학습 연결:** 관측 T/F 오차, 실제 context 통계 reconstruction, 환자 간 soft alignment를 연결했다. 통계 유사성을 correspondence teacher로 사용하는 것은 구현의 연구 가정이며 의학적 정답으로 검증된 것이 아니다.
- **CP·평가 연결:** frozen GNN의 `cross_patient_positive_transport_argmax`로 후보를 선택한다. 실제 donor paste에 대해서만 synthetic segmentation GT를 만든다. 크기별 지표는 `size_metrics.csv`, 개별 병변 지표는 `lesion_metrics.csv` 등에 기록하도록 구현했다.

### 유지한 규모와 호환성

L0 hidden 128 / heads 4 / layers 3, L1/L2 layers 2/2, CNN 12/24/32, patch 5×48³, 환자별 label 16×128, GNN 40 epoch, nnU-Net ResEncM 250 epoch, source당 후보 128개, CP 확률 0.5를 유지한다. label 16개는 구현의 capacity 설정이며 확정된 의학 범주 수가 아니다.

현재 v2.1의 내부 artifact format은 **`hiercp_prompt_graph_v2_cross_patient_r1`**이다. `run_v2.py`, `hiercp_v2/`, `config/prompt_graph_v2.json`, `versions/v2/`의 경로명은 v2 계열 경로로 유지한다. 경로에 `v2`가 있다는 이유로 폐기된 v2.0으로 해석하지 않는다. 내부 format 문자열을 이름만 바꿔 checkpoint를 이전하지 않는다.

v1·v2.0 cache/checkpoint/bank는 v2.1과 호환되지 않는다. 새 출력 디렉터리와 새 데이터 준비·학습이 필요하다. 자동 resume와 DDP는 미구현이다. v1의 별도 feedback curriculum과도 다르므로 v1 대비 차이를 L2 단독 ablation 효과로 보고하면 안 된다.

### 검증과 미실행 항목

기존 [검증 기록](versions/v2/verification_cross_patient_final_20260919/verification.json)과 [테스트 로그](versions/v2/verification_cross_patient_final_20260919/tests.txt): **합성 DEBUG 25/25 통과, 실패·skip 0개, Python 16개 정적 검사 통과**. 환자별 label 독립성, U supervised gradient 배제, 외부 T 전달, 자기 T 제외, label 순열, full-width gradient/optimizer 연결 등을 검사했다. 준비-loop의 128개 후보 검사는 geometry를 mock한 정책 검사이며 실제 의료 데이터 검증이 아니다.

**실제 의료 데이터 전체 GNN 학습·nnU-Net 학습·native end-to-end 실행·전체 의료 평가·target GPU 처리량 측정은 미실행이다. v2.1의 실제 성능 점수나 학습 완료 가중치는 없다.** 이번 문서 변경에서는 모델 테스트를 재실행하지 않고 기존 검증의 소스 SHA 일치와 문서 export를 확인한다.

## v2.0 — 잘못된 view-only 구현, 폐기

이력 구분일: 2026-09-19. 이전 문서에서 처음 `v2`라고 불렀던 구현이다.

동일 데이터에 두 stochastic L0 view를 만들고 각 view에 K-means label을 부여했다. L1은 data–label 관계를 만들고 L2는 shared-support contingency / view consistency로 두 view를 맞췄다. 정렬 embedding의 cosine 기반 후보 선택을 사용했다.

**잘못된 점:** 사용자가 의도한 L2는 서로 다른 실제 환자의 국소 임의 label 공간을 정렬하는 역할이다. 같은 데이터의 view 일치만으로 대체한 v2.0은 이 요구를 충족하지 못했다. 현재 설계나 최종 baseline으로 사용하지 않는다.

- 소스·당시 handoff·code.txt **218개**: [보존 ZIP](versions/v2/superseded_view_alignment_20260919/source.zip), [SHA manifest](versions/v2/superseded_view_alignment_20260919/manifest.json).
- 과거 내부 format: `hiercp_prompt_graph_v2`. v2.1 format과 구별한다.
- `versions/v2/verification_20260919/`와 `verification_handoff_20260919/`의 테스트는 당시 구현의 역사적 검사다. 이를 v2.1 검증이나 의료 성능 결과로 인용하지 않는다.

## v1 — 기존 HierCP 파이프라인 보존

보존 기준 commit: `74dcc2cf03d2d40d1f582223321d96004333f661`. 버전 정리일: 2026-09-19. 이 날짜는 원래 실험 수행일이 아니다.

- 기존 `run.py`, `hiercp/`, `custom_trainers/`, 기존 설정과 실험 경로를 보존했다. `run_v1.py`는 기존 진입점의 별칭이다.
- L0는 기존 국소 그래프 인코더, L1은 patient/region 계층, L2는 population/prototype 계층이다. 기존 online CP와 feedback/curriculum 구현을 유지한다.
- 내부 `MODEL_ARCHITECTURE_VERSION=v5`는 **파이프라인 v1** 안의 모델 revision이다. 파이프라인 v5로 재명명하지 않는다.
- 추적 파일 **202개**를 [원본 ZIP](versions/v1/pipeline_v1_source.zip)과 [SHA manifest](versions/v1/manifest.json)에 보존했다. 현재 handoff/code.txt는 갱신하되 두 파일의 v1 원문은 ZIP에서 검증한다. 다른 원래 runtime/config 파일은 현재 파일도 원본 SHA와 일치해야 한다.
- 과거 성능·ablation 결과는 원래 실험명과 평가 기준을 유지한다. [과거 결과 정리](docs/results_summary_20260918.md)와 `experiment_results/`를 참조하며 v2.0/v2.1 성능으로 옮겨 적지 않는다. 이번 버전 정리는 기존 실험 재실행이 아니다.

## 이후 기록 규칙

변경할 때마다 이 파일 상단에 새 버전 항목을 추가하고 **날짜, 수정한 문제, 구조·코드·설정 변경, 호환성, 검사 근거, 미실행 항목**을 기록한다. 이전 항목과 보존 ZIP은 덮어쓰지 않는다. 수정된 설명이 필요하면 정정 내용을 별도로 남긴다.

현재 버전 표기는 이 문서·`versions/README.md`·`docs/pipeline_v2.md`·`gpt_handoff.md`에서 함께 갱신하고 `code.txt`를 재생성한다. 실행 파일명과 저장 format ID는 사람이 읽는 버전 번호와 구별한다. DEBUG 통과와 실제 전체 학습·평가, 로컬 변경과 GitHub 배포를 각각 기록한다.

## 작업 완료 체크리스트

이번 작업은 패치 노트 및 인계 문서 정리다. 아래 미체크 항목은 이번 문서 작업에서 수행하지 않은 실행 검증이다.

- [x] 서버 또는 원격 세션 종료 위험이 있는 명령을 사용하지 않았다.
- [x] 사용자 파일과 기존 결과를 파괴적으로 변경하지 않았다.
- [x] 모델 깊이와 너비를 편의상 축소하지 않았다.
- [x] 그래프와 데이터 규모를 편의상 축소하지 않았다.
- [x] 숨겨진 subset, cap, fast mode를 추가하지 않았다.
- [ ] physical batch size와 병렬화 가능성을 실제로 검토했다. 기존 구현 상태만 기록했으며 새 측정은 하지 않았다.
- [ ] GPU, CPU, RAM 활용 상태를 측정하거나 확인했다. 기존 검증 기록을 참조했으며 새 자원 측정은 하지 않았다.
- [ ] OOM 발생 시 모델 축소보다 메모리 및 병목 원인을 먼저 조사했다. 이번 작업에 OOM 실행은 없었다.
- [x] 디버그 설정과 최종 설정을 분리해서 기록했다.
- [x] dummy, placeholder, random fallback을 사용하지 않았다.
- [ ] 핵심 모듈이 forward, loss, gradient와 optimizer에 연결되어 있다. 기존 DEBUG 증거를 인용했으며 이번에 재실행하지 않았다.
- [x] 실제 실행 설정과 변경 사항을 명확하게 보고했다.
- [x] smoke test와 전체 학습 또는 전체 평가를 구분해서 보고했다.
