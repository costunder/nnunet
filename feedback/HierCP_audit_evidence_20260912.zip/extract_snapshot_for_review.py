"""Reconstruct the supplied text snapshot into a NEW directory, without edits.

This only extracts source text. It does not install packages, run repository code,
load medical data, train, modify Git, or overwrite an existing directory.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import re
from pathlib import Path, PurePosixPath

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--code', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    text = args.code.read_text(encoding='utf-8')
    pattern = re.compile(r'^===== FILE: (.+?) =====\n(.*?)\n===== END FILE: \1 =====$', re.M | re.S)
    matches = list(pattern.finditer(text))
    declared = re.search(r'^file_count:\s*(\d+)\s*$', text, re.M)
    if declared is None or len(matches) != int(declared.group(1)):
        raise ValueError('The declared file count and complete source boundaries differ')
    if len(matches) != len(re.findall(r'^===== FILE:', text, re.M)):
        raise ValueError('Unmatched or malformed source-file boundary')
    names: set[str] = set()
    for match in matches:
        name = match.group(1)
        parts = PurePosixPath(name).parts
        if (name in names or not parts or name.startswith('/') or '\\' in name
                or ':' in name or any(part in {'', '.', '..'} for part in name.split('/'))):
            raise ValueError(f'Unsafe or duplicate snapshot filename: {name!r}')
        names.add(name)
    destination = args.out.expanduser().absolute()
    if destination.exists() or destination.is_symlink():
        raise FileExistsError(f'Use a new output directory; existing files are preserved: {destination}')
    destination.mkdir(parents=True, exist_ok=False)
    manifest = []
    for match in matches:
        path = destination.joinpath(*PurePosixPath(match.group(1)).parts)
        path.parent.mkdir(parents=True, exist_ok=True)
        content = match.group(2).encode('utf-8')
        with path.open('xb') as handle:
            handle.write(content)
        manifest.append({'file': match.group(1), 'sha256': hashlib.sha256(content).hexdigest(),
                         'code_txt_start_line': text.count('\n', 0, match.start(2)) + 1})
    print(json.dumps({'extracted_files': len(manifest), 'output': str(destination),
                      'manifest': manifest}, indent=2))

if __name__ == '__main__':
    main()
