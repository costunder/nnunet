"""Read-only source audit probes. Synthetic DEBUG, not native medical/GPU training.

Run with --source <directory extracted from the supplied code.txt>.
The AST loader executes exact selected definitions without importing unavailable
PyG/nnU-Net. Boundary doubles are explicitly confined to topology construction,
late publisher failure, and the unexecuted native training boundary.
"""
from __future__ import annotations
import argparse, ast, copy, hashlib, json, os, sys, tempfile, time
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import numpy as np
import torch
from scipy.ndimage import map_coordinates
from skimage.transform import resize

parser=argparse.ArgumentParser()
parser.add_argument('--source',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
a=parser.parse_args(); root=a.source.resolve(); sys.path.insert(0,str(root))
torch.set_num_threads(2)
results=[]

def defs(relative,names,extra=None):
    tree=ast.parse((root/relative).read_text())
    wanted=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names]
    assert {n.name for n in wanted}==set(names)
    namespace={'torch':torch,'np':np,'Tensor':torch.Tensor,'Path':Path,'json':json,
               'os':os,'Any':object,'Mapping':dict,'Sequence':list}
    if extra: namespace.update(extra)
    module=ast.Module(body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0),*wanted],type_ignores=[])
    exec(compile(ast.fix_missing_locations(module),str(root/relative),'exec'),namespace)
    return namespace

def record(name,fn):
    started=time.perf_counter()
    try: detail=fn(); result={'name':name,'passed':True,'details':detail}
    except Exception as e:
        import traceback
        result={'name':name,'passed':False,'error':str(e),'traceback':traceback.format_exc()}
    result['seconds']=time.perf_counter()-started; results.append(result); print(json.dumps(result,ensure_ascii=False),flush=True)

def topology():
    from hiercp.schema import PATIENT_NODE_TYPES,PATIENT_EDGE_TYPES,PATIENT_EDGE_DIM,UPPER_RAW_DIM,UPPER_FORBIDDEN_RAW_COLUMNS,PATIENT_POSITION_EDGE_COLUMNS
    from hiercp.common import normalized_position
    class Store(dict):
        def __getattr__(self,k): return self[k]
        def __setattr__(self,k,v): self[k]=v
    class Graph(dict):
        def __getitem__(self,k):
            if k not in self: self[k]=Store()
            return super().__getitem__(k)
    raw=np.zeros(14,dtype=np.float32)
    globals_={'HeteroData':Graph,'PATIENT_NODE_TYPES':PATIENT_NODE_TYPES,'PATIENT_EDGE_TYPES':PATIENT_EDGE_TYPES,
        'PATIENT_EDGE_DIM':PATIENT_EDGE_DIM,'UPPER_RAW_DIM':UPPER_RAW_DIM,'normalized_position':normalized_position,
        '_source_raw':lambda *a,**k:raw.copy(),'_candidate_raw':lambda *a,**k:raw.copy(),
        '_principal_axis':lambda *a,**k:(np.array([1.,0.,0.]),1.),
        '_lesions':lambda *a,**k:(np.empty((0,14),np.float32),np.empty((0,3),np.float32),np.empty(0,np.int64)),
        '_liver_raw':lambda *a,**k:raw.copy(), '_knn':lambda *a,**k:np.empty((2,0),np.int64)}
    ns=defs('hiercp/hierarchy.py',['_full_bipartite','_node_meta','_patient_edge_attributes','_set_patient_relation','build_patient_graph'],globals_)
    case=SimpleNamespace(label=np.zeros((9,9,9),np.int16),shape=(9,9,9),spacing=(1.,1.,1.))
    source=SimpleNamespace(anchor_center=(4,4,4),full_mask=np.zeros((9,9,9),bool))
    regions=SimpleNamespace(region_at=lambda c:1,num_regions=3,
        region_features=np.zeros((3,16),np.float32),region_positions=np.array([[0,0,0],[.5,.5,.5],[1,1,1]],np.float32),
        region_edge_index=np.empty((2,0),np.int64))
    specs=[SimpleNamespace(center=(4,4,4),region_id=1),SimpleNamespace(center=(6,6,6),region_id=2)]
    graph=ns['build_patient_graph'](case,source,specs,regions,tumor_label=2,
        config=SimpleNamespace(max_lesions=None,candidate_k=1),ct_clip=(-200.,250.))
    masks=defs('hiercp/model.py',['_mask_upper_shortcuts','_mask_tumor_spatial_edge_attr'],
        {'UPPER_RAW_DIM':UPPER_RAW_DIM,'UPPER_FORBIDDEN_RAW_COLUMNS':UPPER_FORBIDDEN_RAW_COLUMNS,
         'PATIENT_EDGE_DIM':PATIENT_EDGE_DIM,'PATIENT_POSITION_EDGE_COLUMNS':PATIENT_POSITION_EDGE_COLUMNS})
    edge=('tumor','hosted_by','region')
    before=graph[edge].edge_index.clone()
    graph[edge].edge_attr=masks['_mask_tumor_spatial_edge_attr'](edge,graph[edge].edge_attr)
    assert torch.equal(before,graph[edge].edge_index)
    host=int(before[1,0]); belongs=graph['candidate','belongs_to','region'].edge_index
    match=(belongs[1]==host).tolist(); assert match==[True,False]
    forward=ast.parse((root/'hiercp/model.py').read_text())
    cls=next(n for n in forward.body if isinstance(n,ast.ClassDef) and n.name=='PatientRegionPyGEncoder')
    fn=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='forward_raw')
    assert any(isinstance(n,ast.Attribute) and n.attr=='edge_index_dict' and isinstance(n.value,ast.Name) and n.value.id=='raw_batch' for n in ast.walk(fn))
    return {'scope':'Exact graph-construction and masking definitions; feature extractors and PyG container are DEBUG boundary doubles. No GNN forward run.',
            'hosted_by_edge_index':before.tolist(),'candidate_region_edges':belongs.tolist(),
            'source_region_recoverable_after_masking':host,'two_hop_source_region_candidate_path':match}

def publisher():
    from custom_trainers.onlinecp_feedback_policy import validate_feedback_config, feedback_config_sha256
    from custom_trainers.onlinecp_curriculum_contract import FORMAT,file_sha256
    from hiercp.contracts import require_current_checkpoint,validate_nested_cohorts
    config=json.loads((root/'config/online_cp_feedback.json').read_text())
    with tempfile.TemporaryDirectory(prefix='hiercp_audit_publisher_') as tmp:
        t=Path(tmp); bank=t/'bank'; gnn=t/'gnn'; pre=t/'pre'; bank.mkdir();gnn.mkdir();pre.mkdir()
        layout=SimpleNamespace(train_config=t/'train.json',nnunet_config=t/'nn.json',outer_splits=t/'outer.json',
            bank=lambda _:bank,gnn=lambda _:gnn,preprocessed=t)
        split={'train':['tr1','tr2'],'val':['va1']}; inner={'train':['tr1'],'val':['tr2']}
        checkpoint={'architecture_version':'hiercp_conditioned_readout_v3','geometry_contract':'level0_physical_closure_v2',
                    'graph_config':{'geometry_contract':'level0_physical_closure_v2'},'prototype_training_cases':['tr1']}
        index={'paste_contract':'onlinecp_raw_target_paste_v1','candidate_count':128,'cp_probability':.5,
               'dataset_name':'Dataset760_LiverOnlineCP_OF0','entries_by_case':{'tr1':['one.npz']}}
        cfgpath=t/'feedback.json';cfgpath.write_text(json.dumps(config))
        layout.train_config.write_text('{}');layout.nnunet_config.write_text(json.dumps({'dataset':{'plans':'P'}}));layout.outer_splits.write_text('{}')
        (bank/'index.json').write_text(json.dumps(index)); np.savez(bank/'one.npz',scores=np.ones(128,np.float32))
        for p in [bank/'config.json',bank/'manifest.csv',bank/'complete.json',gnn/'model.pt',gnn/'split.json',gnn/'prototype.pt',
                  gnn/'graphs/complete.json',pre/'splits_final.json',pre/'P.json',pre/'dataset.json']:
            p.parent.mkdir(parents=True,exist_ok=True);p.write_text('{}')
        (pre/'marker.json').write_text(json.dumps({'input_contract':{'planning_cohort':'outer_train_only_v1'}}))
        online=SimpleNamespace(load_json=lambda p:json.loads(Path(p).read_text()),_verified_bank_identity=lambda *a:None,
            outer_split=lambda *a:split,_verified_gnn_split=lambda *a:inner,
            preprocessed_dataset_dir=lambda *a:pre,PREPROCESS_MARKER_NAME='marker.json')
        def late_failure(*args,**kwargs): raise OSError('DEBUG injected post-publication verification failure')
        ns=defs('tools/online_cp_curriculum.py',['publish'],{'online':online,'FORMAT':FORMAT,'file_sha256':file_sha256,
            'require_current_checkpoint':require_current_checkpoint,'validate_nested_cohorts':validate_nested_cohorts,
            'verify_curriculum_bank_contract':late_failure})
        with patch('hiercp.tensor.load_checkpoint',return_value=checkpoint):
            first=None
            try: ns['publish'](layout,0,760,cfgpath)
            except OSError as e:first=type(e).__name__
            output=bank/'feedback_contract.json'; assert output.is_file()
            first_sha=file_sha256(output);second=None
            try:ns['publish'](layout,0,760,cfgpath)
            except FileExistsError as e:second=type(e).__name__
            assert first=='OSError' and second=='FileExistsError' and file_sha256(output)==first_sha
        return {'scope':'Exact publish() with mocked already-verified native boundaries and injected late verifier failure; all writes isolated in TemporaryDirectory.',
            'first_failure':first,'final_named_contract_remained':True,'second_attempt':second,'remaining_file_unchanged':True}

def offline():
    class Error(RuntimeError):pass
    ns=defs('tools/nnunet.py',['train','train_one'],{'PipelineError':Error})
    calls=[]; original=ns['train_one']
    def training_boundary(project,p,cfg,condition,base_fold,nnfold,split,device,dry):
        calls.append(condition)
        if condition=='hierarchical_copy_paste':return original(project,p,cfg,condition,base_fold,nnfold,split,device,dry)
        # No native process is launched; record the earlier baseline boundary.
    ns.update(train_one=training_boundary,plan_ready=lambda *a:True,install_splits=lambda *a:None,
              load_json=lambda p:{'splits':[{'train':['tr'],'val':['va']}] * 10})
    try:ns['train'](None,SimpleNamespace(splits_json=Path('unused')),{},[0],'cpu',False)
    except Error as e:message=str(e)
    else:raise AssertionError('Expected the explicit unsupported-CP gate')
    assert calls==['baseline','hierarchical_copy_paste']
    return {'scope':'Exact orchestration and unsupported-condition gate; baseline is a recording double, no training performed.',
        'entered_conditions':calls,'guaranteed_error':message,'failure_gate_before_baseline':False}

def streamed():
    ns=defs('hiercp/model.py',['_StreamedEdgeAggregation'])
    cls=ns['_StreamedEdgeAggregation'];gen=torch.Generator().manual_seed(23)
    f=torch.randn(4,2,3,dtype=torch.double,generator=gen,requires_grad=True)
    edges=torch.tensor([[0,0,1,2,3,3],[0,2,1,1,0,2]],dtype=torch.long)
    att=torch.randn(6,2,dtype=torch.double,generator=gen,requires_grad=True)
    out=cls.apply(f,edges,att,3,2)
    reference=torch.zeros(3,2,3,dtype=torch.double).index_add(0,edges[1],f[edges[0]]*att[...,None])
    error=float((out-reference).detach().abs().max());assert error<1e-14
    ok=torch.autograd.gradcheck(lambda f,a:cls.apply(f,edges,a,3,2),(f,att),eps=1e-6,atol=1e-5,rtol=1e-4)
    assert ok
    empty=cls.apply(f,edges[:,:0],att[:0],3,2);assert torch.equal(empty,torch.zeros_like(empty))
    return {'scope':'Exact custom autograd operator; real CPU PyTorch forward/backward, no PyG.',
            'max_forward_absolute_error':error,'float64_gradcheck':bool(ok),'empty_edge_forward':True}

def raw_operator():
    from custom_trainers.onlinecp_raw_resampling import _axis_operator,_contract,_patch_operator,_linear_label_grid
    rng=np.random.default_rng(4);shape=(7,9,11);new=(10,6,13)
    base=rng.normal(size=shape);delta=rng.normal(size=(3,3,4));origin=(2,4,5)
    full=base.copy();sl=tuple(slice(o,o+s) for o,s in zip(origin,delta.shape));full[sl]+=delta
    ops=[_axis_operator(n,m,order=3) for n,m in zip(shape,new)]
    crop=np.array([[1,8],[0,5],[2,12]])
    cropped_ops=[_patch_operator(op,row,o,n) for op,row,o,n in zip(ops,crop,origin,delta.shape)]
    slout=tuple(slice(*r) for r in crop)
    oracle=resize(full,new,order=3,mode='edge',clip=False,anti_aliasing=False,preserve_range=True)[slout]
    rebuilt=resize(base,new,order=3,mode='edge',clip=False,anti_aliasing=False,preserve_range=True)[slout]+_contract(delta,cropped_ops)
    err=float(np.max(np.abs(oracle-rebuilt)));assert err<1e-11
    labels=rng.integers(0,3,size=shape,dtype=np.int16)
    linear=[_axis_operator(n,m,order=1) for n,m in zip(shape,new)]
    actual=_linear_label_grid(labels,linear,(0,1,2));expected=np.zeros(new,np.int16)
    for l in (0,1,2):
        p=resize((labels==l).astype(float),new,order=1,mode='edge',clip=True,anti_aliasing=False,preserve_range=True)
        expected[p>=.5]=l
    assert np.array_equal(actual,expected)
    return {'scope':'Exact source operator helpers versus installed skimage.resize. Synthetic CPU arrays; NOT native nnU-Net prepare_case integration.',
            'cubic_delta_crop_max_error':err,'full_label_mixture_exact_match':True,'input_shape':shape,'output_shape':new}

def masking():
    from hiercp.schema import UPPER_RAW_DIM,UPPER_FORBIDDEN_RAW_COLUMNS
    fn=defs('hiercp/model.py',['_mask_upper_shortcuts'],{'UPPER_RAW_DIM':UPPER_RAW_DIM,'UPPER_FORBIDDEN_RAW_COLUMNS':UPPER_FORBIDDEN_RAW_COLUMNS})['_mask_upper_shortcuts']
    raw=torch.randn(12,UPPER_RAW_DIM); layer=torch.nn.Linear(UPPER_RAW_DIM,5)
    layer(fn(raw)).square().mean().backward()
    columns=list(UPPER_FORBIDDEN_RAW_COLUMNS); assert torch.count_nonzero(layer.weight.grad[:,columns])==0
    return {'scope':'Exact input mask and actual torch Linear backward; does not claim an entire GNN block is disconnected.',
            'identically_zero_input_columns':columns,'data_gradient_on_masked_projection_columns':'exactly zero'}

def survivor():
    from custom_trainers.onlinecp_feedback_metrics import compute_feedback_metrics,_border_contact
    mask=torch.zeros(1,1,9,9,9,dtype=torch.bool);mask[:,:,3:6,3:6,3:6]=True
    labels=torch.ones_like(mask,dtype=torch.int16);labels[mask]=2
    valid=torch.ones_like(mask);truncated=_border_contact(mask,valid)
    out=compute_feedback_metrics(torch.zeros(1,3,9,9,9),labels,mask,valid_mask=valid,event_applied=torch.tensor([True]),mask_truncated=truncated)
    assert int(out['status'][0])==0
    return {'scope':'Actual metric on one fully interior surviving component. Hypothetical other disjoint component outside crop is NOT supplied to the metric.',
            'available_status':int(out['status'][0]),'crop_support':int(mask.sum()),
            'limitation':'Boundary-contact alone does not establish that every full-native component survived the crop. The native-count audit is separate.'}


def matching_tie_break():
    from tools.online_eval_v2 import PairMatrices, Criterion, match_components
    gt = np.array([100, 200], dtype=np.int64)
    pred = np.array([100, 200], dtype=np.int64)
    inter = np.array([[45, 36], [45, 0]], dtype=np.int64)
    # Feasible disjoint-component counts: each row/column fits its component.
    assert np.all(inter.sum(1) <= gt) and np.all(inter.sum(0) <= pred)
    dice = 2 * inter / (gt[:, None] + pred[None, :])
    matrix = PairMatrices(gt, pred, inter, dice,
        inter / (gt[:, None] + pred[None, :] - inter),
        inter / gt[:, None], inter / pred[None, :])
    actual = match_components(matrix, Criterion('dice_ge_0p25', 'Dice >= .25', 'dice', .25))
    assert dict(actual.gt_to_pred) == {1: 0}
    chosen_sum = sum(float(dice[g, p]) for g, p in actual.gt_to_pred.items())
    alternative_sum = float(dice[0, 0])
    assert chosen_sum < alternative_sum and actual.tp == 1
    return {'scope': 'Actual evaluator on synthetic feasible component-count matrices; no medical images.',
        'gt_voxels': gt.tolist(), 'pred_voxels': pred.tolist(), 'intersections': inter.tolist(),
        'dice_matrix': dice.tolist(), 'threshold': .25,
        'actual_match_gt_to_pred_zero_based': dict(actual.gt_to_pred),
        'actual_valid_pair_quality': chosen_sum,
        'alternative_same_tp_valid_pair_quality': alternative_sum,
        'consequence': 'Invalid-edge score changes the secondary matching decision. Total TP remains maximal, but detected GT identity and size-bin attribution can change.'}

for n,f in [('source_region_topology_retained',topology),('publisher_failed_verification_retry',publisher),
            ('offline_full_late_guard',offline),('streamed_attention_sum_gradient',streamed),
            ('raw_cubic_operator_and_label_mixture',raw_operator),('masked_projection_columns',masking),
            ('surviving_support_metric_scope',survivor),('evaluation_valid_pair_tie_break',matching_tie_break)]:record(n,f)
a.output.parent.mkdir(parents=True,exist_ok=True)
a.output.write_text(json.dumps({'scope':'Read-only source audit; synthetic DEBUG; no real medical, PyG or native nnU-Net/GPU training',
    'source_snapshot':'ec2d8388f39c6b03ed32a3677fbdd6eaafed4731','results':results},ensure_ascii=False,indent=2))
print('PROBES',sum(r['passed'] for r in results),'/',len(results))
