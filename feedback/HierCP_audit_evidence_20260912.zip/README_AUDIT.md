# HierCP read-only audit evidence — 2026-09-12

## 범위

사용자가 제공한 `code.txt`의 source_commit `ec2d8388f39c6b03ed32a3677fbdd6eaafed4731` 및 동반 `gpt_handoff.md`에 대한 감사다. 원격 checkout, 실제 bank/checkpoint, 서버 journal, 의료 cohort는 이 증거에 포함되지 않는다. 원본 프로젝트 소스는 수정하지 않았다.

`HierCP_code_review_20260912.md`가 상세 결과, `HierCP_review_inventory_20260912.md`가 159개 파일 대장이다. `artifacts/`에는 정적 검사, 원본 보존 hash, 추가 진단, 기존 unittest 실행 시도의 원시 결과가 있다.

## 중요한 해석

추가 probe 8개의 `passed=true`는 **진단 시나리오가 예상대로 확인됐다**는 의미다. 그중 publisher 재시도와 evaluator matching 등은 결함을 재현하는 assertion이므로, 프로젝트 버그가 수정됐거나 전체 pipeline이 통과했다는 뜻이 아니다.

기존 unittest는 누락 의존성과 import/patch 경계 오류로 전체 실패했다. `tests_run`, success callback, error event, skip event는 setup/subtest/module-load에 따라 서로 단순 합산할 수 없다. 각 test ID와 traceback을 그대로 보존했다.

현재 audit 환경: Python 3.13.5, PyTorch 2.10.0+cpu; PyG/native nnU-Net 없이 CPU synthetic probe를 실행했다. 실제 학습 및 GPU 수치 재현은 하지 않았다.

## 추가 진단 재현

기존 NumPy/SciPy/scikit-image/PyTorch가 설치된 별도 검사 환경에서, 사용자 원본 `code.txt`를 읽어 **새 디렉터리**를 만든다. 아래 명령은 패키지를 설치하지 않는다.

```bash
python extract_snapshot_for_review.py --code code.txt --out reconstructed_source
python audit_probes.py --source reconstructed_source --output local_probe_results.json
```

첫 명령은 기존 출력 디렉터리를 덮어쓰지 않는다. 두 번째 명령은 source를 읽고 필요한 실제 함수 정의를 실행한다. native/PyG 경계 double이 있는 probe는 script와 결과 JSON의 scope에 명시되어 있다. graph topology probe는 실제 trained GNN score 효과를 측정하지 않는다.

검증에 사용한 `audit_probes.py` 자체는 실제 학습 코드나 프로젝트 수정 패치가 아니다.
